<?php
/**
 * ترخيص البرنامج مقفول على بصمة الجهاز، بلا إنترنت.
 *
 * كود الجهاز: MOTO-XXXX-XXXX-XXXX (includes/hwid.php). مفتاح التفعيل: ACT-XXXX-XXXX-XXXX-XXXX، يولّده المطور فقط
 * بـ tools/keygen.php. المفتاح 16 حرفاً من Crockford Base32 = 80 بت:
 *   - 16 بت: مدة الترخيص (0 = مدى الحياة، وإلا عدد الأيام من LICENSE_EPOCH = آخر يوم صالح)،
 *     مخلوطة (XOR) بقناع من كود الجهاز فلا تتشابه مفاتيح الأجهزة.
 *   - 64 بت: أول 8 بايتات من HMAC-SHA256(LICENSE_SECRET, كود الجهاز + المدة).
 * المفتاح لا يصلح إلا لكود الجهاز الذي وُلّد له، وأي تغيير في حرف واحد يُبطله.
 *
 * الترخيص المفعّل في config/license.key (لا يُخدم عبر HTTP، ولا تحمله حزم التحديث ولا برنامج التثبيت).
 * ترخيص بتاريخ انتهاء: التاريخ الفعلي = الأحدث من تاريخ اليوم وآخر يوم رآه البرنامج، فإرجاع ساعة الجهاز لا يمدّه.
 *
 * LICENSE_SECRET ثابت لا يتغير أبداً: تغييره يبطل كل المفاتيح الصادرة.
 */

const LICENSE_SECRET = 'b31938b8f70465825c106739beb02fd2429675d197bac523e7d434d0c3f4cd1e';
const LICENSE_EPOCH = '2024-01-01';
const LICENSE_ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';   // Crockford: بلا I L O U
const LICENSE_WARN_DAYS = 14;

require_once __DIR__ . '/hwid.php';

function license_path(): string
{
    return APP_ROOT . '/config/license.key';
}

/** "MOTO-a4f1 8892-bc30" ← "MOTO-A4F1-8892-BC30"، أو null إن لم يكن كود جهاز. */
function license_normalize_machine(string $code): ?string
{
    $hex = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $code) ?? '');
    if (strpos($hex, 'MOTO') === 0) {
        $hex = substr($hex, 4);
    }
    return preg_match('/^[0-9A-F]{12}$/', $hex) ? 'MOTO-' . implode('-', str_split($hex, 4)) : null;
}

/** "lifetime" أو تاريخ YYYY-MM-DD صالح بعد LICENSE_EPOCH، وإلا null. */
function license_normalize_term(string $term): ?string
{
    $term = strtolower(trim($term));
    if ($term === 'lifetime') {
        return 'lifetime';
    }
    $date = valid_date($term);
    return $date !== null && $date > LICENSE_EPOCH && license_days($date) <= 0xFFFF ? $date : null;
}

function license_days(string $date): int
{
    return (int) (new DateTimeImmutable(LICENSE_EPOCH))->diff(new DateTimeImmutable($date))->format('%r%a');
}

function license_mac(string $machine, string $term): string
{
    return substr(hash_hmac('sha256', 'ACT|v1|' . $machine . '|' . $term, LICENSE_SECRET, true), 0, 8);
}

function license_mask(string $machine): int
{
    return unpack('n', hash_hmac('sha256', 'MASK|v1|' . $machine, LICENSE_SECRET, true))[1];
}

/** 10 بايتات ← 16 حرفاً Base32. */
function license_base32_encode(string $bytes): string
{
    $bits = '';
    foreach (str_split($bytes) as $b) {
        $bits .= str_pad(decbin(ord($b)), 8, '0', STR_PAD_LEFT);
    }
    $out = '';
    foreach (str_split($bits, 5) as $chunk) {
        $out .= LICENSE_ALPHABET[bindec(str_pad($chunk, 5, '0'))];
    }
    return $out;
}

/** 16 حرفاً Base32 ← 10 بايتات، أو null. O تُقرأ 0، و I و L تُقرأ 1 (أخطاء النسخ اليدوي). */
function license_base32_decode(string $text): ?string
{
    $text = strtr(strtoupper($text), ['O' => '0', 'I' => '1', 'L' => '1']);
    if (strlen($text) !== 16) {
        return null;
    }
    $bits = '';
    foreach (str_split($text) as $ch) {
        $v = strpos(LICENSE_ALPHABET, $ch);
        if ($v === false) {
            return null;
        }
        $bits .= str_pad(decbin($v), 5, '0', STR_PAD_LEFT);
    }
    $bytes = '';
    foreach (str_split($bits, 8) as $byte) {
        $bytes .= chr(bindec($byte));
    }
    return $bytes;
}

/** مفتاح التفعيل لكود جهاز ومدة (tools/keygen.php). */
function license_make_key(string $machine, string $term): string
{
    $days = $term === 'lifetime' ? 0 : license_days($term);
    $raw = pack('n', $days ^ license_mask($machine)) . license_mac($machine, $term);
    return 'ACT-' . implode('-', str_split(license_base32_encode($raw), 4));
}

/** يفك المفتاح ويتحقق أنه صادر لهذا الكود. @return ?string المدة ("lifetime" أو YYYY-MM-DD)، أو null. */
function license_check_key(string $key, string $machine): ?string
{
    $text = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $key) ?? '');
    if (strlen($text) === 19 && strpos($text, 'ACT') === 0) {
        $text = substr($text, 3);
    }
    $raw = license_base32_decode($text);
    if ($raw === null) {
        return null;
    }
    $days = unpack('n', substr($raw, 0, 2))[1] ^ license_mask($machine);
    $term = $days === 0 ? 'lifetime' : (new DateTimeImmutable(LICENSE_EPOCH))->modify('+' . $days . ' days')->format('Y-m-d');
    return hash_equals(license_mac($machine, $term), substr($raw, 2)) ? $term : null;
}

function license_file_mac(array $f): string
{
    return hash_hmac('sha256', 'FILE|v1|' . $f['key'] . '|' . $f['machine'] . '|' . $f['term'] . '|' . $f['activated_at'] . '|' . $f['last_seen'], LICENSE_SECRET);
}

function license_write(array $f): bool
{
    $f['mac'] = license_file_mac($f);
    $tmp = license_path() . '.tmp';
    if (@file_put_contents($tmp, json_encode($f, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n", LOCK_EX) === false) {
        return false;
    }
    if (!@rename($tmp, license_path())) {
        @unlink(license_path());
        return @rename($tmp, license_path());
    }
    return true;
}

/**
 * حالة الترخيص على هذا الجهاز (مرة واحدة لكل طلب).
 * state: ok | missing (لم يُفعَّل) | mismatch (الترخيص لجهاز آخر) | expired | invalid (ملف تالف أو معدَّل) | hwid (تعذرت قراءة البصمة)
 * $reload: إعادة الفحص بعد تفعيل في الطلب نفسه.
 * @return array{state:string, machine:?string, term:?string, days_left:?int, licensed_machine:?string, error:?string}
 */
function license_status(bool $mayRefresh = true, bool $reload = false): array
{
    static $memo = null;
    if ($memo !== null && !$reload) {
        return $memo;
    }
    $hw = hwid_machine_code($mayRefresh);
    $out = ['state' => 'missing', 'machine' => $hw['code'], 'term' => null, 'days_left' => null, 'licensed_machine' => null, 'error' => $hw['error']];
    $path = license_path();
    if (!is_file($path)) {
        return $memo = $hw['code'] === null ? ['state' => 'hwid'] + $out : $out;
    }
    $f = json_decode((string) @file_get_contents($path), true);
    if (!is_array($f) || !isset($f['key'], $f['machine'], $f['term'], $f['activated_at'], $f['last_seen'], $f['mac'])
        || !hash_equals(license_file_mac($f), (string) $f['mac'])) {
        return $memo = ['state' => 'invalid'] + $out;
    }
    $out['licensed_machine'] = (string) $f['machine'];
    if ($hw['code'] === null) {
        return $memo = ['state' => 'hwid'] + $out;
    }
    $term = license_check_key((string) $f['key'], $hw['code']);
    if ($term === null) {
        return $memo = ['state' => 'mismatch'] + $out;
    }
    $out['term'] = $term;
    if ($term !== 'lifetime') {
        $today = date('Y-m-d');
        $effective = max($today, (string) $f['last_seen']);
        if ($today > (string) $f['last_seen']) {
            $f['last_seen'] = $today;
            license_write($f);
        }
        $out['days_left'] = (int) (new DateTimeImmutable($effective))->diff(new DateTimeImmutable($term))->format('%r%a');
        if ($effective > $term) {
            return $memo = ['state' => 'expired'] + $out;
        }
    }
    return $memo = ['state' => 'ok'] + $out;
}

/** يفعّل مفتاحاً لهذا الجهاز. @return ?string رسالة الخطأ، أو null عند النجاح. */
function license_activate(string $key): ?string
{
    $hw = hwid_machine_code(true);
    if ($hw['code'] === null) {
        return $hw['error'];
    }
    if (trim($key) === '') {
        return 'أدخل مفتاح التفعيل.';
    }
    $term = license_check_key($key, $hw['code']);
    if ($term === null) {
        return 'مفتاح التفعيل غير صحيح لهذا الجهاز. تأكد أنك أرسلت للمطور الكود ' . $hw['code'] . ' وانسخ المفتاح كما وصلك.';
    }
    $today = date('Y-m-d');
    $previous = is_file(license_path()) ? json_decode((string) @file_get_contents(license_path()), true) : null;
    $lastSeen = is_array($previous) && isset($previous['last_seen']) && valid_date((string) $previous['last_seen']) ? max($today, (string) $previous['last_seen']) : $today;
    if ($term !== 'lifetime' && $lastSeen > $term) {
        return 'هذا المفتاح انتهت صلاحيته في ' . $term . '. اطلب مفتاحاً جديداً من المطور.';
    }
    $text = strtr(strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $key) ?? ''), ['O' => '0', 'I' => '1', 'L' => '1']);
    $text = strlen($text) === 19 ? substr($text, 3) : $text;
    $f = ['key' => 'ACT-' . implode('-', str_split($text, 4)), 'machine' => $hw['code'], 'term' => $term,
          'activated_at' => date('Y-m-d H:i:s'), 'last_seen' => $lastSeen];
    if (!license_write($f)) {
        return 'تعذر حفظ الترخيص في ' . license_path() . '. تأكد أن البرنامج يملك صلاحية الكتابة في مجلد config.';
    }
    return null;
}

/** وصف المدة للعرض. */
function license_term_label(?string $term): string
{
    return $term === null ? '—' : ($term === 'lifetime' ? 'مدى الحياة' : 'حتى ' . $term);
}

/**
 * بوابة الترخيص قبل أي شيء آخر: بلا ترخيص صالح تُحوَّل الصفحات إلى activate.php، وترد طلبات API بـ 403
 * ومعها كود الجهاز. طلبات API لا تقرأ WMI بسبب مرور الوقت وحده (hwid_machine_code).
 */
function license_require(): void
{
    $status = license_status(!defined('APP_API'));
    if ($status['state'] === 'ok') {
        return;
    }
    if (defined('APP_API')) {
        json_error('البرنامج غير مفعّل على هذا الجهاز. كود الجهاز: ' . ($status['machine'] ?? '—'), 403,
            ['code' => 'license', 'state' => $status['state'], 'machine_code' => $status['machine']]);
    }
    header('Location: activate.php');
    exit;
}
