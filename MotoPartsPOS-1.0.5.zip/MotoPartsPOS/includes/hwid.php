<?php
/**
 * بصمة الجهاز (كود الجهاز) لترخيص البرنامج: MOTO-XXXX-XXXX-XXXX.
 *
 * المصادر من Windows عبر PowerShell (WMI)، وإن تعذر PowerShell فعبر wmic:
 *   - UUID اللوحة الأم (Win32_ComputerSystemProduct) + معرّف المعالج ProcessorId (Win32_Processor).
 *   - إن كان UUID فارغاً أو قيمة مصنع معروفة (أصفار، FFFF…): الرقم التسلسلي للقرص الأول (Win32_DiskDrive) بدلاً منه.
 *   - إن فشلت القراءتان: الرقم التسلسلي لقسم النظام (vol C:)، وهو متاح دائماً.
 * القيم تُطبَّع (أحرف كبيرة بلا مسافات) ثم SHA-256، وأول 12 خانة hex هي الكود.
 *
 * قراءة WMI تأخذ ثانيتين إلى عدة ثوانٍ على الأجهزة البطيئة، فالكود يُحفظ في storage/hwid.json ويُعاد حسابه:
 *   - فوراً إن تغيّر اسم الجهاز أو كان الملف معدَّلاً (نسخ مجلد البرنامج لجهاز آخر يُكشف في أول طلب)،
 *   - ومرة كل HWID_CACHE_SECONDS في طلب صفحة (لا في طلب API، فلا يتأخر حفظ فاتورة).
 * فشل القراءة لا يغيّر الكود المحفوظ: لا يُقفل البرنامج بسبب تعثر مؤقت في WMI.
 */

const HWID_CACHE_SECONDS = 43200;     // 12 ساعة
const HWID_READ_TIMEOUT = 25;         // ثانية: PowerShell على Core2Duo قد يأخذ عدة ثوانٍ في أول تشغيل
const HWID_BOGUS = [
    '', 'NONE', 'NULL', 'DEFAULT STRING', 'TO BE FILLED BY O.E.M.', 'SYSTEM SERIAL NUMBER',
    '00000000-0000-0000-0000-000000000000', 'FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF',
    '03000200-0400-0500-0006-000700080009', '0000000000000000',
];

/** قيمة من WMI بعد التطبيع، أو '' إن كانت فارغة أو قيمة مصنع لا تميّز جهازاً. */
function hwid_clean(?string $value): string
{
    $norm = function (string $s): string { return strtoupper(preg_replace('/[^0-9A-Za-z\-]/', '', $s) ?? ''); };
    $v = $norm((string) $value);
    if (in_array($v, array_map($norm, HWID_BOGUS), true) || preg_match('/^[0F\-]+$/', $v) || preg_match('/^(.)\1+$/', str_replace('-', '', $v))) {
        return '';
    }
    return $v;
}

/**
 * يشغّل أمراً بلا cmd.exe، بمهلة. @return ?string المخرجات، أو null إن فشل أو تجاوز المهلة.
 * المخرجات إلى ملف مؤقت لا إلى pipe: قراءة pipe على Windows لا تكون غير حاجبة، فلا تعمل المهلة معها.
 */
function hwid_run(array $command, int $timeout = HWID_READ_TIMEOUT): ?string
{
    if (!function_exists('proc_open')) {
        return null;
    }
    $out = storage_path('tmp') . '/hwid-' . bin2hex(random_bytes(6)) . '.txt';
    $null = stripos(PHP_OS, 'WIN') === 0 ? 'NUL' : '/dev/null';
    $proc = @proc_open($command, [0 => ['file', $null, 'r'], 1 => ['file', $out, 'w'], 2 => ['file', $null, 'w']], $pipes, null, null, ['bypass_shell' => true]);
    if (!is_resource($proc)) {
        @unlink($out);
        return null;
    }
    $deadline = microtime(true) + $timeout;
    while (proc_get_status($proc)['running']) {
        if (microtime(true) > $deadline) {
            proc_terminate($proc);
            proc_close($proc);
            @unlink($out);
            return null;
        }
        usleep(50000);
    }
    proc_close($proc);
    $text = @file_get_contents($out);
    @unlink($out);
    return $text === false ? null : $text;
}

/** مسار برنامج نظام في System32 (PHP 64-bit فلا تحويل لـ SysWOW64). */
function hwid_system_exe(string $relative): string
{
    $root = getenv('SystemRoot') ?: getenv('windir') ?: 'C:\\Windows';
    return rtrim($root, '\\/') . '\\System32\\' . $relative;
}

/** @return array{uuid:string, cpu:string, disk:string, volume:string, method:string} */
function hwid_read_sources(): array
{
    $src = ['uuid' => '', 'cpu' => '', 'disk' => '', 'volume' => '', 'method' => ''];
    if (stripos(PHP_OS, 'WIN') !== 0) {
        // ليس Windows (لا يحدث في المحل): معرّف النظام إن وُجد.
        $id = @file_get_contents('/etc/machine-id') ?: (string) php_uname('n');
        $src['volume'] = hwid_clean($id);
        $src['method'] = 'machine-id';
        return $src;
    }

    // Get-CimInstance (PowerShell 3+، ومنه Windows 8.1) وإلا Get-WmiObject. المخرجات سطر لكل قيمة.
    $ps = '$ErrorActionPreference="SilentlyContinue";'
        . 'function Q($c){ try { Get-CimInstance -ClassName $c -ErrorAction Stop } catch { Get-WmiObject -Class $c } };'
        . '"UUID=" + (Q Win32_ComputerSystemProduct | Select-Object -First 1).UUID;'
        . '"CPU=" + (Q Win32_Processor | Select-Object -First 1).ProcessorId;'
        . '"DISK=" + (Q Win32_DiskDrive | Sort-Object Index | Select-Object -First 1).SerialNumber;'
        . '"END=1"';
    $out = hwid_run([hwid_system_exe('WindowsPowerShell\\v1.0\\powershell.exe'), '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', $ps]);
    if ($out !== null && strpos($out, 'END=1') !== false) {
        foreach (preg_split('/\R/', $out) as $line) {
            if (preg_match('/^(UUID|CPU|DISK)=(.*)$/', trim($line), $m)) {
                $src[strtolower($m[1])] = hwid_clean($m[2]);
            }
        }
        $src['method'] = 'powershell';
    } else {
        $wmic = function (string $alias, string $field): string {
            $out = hwid_run([hwid_system_exe('wbem\\WMIC.exe'), $alias, 'get', $field, '/value']);
            return $out !== null && preg_match('/' . $field . '=([^\r\n]*)/i', $out, $m) ? hwid_clean($m[1]) : '';
        };
        $src['uuid'] = $wmic('csproduct', 'UUID');
        $src['cpu'] = $wmic('cpu', 'ProcessorId');
        $src['disk'] = $wmic('diskdrive', 'SerialNumber');
        $src['method'] = ($src['uuid'] . $src['cpu'] . $src['disk']) !== '' ? 'wmic' : '';
    }
    if ($src['uuid'] === '' && $src['disk'] === '') {
        // آخر حل: الرقم التسلسلي لقسم النظام ("Volume Serial Number is 1A2B-3C4D").
        $drive = getenv('SystemDrive') ?: 'C:';
        $out = hwid_run([hwid_system_exe('cmd.exe'), '/c', 'vol', $drive], 10);
        if ($out !== null && preg_match('/([0-9A-F]{4}-[0-9A-F]{4})\s*$/i', trim($out), $m)) {
            $src['volume'] = hwid_clean($m[1]);
            $src['method'] .= ($src['method'] !== '' ? '+' : '') . 'vol';
        }
    }
    return $src;
}

/** الكود من المصادر: UUID + المعالج، وبديل UUID القرص، وآخر حل قسم النظام. null = لا شيء يميّز الجهاز. */
function hwid_code_from(array $src): ?string
{
    $parts = [];
    if ($src['uuid'] !== '') {
        $parts[] = 'U:' . $src['uuid'];
    } elseif ($src['disk'] !== '') {
        $parts[] = 'D:' . $src['disk'];
    }
    if ($src['cpu'] !== '') {
        $parts[] = 'C:' . $src['cpu'];
    }
    if (!$parts && $src['volume'] !== '') {
        $parts[] = 'V:' . $src['volume'];
    }
    if (!$parts) {
        return null;
    }
    $hex = strtoupper(substr(hash('sha256', 'MotoPartsPOS|HWID|v1|' . implode('|', $parts)), 0, 12));
    return 'MOTO-' . implode('-', str_split($hex, 4));
}

function hwid_cache_path(): string
{
    return storage_path() . '/hwid.json';
}

function hwid_cache_mac(array $c): string
{
    return hash_hmac('sha256', 'hwid|' . $c['code'] . '|' . $c['host'] . '|' . $c['at'], LICENSE_SECRET);
}

/**
 * كود هذا الجهاز. $mayRefresh = false (طلبات API): لا قراءة WMI بسبب مرور الوقت وحده.
 * $force: قراءة WMI الآن مهما كان المحفوظ. $reload: تجاهل نتيجة سابقة في الطلب نفسه.
 * @return array{code: ?string, error: ?string, fresh: bool}
 */
function hwid_machine_code(bool $mayRefresh = true, bool $force = false, bool $reload = false): array
{
    static $memo = null;
    if ($memo !== null && !$force && !$reload) {
        return $memo;
    }
    $host = strtoupper((string) (gethostname() ?: php_uname('n')));
    $path = hwid_cache_path();
    $cache = is_file($path) ? json_decode((string) @file_get_contents($path), true) : null;
    $valid = is_array($cache) && isset($cache['code'], $cache['host'], $cache['at'], $cache['mac'])
        && hash_equals(hwid_cache_mac($cache), (string) $cache['mac']);
    $sameHost = $valid && $cache['host'] === $host;
    $stale = !$valid || time() - (int) $cache['at'] > HWID_CACHE_SECONDS || (int) $cache['at'] > time() + 86400;
    if ($sameHost && !$force && (!$stale || !$mayRefresh)) {
        return $memo = ['code' => (string) $cache['code'], 'error' => null, 'fresh' => false];
    }

    $code = hwid_code_from(hwid_read_sources());
    if ($code === null) {
        // تعثر مؤقت: الكود المحفوظ لهذا الجهاز نفسه يبقى صالحاً.
        if ($sameHost) {
            return $memo = ['code' => (string) $cache['code'], 'error' => null, 'fresh' => false];
        }
        return $memo = ['code' => null, 'error' => 'تعذر قراءة بصمة هذا الجهاز من Windows (WMI). أعد تشغيل الجهاز ثم افتح البرنامج مرة أخرى.', 'fresh' => true];
    }
    $new = ['code' => $code, 'host' => $host, 'at' => time()];
    $new['mac'] = hwid_cache_mac($new);
    @file_put_contents($path, json_encode($new), LOCK_EX);
    return $memo = ['code' => $code, 'error' => null, 'fresh' => true];
}
