<?php
/**
 * نقطة البداية لكل صفحة وكل API: الإعدادات، تسجيل الأخطاء، والدوال المشتركة، وفحص تسجيل الدخول.
 */
defined('APP_ROOT') || define('APP_ROOT', dirname(__DIR__));

require_once APP_ROOT . '/config/db.php';
require_once __DIR__ . '/helpers.php';

error_reporting(E_ALL);
// XAMPP يشغّل display_errors=On افتراضياً، وأي تحذير مطبوع يكسر ردود JSON؛ نسجّل الأخطاء في ملف بدلاً من ذلك.
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', APP_ROOT . '/storage/logs/php-errors.log');

// قبل أي شيء: ترخيص هذا الجهاز (includes/license.php). بلا ترخيص صالح تُحوَّل كل صفحة إلى activate.php
// ويرد كل API بـ 403 ومعه كود الجهاز. المستثنى فقط ما عرّف LICENSE_EXEMPT (شاشة التفعيل نفسها) وسطر الأوامر.
require_once __DIR__ . '/license.php';
if (PHP_SAPI !== 'cli' && !defined('LICENSE_EXEMPT')) {
    license_require();
}

// كل صفحة وكل API تتطلب تسجيل الدخول، إلا ملفاً عرّف PUBLIC_PAGE قبل هذا الملف.
// سطر الأوامر مستثنى: أدوات tools/ و install.php الذي يشغّله برنامج التثبيت.
require_once __DIR__ . '/auth.php';
if (PHP_SAPI !== 'cli' && !defined('PUBLIC_PAGE')) {
    auth_require();
}
