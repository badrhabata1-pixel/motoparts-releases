/*
 * شاشة التفعيل: نسخ كود الجهاز، تنسيق المفتاح أثناء الكتابة (ACT-XXXX-XXXX-XXXX-XXXX)، منع الضغط المزدوج،
 * الانتقال لتسجيل الدخول بعد نجاح التفعيل، والوضع الليلي. التحقق كله في الخادم (activate.php).
 */
(function () {
  'use strict';

  var code = document.getElementById('machineCode');
  var copyBtn = document.getElementById('copyCode');
  var copied = document.getElementById('copied');
  var form = document.getElementById('activateForm');
  var keyInput = document.getElementById('key');
  var submit = document.getElementById('activateSubmit');

  function fallbackCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (e) { /* يبقى النص محدداً للنسخ اليدوي */ }
    document.body.removeChild(ta);
  }

  copyBtn.addEventListener('click', function () {
    var text = code.textContent.trim();
    var done = function () {
      copied.hidden = false;
      clearTimeout(copyBtn._t);
      copyBtn._t = setTimeout(function () { copied.hidden = true; }, 2500);
    };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done, function () { fallbackCopy(text); done(); });
    } else {
      fallbackCopy(text);
      done();
    }
  });

  // الحروف كبيرة، ومجموعات من 4 بشرطة. "ACT" تُضاف تلقائياً.
  if (keyInput) {
    keyInput.addEventListener('input', function () {
      var raw = keyInput.value.toUpperCase().replace(/[^0-9A-Z]/g, '');
      if (raw.indexOf('ACT') === 0) raw = raw.slice(3);
      raw = raw.slice(0, 16);
      keyInput.value = raw ? 'ACT-' + raw.match(/.{1,4}/g).join('-') : '';
    });
  }

  if (form) {
    form.addEventListener('submit', function (e) {
      if (submit.disabled) {
        e.preventDefault();
        return;
      }
      submit.disabled = true;
      submit.textContent = 'جارٍ التحقق…';
    });
    window.addEventListener('pageshow', function () {
      submit.disabled = code.textContent.trim() === '—';
      submit.textContent = 'تفعيل البرنامج 🔓';
    });
  }

  var next = document.body.getAttribute('data-redirect');
  if (next) setTimeout(function () { location.href = next; }, 1800);

  document.addEventListener('click', function (e) {
    if (!e.target.closest('[data-action="toggle-theme"]')) return;
    var dark = document.documentElement.getAttribute('data-theme') !== 'dark';
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    try { localStorage.setItem('mp_theme', JSON.stringify(dark ? 'dark' : 'light')); } catch (err) { /* التخزين معطّل */ }
  });
})();
