<?php defined('IN_APP') || exit; ?>
<div class="labels-layout">
  <section class="card">
    <div class="card__head">
      <h2 class="card__title"><svg class="icon"><use href="#i-printer"/></svg> طباعة ملصقات الباركود</h2>
      <span class="muted small" id="listSummary"></span>
    </div>
    <div class="card__body stack">
      <div class="toolbar toolbar--inner">
        <label class="search-field">
          <svg class="icon"><use href="#i-search"/></svg>
          <input id="pickSearch" class="input" type="search" autocomplete="off" spellcheck="false"
                 placeholder="ابحث بالاسم أو امسح باركود صنف لإضافته إلى قائمة الطباعة">
        </label>
        <select id="pickFilter" class="input select" aria-label="تصفية الأصناف">
          <option value="all">كل الأصناف</option>
          <option value="quick">الوصول السريع [F3]</option>
          <option value="fast">الأكثر مبيعاً [F1]</option>
          <option value="unbarcoded">أصناف بدون باركود</option>
          <option value="barcoded">بباركود (عليها ملصق)</option>
          <option value="low">منخفض المخزون</option>
          <option value="negative">رصيد سالب</option>
          <option value="zero_price">سعر البيع 0.00</option>
        </select>
      </div>
      <div class="bulk-bar">
        <button class="btn btn--lg btn--bulk" type="button" data-action="add-all" disabled>
          <span data-bulk-label>إضافة كل بضاعة المخزن للطباعة 📦</span> <span class="badge badge--ok" data-bulk-count>…</span>
        </button>
        <span class="muted small" id="bulkScope"></span>
      </div>
      <div id="pickResults" class="stack-sm" hidden></div>
      <div class="table-wrap table-wrap--tall">
        <table class="grid grid--compact">
          <thead>
            <tr>
              <th>الباركود</th>
              <th>الصنف</th>
              <th class="num">السعر</th>
              <th class="num">الرصيد</th>
              <th class="num">عدد النسخ</th>
              <th></th>
            </tr>
          </thead>
          <tbody id="labelList">
            <tr><td colspan="6" class="empty">لم تُختر أصناف بعد. ابحث عن صنف أو امسح باركوده، أو أضف كل الأصناف بالزر أعلاه.</td></tr>
          </tbody>
        </table>
      </div>
      <div class="btn-row">
        <button class="btn btn--ghost btn--sm" type="button" data-action="clear-list">تفريغ القائمة</button>
      </div>
    </div>
  </section>

  <aside class="card">
    <div class="card__head"><h2 class="card__title">إعدادات الطباعة</h2></div>
    <form class="card__body stack" id="labelSettings" novalidate>
      <label class="field">
        <span class="field__label">الورق والمقاس</span>
        <select class="input select" name="preset"></select>
      </label>
      <!-- خيار "رول Xprinter (مضبوط 38×25)" (xprinter_38x25) من قائمة المقاسات في assets/js/barcode.js -->
      <p class="muted small" data-autorotate-hint hidden>تُرسل الصفحة 25×38 مم عمودية كما هي، بلا أي تدوير من البرنامج، وطابعة Xprinter تديرها تلقائياً لتناسب ملصق 38×25.</p>
      <label class="field">
        <span class="field__label">دقة الطابعة</span>
        <select class="input select" name="dpi"></select>
      </label>
      <div class="form-grid" data-custom-size hidden>
        <label class="field"><span class="field__label">العرض (مم)</span><input class="input" name="w" inputmode="decimal"></label>
        <label class="field"><span class="field__label">الارتفاع (مم)</span><input class="input" name="h" inputmode="decimal"></label>
      </div>
      <fieldset class="fieldset field">
        <legend class="field__label">محتوى الملصق</legend>
        <div class="checks">
          <label class="check"><input type="checkbox" name="showName"> <span>اسم الصنف</span></label>
          <label class="check"><input type="checkbox" name="showPrice"> <span>السعر</span></label>
          <label class="check"><input type="checkbox" name="showCode"> <span>رقم الباركود</span></label>
        </div>
      </fieldset>
      <div class="field">
        <span class="field__label">عدد النسخ لكل الأصناف</span>
        <div class="segmented" role="radiogroup">
          <label title="نسخة واحدة لكل صنف"><input type="radio" name="copyMode" value="one"> <span>واحدة</span></label>
          <label title="ملصق لكل قطعة في المخزون"><input type="radio" name="copyMode" value="stock"> <span>بالرصيد</span></label>
          <label title="العدد نفسه لكل صنف"><input type="radio" name="copyMode" value="fixed"> <span>ثابت</span></label>
        </div>
        <input class="input" name="fixedCopies" inputmode="numeric" value="2" aria-label="العدد الثابت" hidden>
      </div>
      <div class="form-grid">
        <label class="field"><span class="field__label">إزاحة أفقية (مم)</span><input class="input" name="offsetX" inputmode="decimal"></label>
        <label class="field"><span class="field__label">إزاحة رأسية (مم)</span><input class="input" name="offsetY" inputmode="decimal"></label>
      </div>
      <div id="labelWarnings" class="stack-sm"></div>
      <p class="muted" id="printSummary"></p>
      <label class="field" id="batchField" hidden>
        <span class="field__label">دفعة الطباعة</span>
        <select class="input select" id="printBatch"></select>
      </label>
      <button class="btn btn--primary btn--xl" type="button" data-action="print"><svg class="icon"><use href="#i-printer"/></svg> <span data-print-label>طباعة</span></button>
      <details>
        <summary>إعدادات نافذة الطباعة</summary>
        <ul class="small">
          <li>اختر طابعة الملصقات، أو الطابعة العادية لورق A4.</li>
          <li>الهوامش: <strong>بلا (None)</strong>، والمقياس: <strong>100%</strong> أو "الافتراضي".</li>
          <li>ألغِ "الرؤوس والتذييلات" (Headers and footers).</li>
          <li>اطبع ملصقاً واحداً أولاً وجرّب قراءته بالماسح، ثم صحّح الإزاحة إن لزم.</li>
        </ul>
      </details>
    </form>
  </aside>
</div>

<section class="card">
  <div class="card__head">
    <h2 class="card__title">المعاينة بالمقاس الحقيقي</h2>
    <span class="muted small" id="previewNote"></span>
  </div>
  <div class="card__body">
    <div id="labelPreview" class="preview-area"><p class="empty">أضف أصنافاً لترى الملصقات هنا.</p></div>
  </div>
</section>
