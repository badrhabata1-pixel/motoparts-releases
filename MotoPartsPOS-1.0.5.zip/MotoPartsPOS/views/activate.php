<?php
defined('APP_ROOT') || exit;
/* شاشة تفعيل البرنامج. المتغيرات من activate.php: $status (license_status) و $error و $activated و $key و $csrf. */
$machine = $status['machine'];
$messages = [
    'missing'  => ['warn', 'هذه النسخة غير مفعّلة على هذا الجهاز. البرنامج يعمل بعد إدخال مفتاح تفعيل خاص بكود هذا الجهاز.'],
    'mismatch' => ['danger', 'الترخيص المحفوظ صادر لجهاز آخر (' . ($status['licensed_machine'] ?? '—') . '). كل جهاز يحتاج مفتاحاً خاصاً بكوده.'],
    'expired'  => ['danger', 'انتهت صلاحية الترخيص في ' . ($status['term'] ?? '') . '. أرسل كود الجهاز للمطور لتجديده.'],
    'invalid'  => ['danger', 'ملف الترخيص تالف أو معدَّل. أدخل مفتاح التفعيل مرة أخرى.'],
    'hwid'     => ['danger', (string) ($status['error'] ?? 'تعذر قراءة بصمة هذا الجهاز.')],
];
$left = $status['days_left'];
$termText = license_term_label($status['term']) . ($left !== null && $left >= 0 ? ' (بقي ' . $left . ' يوم)' : '');
?>
<!doctype html>
<html lang="ar" dir="rtl" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>تفعيل البرنامج — <?= h(APP_NAME) ?></title>
<link rel="icon" href="data:,">
<link rel="stylesheet" href="<?= h(asset('assets/css/style.css')) ?>">
<link rel="stylesheet" href="<?= h(asset('assets/css/login.css')) ?>">
<script>
(function () {
  try {
    var saved = JSON.parse(localStorage.getItem('mp_theme') || 'null');
    var dark = saved ? saved === 'dark' : !!(window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
  } catch (e) {}
})();
</script>
</head>
<body class="page-login"<?= $activated ? ' data-redirect="login.php"' : '' ?>>
<svg class="sprite" aria-hidden="true" focusable="false">
  <symbol id="i-key" viewBox="0 0 24 24"><circle cx="8" cy="15" r="4"/><path d="M10.8 12.2L20 3M16 7l3 3M14 9l2 2"/></symbol>
  <symbol id="i-sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></symbol>
  <symbol id="i-moon" viewBox="0 0 24 24"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></symbol>
</svg>

<main class="login login--wide">
  <section class="login__card" aria-labelledby="activateTitle">
    <div class="login__brand">
      <span class="brand__mark login__mark" aria-hidden="true">MP</span>
      <div>
        <div class="login__app"><?= h(APP_NAME) ?></div>
        <div class="login__sub">نقطة البيع والمخزون</div>
      </div>
    </div>

    <h1 id="activateTitle" class="login__title"><?= $status['state'] === 'ok' && !$activated ? 'ترخيص البرنامج' : 'تفعيل البرنامج' ?></h1>

    <?php if ($activated): ?>
      <div class="alert alert--ok login__alert activate__done" role="status">
        <strong>تم تفعيل البرنامج بنجاح ✓</strong> — <?= h($termText) ?>.<br>
        جارٍ الانتقال إلى تسجيل الدخول… <a href="login.php">انتقل الآن</a>
      </div>
    <?php elseif ($status['state'] === 'ok'): ?>
      <div class="alert alert--ok login__alert" role="status">البرنامج مفعّل على هذا الجهاز — <?= h($termText) ?>.
        <a href="index.php">متابعة إلى البرنامج</a></div>
    <?php else: ?>
      <div class="alert alert--<?= $messages[$status['state']][0] ?> login__alert" role="alert"><?= h($messages[$status['state']][1]) ?></div>
    <?php endif; ?>
    <?php if ($error !== null): ?>
      <div class="alert alert--danger login__alert" role="alert" id="activateError"><?= h($error) ?></div>
    <?php endif; ?>

    <div class="field">
      <span class="field__label">كود الجهاز — أرسله للمطور</span>
      <div class="activate__code">
        <code id="machineCode" dir="ltr"><?= h($machine ?? '—') ?></code>
        <button class="btn" type="button" id="copyCode"<?= $machine === null ? ' disabled' : '' ?>>نسخ الكود 📋</button>
      </div>
      <span class="activate__copied" id="copied" role="status" hidden>نُسخ الكود ✓</span>
    </div>

    <?php if (!$activated): ?>
      <form id="activateForm" class="login__form activate__form" method="post" action="activate.php" autocomplete="off">
        <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
        <div class="field">
          <label class="field__label" for="key"><?= $status['state'] === 'ok' ? 'مفتاح جديد (تجديد أو تغيير الترخيص)' : 'مفتاح التفعيل الذي وصلك' ?></label>
          <span class="login__control">
            <svg class="icon"><use href="#i-key"/></svg>
            <input class="input mono activate__key" id="key" name="key" type="text" dir="ltr" maxlength="40" spellcheck="false" autocapitalize="characters"
                   placeholder="ACT-XXXX-XXXX-XXXX-XXXX" value="<?= h($key) ?>"<?= $status['state'] !== 'ok' && $machine !== null ? ' autofocus' : '' ?>>
          </span>
        </div>
        <button class="btn btn--primary btn--xl login__submit" id="activateSubmit" type="submit"<?= $machine === null ? ' disabled' : '' ?>>تفعيل البرنامج 🔓</button>
      </form>
    <?php endif; ?>

    <div class="login__foot">
      <span class="muted small">الإصدار <span class="mono"><?= h(APP_VERSION) ?></span></span>
      <button class="icon-btn" type="button" data-action="toggle-theme" title="الوضع الليلي" aria-label="تبديل الوضع الليلي">
        <svg class="icon icon--light"><use href="#i-moon"/></svg><svg class="icon icon--dark"><use href="#i-sun"/></svg>
      </button>
    </div>
  </section>
</main>
<script src="<?= h(asset('assets/js/activate.js')) ?>" defer></script>
</body>
</html>
