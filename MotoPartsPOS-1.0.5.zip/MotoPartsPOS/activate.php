<?php
/**
 * تفعيل البرنامج على هذا الجهاز (includes/license.php). الصفحة الوحيدة المتاحة بلا ترخيص: كل صفحة أخرى تُحوَّل إليها.
 * تعرض كود الجهاز لإرساله للمطور، وتقبل مفتاح التفعيل. بعد النجاح تنتقل إلى تسجيل الدخول.
 * والبرنامج مفعّل: تعرض حالة الترخيص، وتقبل مفتاحاً جديداً (تجديد ترخيص بتاريخ انتهاء).
 */
define('PUBLIC_PAGE', true);
define('LICENSE_EXEMPT', true);
require __DIR__ . '/includes/bootstrap.php';

if (!request_host_allowed()) {
    http_response_code(403);
    exit('Forbidden host');
}

$error = null;
$activated = false;
$key = '';
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $key = clean_text(is_string($_POST['key'] ?? null) ? $_POST['key'] : '', 60);
    $site = $_SERVER['HTTP_SEC_FETCH_SITE'] ?? '';
    if (($site !== '' && $site !== 'same-origin') || !auth_csrf_valid($_POST['csrf'] ?? null)) {
        $error = 'انتهت صلاحية الصفحة. أدخل المفتاح مرة أخرى ثم اضغط تفعيل البرنامج.';
    } else {
        $error = license_activate($key);
        $activated = $error === null;
    }
}

$status = license_status(true, $activated);

$csrf = auth_csrf_token();
require __DIR__ . '/views/activate.php';
