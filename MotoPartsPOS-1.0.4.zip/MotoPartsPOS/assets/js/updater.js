/*
 * فحص التحديث الصامت بعد نصف ثانية من فتح أي صفحة، في الخلفية دون أن يؤخر أي عملية بيع.
 * لا حظر يومي: إصدار يُرفع في منتصف اليوم يظهر عند فتح الصفحة التالية (الخادم يحفظ نتيجة الفحص دقيقة واحدة
 * فقط، updater/check_update.php). انقطاع الإنترنت حالة طبيعية: لا رسالة ولا خطأ.
 * عند وجود إصدار أحدث تظهر شارة في الشريط العلوي، والتثبيت لا يبدأ إلا بعد موافقة المستخدم.
 */
(function () {
  'use strict';

  var MP = window.MP;
  var badge = document.getElementById('updateBadge');
  if (!badge || !MP) return;
  MP.store.remove('mp_update_check');   // حظر الفحص اليومي في الإصدارات السابقة

  function show(info) {
    badge.hidden = false;
    badge.disabled = false;
    badge.textContent = 'تحديث ' + info.latest + ' متاح';
    badge.title = info.notes || 'اضغط للتثبيت';
    badge.onclick = function () { apply(info); };
  }

  function check() {
    MP.api.get('updater/check_update.php', null, { timeout: 20000 }).then(function (res) {
      if (res.available) show(res);
    }, function () { /* بلا إنترنت أو الخادم متوقف: يُعاد الفحص مع الصفحة التالية */ });
  }

  function apply(info) {
    var message = 'تثبيت الإصدار ' + info.latest + '؟\n\n' + (info.notes ? info.notes + '\n\n' : '') +
      'تُؤخذ نسخة احتياطية من قاعدة البيانات والملفات قبل التحديث، ولا تتأثر بيانات المبيعات.\n' +
      'لا تغلق البرنامج حتى تظهر رسالة الانتهاء.';
    if (!window.confirm(message)) return;
    badge.disabled = true;
    badge.textContent = 'جارٍ التحديث…';
    MP.api.post('updater/apply_update.php', { version: info.latest }, { timeout: 900000 }).then(function (res) {
      MP.toast('تم التحديث إلى الإصدار ' + res.version + '. ستُعاد تحميل الصفحة.', 'success');
      setTimeout(function () { location.reload(); }, 1500);
    }, function (err) {
      show(info);
      MP.toast(err.message, 'error', { duration: 15000 });
    });
  }

  setTimeout(function () {
    (window.requestIdleCallback || function (cb) { setTimeout(cb, 0); })(check, { timeout: 2000 });
  }, 500);
})();
