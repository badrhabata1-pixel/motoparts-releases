/*
 * التقارير: ملخص يوم أو فترة من - إلى، والأصناف المباعة ونقص المخزون، تُرسم في PHP (views/reports.php).
 * سجل الفواتير والمرتجعات والإلغاء في صفحة الفواتير (views/invoices.php).
 */
(function () {
  'use strict';

  var dateForm = document.getElementById('dateForm');
  var f = dateForm.elements;

  // يوم: تغيير التاريخ يعيد رسم التقرير فوراً. فترة: يُختار التاريخان ثم "عرض".
  // الحقول المخفية معطلة فلا تُرسل مع النموذج.
  function setMode(mode) {
    dateForm.querySelectorAll('[data-mode]').forEach(function (el) {
      var on = el.dataset.mode === mode;
      el.hidden = !on;
      el.querySelectorAll('input').forEach(function (input) { input.disabled = !on; });
    });
  }

  f.date.addEventListener('change', function () { dateForm.submit(); });
  dateForm.addEventListener('change', function (e) {
    if (e.target.name !== 'mode') return;
    setMode(e.target.value);
    if (e.target.value === 'range') f.date_from.focus();
    else dateForm.submit();
  });
  dateForm.addEventListener('submit', function () {
    f.mode.forEach(function (r) { r.disabled = true; });   // لا داعي لـ mode في الرابط: التواريخ تكفي
  });
})();
