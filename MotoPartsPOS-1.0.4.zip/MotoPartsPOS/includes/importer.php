<?php
/**
 * قراءة ملفات الاستيراد وتحديث الأسعار: اكتشاف صف العناوين والأعمدة، وتصنيف كل صف مع ذكر سبب أي تخطٍّ.
 * لا دمج تلقائي: الصف الجديد سجل مستقل دائماً، والصف الذي يطابق اسمه صنفاً في المخزن لا يُضاف إليه
 * إلا باختيار المستخدم الصريح في المعاينة (apply_import).
 */
require_once __DIR__ . '/spreadsheet.php';
require_once __DIR__ . '/inventory.php';

// 250 صفاً في الجملة الواحدة تبقيها تحت max_allowed_packet=1M في إعداد XAMPP الافتراضي.
const IMPORT_BATCH = 250;

/**
 * يدرج صفوف الاستيراد [الاسم، الكمية، سعر البيع، سعر الشراء] (مئات؛ السعر الغائب = 0.00) أصنافاً جديدة
 * بباركودات متسلسلة، ويسجل رصيدها الافتتاحي في stock_movements، ويعيد الباركودات بترتيب الصفوف.
 * يُستدعى داخل معاملة مفتوحة (allocate_barcodes يقفل صف التسلسل حتى نهايتها).
 * كل صف صنف مستقل حتى لو تكرر الاسم. يستخدمه api/import_excel.php و tools/import_pdf_items.php.
 *
 * @param array<int, array{0: string, 1: int, 2?: ?int, 3?: ?int}> $rows
 * @return string[]
 */
function insert_imported_rows(PDO $pdo, array $rows, int $minAlert, int $isBarcoded, string $note = ''): array
{
    $rows = array_values($rows);
    $codes = allocate_barcodes($pdo, count($rows));
    $alert = from_hundredths($minAlert);
    $statements = [];
    foreach (array_chunk(array_keys($rows), IMPORT_BATCH) as $keys) {
        $size = count($keys);
        if (!isset($statements[$size])) {
            $statements[$size] = $pdo->prepare(
                'INSERT INTO products (barcode, product_name, search_key, stock_quantity, buy_price, sell_price, is_barcoded, min_alert_qty) VALUES '
                . implode(',', array_fill(0, $size, '(?, ?, ?, ?, ?, ?, ?, ?)'))
            );
        }
        $params = [];
        foreach ($keys as $k) {
            $name = $rows[$k][0];
            array_push($params, $codes[$k], $name, normalize_search($name), from_hundredths($rows[$k][1]),
                from_hundredths($rows[$k][3] ?? 0), from_hundredths($rows[$k][2] ?? 0), $isBarcoded, $alert);
        }
        $statements[$size]->execute($params);

        // الرصيد الافتتاحي في دفتر الحركة، كإضافة صنف من شاشة المخزون.
        $batch = array_map(function ($k) use ($codes) { return $codes[$k]; }, $keys);
        $find = $pdo->prepare('SELECT barcode, id FROM products WHERE barcode IN (' . implode(',', array_fill(0, $size, '?')) . ')');
        $find->execute($batch);
        $ids = $find->fetchAll(PDO::FETCH_KEY_PAIR);
        foreach ($keys as $k) {
            if ($rows[$k][1] !== 0) {
                record_movement($pdo, (int) $ids[$codes[$k]], $rows[$k][1], $rows[$k][1], 'create', null, $note);
            }
        }
    }
    return $codes;
}

/**
 * الأصناف النشطة (is_active = 1) التي يطابق اسمها كل اسم في الملف بعد التطبيع (normalize_search): لا فرق بين
 * أ/إ/آ و ا، ولا ى و ي، ولا ة و ه، ولا بالتشكيل والمسافات الزائدة وحالة الحروف. فاختلاف همزة أو حرف لا يُضيّع التطابق.
 * قراءة واحدة للأصناف النشطة والمطابقة في الذاكرة؛ اسم الصنف يُطبَّع هنا (لا من search_key المخزَّن) فيشمل كل الأصناف.
 *
 * @param string[] $names
 * @return array<string, array<int, array{id:int, barcode:string, name:string, stock:string, sell_price:string, buy_price:string}>>
 */
function match_import_names(PDO $pdo, array $names): array
{
    $wanted = [];
    foreach (array_unique($names) as $name) {
        $key = normalize_search((string) $name);
        if ($key !== '') {
            $wanted[$key][] = $name;
        }
    }
    $out = [];
    if (!$wanted) {
        return $out;
    }
    $st = $pdo->query('SELECT id, barcode, product_name, stock_quantity, sell_price, buy_price FROM products WHERE is_active = 1 ORDER BY id');
    foreach ($st as $p) {
        $key = normalize_search((string) $p['product_name']);
        if (!isset($wanted[$key])) {
            continue;
        }
        $match = [
            'id' => (int) $p['id'], 'barcode' => (string) $p['barcode'], 'name' => (string) $p['product_name'],
            'stock' => (string) $p['stock_quantity'], 'sell_price' => (string) $p['sell_price'], 'buy_price' => (string) $p['buy_price'],
        ];
        foreach ($wanted[$key] as $name) {
            $out[$name][] = $match;
        }
    }
    return $out;
}

/**
 * ينفذ الاستيراد داخل معاملة مفتوحة. $rows: [المفتاح "ورقة:صف"، الاسم، الكمية، سعر البيع|null، سعر الشراء|null].
 * الصف بلا تطابق بالاسم = صنف جديد. الصف المتطابق يتبع اختيار المستخدم في $decisions[المفتاح]:
 *   add  = يُضاف الوارد إلى رصيد الصنف target ويُحدَّث سعره (الخلية الفارغة = السعر الحالي)، وحركة توريد.
 *   new  = صنف مستقل بباركود جديد بالاسم نفسه.
 *   skip = لا شيء.
 * المطابقة تُعاد هنا: أي اختلاف عن المعاينة (صنف أُضيف أو حُذف بالاسم نفسه) يرفض الاستيراد كله قبل أي كتابة.
 *
 * @return array{codes: string[], separate: int, added: int, price_updated: int, skipped: int, product_ids: int[]}
 */
function apply_import(PDO $pdo, array $rows, array $decisions, int $minAlert, int $isBarcoded, string $note): array
{
    $stale = 'تغيّر المخزون منذ المعاينة (صنف بالاسم نفسه أُضيف أو حُذف). أعد معاينة الملف.';
    $matches = match_import_names($pdo, array_column($rows, 1));
    $newRows = [];
    $adds = [];
    $separate = 0;
    $skipped = 0;
    foreach ($rows as [$key, $name, $qty, $sell, $buy]) {
        $found = $matches[$name] ?? [];
        $choice = $decisions[$key] ?? null;
        if (!$found) {
            if ($choice !== null) {
                throw new UserError($stale, 409);
            }
            $newRows[] = [$name, $qty, $sell, $buy];
            continue;
        }
        $action = is_array($choice) ? (string) ($choice['action'] ?? '') : '';
        if ($action === 'skip') {
            $skipped++;
        } elseif ($action === 'new') {
            $separate++;
            $newRows[] = [$name, $qty, $sell, $buy];
        } elseif ($action === 'add' && in_array((int) ($choice['target'] ?? 0), array_column($found, 'id'), true)) {
            $adds[] = [(int) $choice['target'], $qty, $sell, $buy];
        } else {
            throw new UserError($stale, 409);
        }
    }

    $codes = $newRows ? insert_imported_rows($pdo, $newRows, $minAlert, $isBarcoded, $note) : [];

    $priceUpdated = 0;
    $ids = array_values(array_unique(array_column($adds, 0)));
    if ($ids) {
        $lock = $pdo->prepare('SELECT id, stock_quantity, sell_price, buy_price FROM products
                                WHERE is_active = 1 AND id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') FOR UPDATE');
        $lock->execute($ids);
        $current = [];
        foreach ($lock as $p) {
            $current[(int) $p['id']] = [
                to_hundredths((string) $p['stock_quantity']) ?? 0, to_hundredths((string) $p['sell_price']) ?? 0, to_hundredths((string) $p['buy_price']) ?? 0,
            ];
        }
        if (count($current) !== count($ids)) {
            throw new UserError($stale, 409);
        }
        $update = $pdo->prepare('UPDATE products SET stock_quantity = ?, sell_price = ?, buy_price = ? WHERE id = ?');
        foreach ($adds as [$id, $qty, $sell, $buy]) {
            [$oldStock, $oldSell, $oldBuy] = $current[$id];
            $stock = $oldStock + $qty;
            $newSell = $sell ?? $oldSell;
            $newBuy = $buy ?? $oldBuy;
            $update->execute([from_hundredths($stock), from_hundredths($newSell), from_hundredths($newBuy), $id]);
            $current[$id] = [$stock, $newSell, $newBuy];

            $parts = [$note];
            if ($newSell !== $oldSell) {
                $parts[] = 'سعر البيع ' . from_hundredths($oldSell) . ' ← ' . from_hundredths($newSell);
            }
            if ($newBuy !== $oldBuy) {
                $parts[] = 'سعر الشراء ' . from_hundredths($oldBuy) . ' ← ' . from_hundredths($newBuy);
            }
            $priceChanged = count($parts) > 1;
            if ($priceChanged) {
                $priceUpdated++;
            }
            // الكمية الواردة توريد؛ صف بلا كمية وبسعر جديد يُسجَّل تعديل سعر بلا تغيير في الرصيد.
            if ($qty !== 0 || $priceChanged) {
                record_movement($pdo, $id, $qty, $stock, $qty !== 0 ? 'restock' : 'price', null, implode(' — ', array_filter($parts)));
            }
        }
    }

    return ['codes' => $codes, 'separate' => $separate, 'added' => count($adds), 'price_updated' => $priceUpdated,
            'skipped' => $skipped, 'product_ids' => $ids];
}

/** الكلمات تُطبَّع بنفس دالة البحث، فتطابق "الكمية" و"الكميه" و"الكميّة". */
function header_roles(string $kind): array
{
    static $cache = [];
    if (isset($cache[$kind])) {
        return $cache[$kind];
    }
    $n = function (array $words): array {
        return array_values(array_unique(array_map('normalize_search', $words)));
    };
    if ($kind === 'import') {
        $roles = [
            'name' => [
                'words'   => $n(['الصنف', 'اسم الصنف', 'الأصناف', 'البيان', 'بيان الصنف', 'الاسم', 'اسم', 'الوصف', 'صنف', 'item', 'product', 'name', 'description']),
                'exclude' => $n(['كود', 'رقم', 'باركود', 'code']),
            ],
            'qty' => [
                'words'   => $n(['الكمية', 'كمية', 'العدد', 'عدد', 'الكم', 'qty', 'quantity', 'count']),
                'exclude' => [],
            ],
            'sell' => [
                'words'   => $n(['سعر البيع', 'سعر بيع', 'سعر القطاعي', 'القطاعي', 'السعر', 'سعر', 'البيع', 'sell price', 'price', 'sell']),
                'exclude' => $n(['شراء', 'تكلفة', 'التكلفة', 'جملة', 'الجملة', 'اجمالي', 'إجمالي', 'buy', 'cost', 'total']),
            ],
            'buy' => [
                'words'   => $n(['سعر الشراء', 'سعر شراء', 'الشراء', 'شراء', 'التكلفة', 'تكلفة', 'buy price', 'buy', 'cost']),
                'exclude' => $n(['اجمالي', 'إجمالي', 'total']),
            ],
        ];
    } else {
        $roles = [
            'barcode' => [
                'words'   => $n(['الباركود', 'باركود', 'barcode', 'كود الصنف', 'الكود', 'كود', 'code', 'رقم الصنف']),
                'exclude' => [],
            ],
            'sell' => [
                'words'   => $n(['السعر الجديد', 'سعر البيع الجديد', 'سعر جديد', 'سعر البيع', 'السعر', 'سعر', 'new price', 'price', 'sell']),
                'exclude' => $n(['حالي', 'قديم', 'شراء', 'تكلفة', 'current', 'old', 'buy', 'cost']),
            ],
            'buy' => [
                'words'   => $n(['سعر الشراء الجديد', 'سعر الشراء', 'الشراء', 'التكلفة', 'تكلفة', 'buy', 'cost']),
                'exclude' => $n(['حالي', 'قديم', 'current', 'old']),
            ],
        ];
    }
    return $cache[$kind] = $roles;
}

/** يمر على الصفوف المخزّنة أولاً ثم يكمل المولّد، فتُقرأ الورقة مرة واحدة فقط. */
function iterate_rows(array $head, Generator $rest): Generator
{
    foreach ($head as $row) {
        yield $row;
    }
    while ($rest->valid()) {
        yield $rest->current();
        $rest->next();
    }
}

/** @return array{0: array, 1: Generator} أول 30 صفاً، وباقي المولّد */
function read_head(SpreadsheetReader $reader, int $sheet): array
{
    $gen = $reader->rows($sheet);
    $head = [];
    while ($gen->valid() && count($head) < 30) {
        $head[] = $gen->current();
        $gen->next();
    }
    return [$head, $gen];
}

/**
 * ورقة بلا صف عناوين: عمود الاسم = أكثر عمود نصي، والكمية = أول عمود رقمي بعده، وسعر البيع = العمود الرقمي التالي.
 * @return array{0: int, 1: ?int, 2: ?int}
 */
function guess_import_columns(array $head): array
{
    $text = [];
    $numeric = [];
    foreach ($head as [$rowNum, $cells]) {
        foreach ($cells as $col => $value) {
            if (to_hundredths((string) $value) !== null) {
                $numeric[$col] = ($numeric[$col] ?? 0) + 1;
            } else {
                $text[$col] = ($text[$col] ?? 0) + 1;
            }
        }
    }
    if (!$text) {
        return [0, $numeric ? min(array_keys($numeric)) : null, null];
    }
    arsort($text);
    $nameCol = (int) array_key_first($text);
    unset($numeric[$nameCol]);
    $after = array_values(array_filter(array_keys($numeric), function ($c) use ($nameCol) {
        return $c > $nameCol;
    }));
    sort($after);
    $qtyCol = $after ? $after[0] : ($numeric ? min(array_keys($numeric)) : null);
    return [$nameCol, $qtyCol, $after[1] ?? null];
}

/**
 * ورقة استيراد [الصنف، الكمية، سعر البيع، سعر الشراء]. $map اختيار المستخدم من المعاينة ويتقدم على الاكتشاف التلقائي.
 * عند $collect تُعاد الصفوف الصالحة نفسها: [الاسم، الكمية، سعر البيع|null، سعر الشراء|null، رقم الصف] بالمئات.
 * السعر null = خلية فارغة أو غير صالحة: الصنف الجديد يأخذ 0.00، والصنف المتطابق يبقى بسعره الحالي.
 */
function scan_import_sheet(SpreadsheetReader $reader, int $sheet, ?array $map, bool $collect): array
{
    [$head, $rest] = read_head($reader, $sheet);
    $detected = detect_header($head, header_roles('import'), ['name']);
    $headerRow = $detected['header_row'];
    $nameCol = $detected['columns']['name'];
    $qtyCol = $detected['columns']['qty'];
    $sellCol = $detected['columns']['sell'];
    $buyCol = $detected['columns']['buy'];
    if ($headerRow === null) {
        [$nameCol, $qtyCol, $sellCol] = guess_import_columns($head);
        $buyCol = null;
    }
    if ($map !== null) {
        if (array_key_exists('header_row', $map)) {
            $headerRow = ($map['header_row'] === null || $map['header_row'] === '') ? null : (int) $map['header_row'];
        }
        if (isset($map['name']) && $map['name'] !== '') {
            $nameCol = (int) $map['name'];
        }
        foreach (['qty' => &$qtyCol, 'sell' => &$sellCol, 'buy' => &$buyCol] as $role => &$col) {
            if (array_key_exists($role, $map)) {
                $col = ($map[$role] === null || $map[$role] === '') ? null : (int) $map[$role];
            }
        }
        unset($col);
    }

    $nameWords = header_roles('import')['name']['words'];
    $totalWords = array_map('normalize_search', ['الإجمالي', 'اجمالي', 'المجموع', 'مجموع', 'الصافي', 'صافي', 'إجمالي الفاتورة', 'total', 'subtotal']);
    $stats = ['data_rows' => 0, 'ok' => 0, 'empty_name' => 0, 'total_row' => 0, 'header_repeat' => 0, 'qty_invalid' => 0, 'qty_empty' => 0,
              'truncated' => 0, 'price_invalid' => 0];
    $sample = [];
    $skippedSample = [];
    $rows = [];

    foreach (iterate_rows($head, $rest) as [$rowNum, $cells]) {
        if ($headerRow !== null && $rowNum <= $headerRow) {
            continue;
        }
        if (!$cells) {
            continue;                                   // صف فارغ تماماً
        }
        $stats['data_rows']++;
        $rawName = (string) ($cells[$nameCol] ?? '');
        $name = clean_text($rawName, 1000);
        $reason = null;
        if ($name === '') {
            $reason = 'empty_name';
        } else {
            $norm = normalize_search($name);
            if (in_array($norm, $nameWords, true)) {
                $reason = 'header_repeat';
            } else {
                foreach ($totalWords as $word) {
                    if (mb_strpos($norm, $word) === 0) {
                        $reason = 'total_row';
                        break;
                    }
                }
            }
        }
        if ($reason !== null) {
            $stats[$reason]++;
            if (count($skippedSample) < 12) {
                $skippedSample[] = ['row' => $rowNum, 'reason' => $reason, 'text' => clean_text(implode(' | ', $cells), 80)];
            }
            continue;
        }

        if (mb_strlen($name) > 255) {
            $stats['truncated']++;
            $name = mb_substr($name, 0, 255);
        }
        $rawQty = $qtyCol === null ? '' : trim((string) ($cells[$qtyCol] ?? ''));
        $qty = $rawQty === '' ? null : to_hundredths($rawQty);
        if ($rawQty === '') {
            $stats['qty_empty']++;
            $qty = 0;
        } elseif ($qty === null || abs($qty) > 999999999) {
            $stats['qty_invalid']++;
            $qty = 0;
        }
        $prices = [];
        foreach (['sell' => $sellCol, 'buy' => $buyCol] as $role => $col) {
            $raw = $col === null ? '' : trim((string) ($cells[$col] ?? ''));
            $value = $raw === '' ? null : to_hundredths($raw);
            if ($raw !== '' && ($value === null || $value < 0 || $value > 999999999)) {
                $stats['price_invalid']++;
                $value = null;
            }
            $prices[$role] = $value;
        }
        $stats['ok']++;
        if (count($sample) < 8) {
            $sample[] = ['row' => $rowNum, 'name' => $name, 'qty' => from_hundredths($qty)];
        }
        if ($collect) {
            $rows[] = [$name, $qty, $prices['sell'], $prices['buy'], $rowNum];
        }
    }

    return [
        'header_row'     => $headerRow,
        'map'            => ['name' => $nameCol, 'qty' => $qtyCol, 'sell' => $sellCol, 'buy' => $buyCol, 'header_row' => $headerRow],
        'columns'        => sheet_columns($head, $headerRow),
        'stats'          => $stats,
        'sample'         => $sample,
        'skipped_sample' => $skippedSample,
        'rows'           => $rows,
    ];
}

/**
 * ورقة أسعار [الباركود، السعر الجديد، (سعر الشراء الجديد)]. الخلية الفارغة تعني "بلا تغيير".
 * التكرار: آخر قيمة غير فارغة لكل عمود هي المعتمدة.
 */
function scan_price_sheet(SpreadsheetReader $reader, int $sheet, ?array $map): array
{
    [$head, $rest] = read_head($reader, $sheet);
    $detected = detect_header($head, header_roles('prices'), ['barcode']);
    $headerRow = $detected['header_row'];
    $cols = $detected['columns'];
    if ($headerRow === null) {
        $cols = ['barcode' => 0, 'sell' => 1, 'buy' => null];
    }
    if ($map !== null) {
        if (array_key_exists('header_row', $map)) {
            $headerRow = ($map['header_row'] === null || $map['header_row'] === '') ? null : (int) $map['header_row'];
        }
        foreach (['barcode', 'sell', 'buy'] as $role) {
            if (array_key_exists($role, $map)) {
                $cols[$role] = ($map[$role] === null || $map[$role] === '') ? null : (int) $map[$role];
            }
        }
    }

    $entries = [];
    $invalid = [];
    $counts = ['rows' => 0, 'no_barcode' => 0, 'no_price' => 0, 'invalid' => 0, 'duplicates' => 0];
    if ($cols['barcode'] !== null && ($cols['sell'] !== null || $cols['buy'] !== null)) {
        foreach (iterate_rows($head, $rest) as [$rowNum, $cells]) {
            if (($headerRow !== null && $rowNum <= $headerRow) || !$cells) {
                continue;
            }
            $counts['rows']++;
            $code = normalize_barcode((string) ($cells[$cols['barcode']] ?? ''));
            if ($code === '') {
                $counts['no_barcode']++;
                continue;
            }
            $values = [];
            $bad = false;
            foreach (['sell', 'buy'] as $role) {
                $raw = $cols[$role] === null ? '' : trim((string) ($cells[$cols[$role]] ?? ''));
                if ($raw === '') {
                    $values[$role] = null;
                    continue;
                }
                $value = to_hundredths($raw);
                if ($value === null || $value < 0 || $value > 999999999) {
                    $bad = true;
                    if (count($invalid) < 20) {
                        $invalid[] = ['row' => $rowNum, 'barcode' => $code, 'value' => clean_text($raw, 30)];
                    }
                }
                $values[$role] = $value;
            }
            if ($bad) {
                $counts['invalid']++;
                continue;
            }
            if ($values['sell'] === null && $values['buy'] === null) {
                $counts['no_price']++;
                continue;
            }
            $key = mb_strtolower($code);
            if (isset($entries[$key])) {
                // الباركود مكرر: كل خلية غير فارغة تعليمة، والأحدث يتقدم في عمودها فقط.
                $counts['duplicates']++;
                foreach (['sell', 'buy'] as $role) {
                    if ($values[$role] !== null) {
                        $entries[$key][$role] = $values[$role];
                    }
                }
                $entries[$key]['row'] = $rowNum;
            } else {
                $entries[$key] = ['barcode' => $code, 'sell' => $values['sell'], 'buy' => $values['buy'], 'row' => $rowNum];
            }
        }
    }

    return [
        'header_row' => $headerRow,
        'map'        => $cols + ['header_row' => $headerRow],
        'columns'    => sheet_columns($head, $headerRow),
        'entries'    => $entries,
        'invalid'    => $invalid,
        'counts'     => $counts,
    ];
}

/**
 * يطابق باركودات ملف الأسعار مع قاعدة البيانات (دفعات من 500) ويحسب ما سيتغير فعلاً.
 * @return array{changes: array, unchanged: int, unmatched: string[]}
 */
function match_price_entries(PDO $pdo, array $entries): array
{
    $changes = [];
    $unchanged = 0;
    $found = [];
    foreach (array_chunk($entries, 500, true) as $chunk) {
        $codes = array_column($chunk, 'barcode');
        $in = implode(',', array_fill(0, count($codes), '?'));
        $st = $pdo->prepare("SELECT id, barcode, product_name, sell_price, buy_price FROM products WHERE barcode IN ($in)");
        $st->execute($codes);
        foreach ($st as $p) {
            $key = mb_strtolower($p['barcode']);
            if (!isset($chunk[$key])) {
                continue;
            }
            $found[$key] = true;
            $entry = $chunk[$key];
            $oldSell = to_hundredths((string) $p['sell_price']) ?? 0;
            $oldBuy = to_hundredths((string) $p['buy_price']) ?? 0;
            $newSell = $entry['sell'] ?? $oldSell;
            $newBuy = $entry['buy'] ?? $oldBuy;
            if ($newSell === $oldSell && $newBuy === $oldBuy) {
                $unchanged++;
                continue;
            }
            $changes[] = [
                'id' => (int) $p['id'], 'barcode' => $p['barcode'], 'name' => $p['product_name'],
                'old_sell' => $oldSell, 'new_sell' => $newSell, 'old_buy' => $oldBuy, 'new_buy' => $newBuy,
            ];
        }
    }
    $unmatched = [];
    foreach ($entries as $key => $entry) {
        if (!isset($found[$key])) {
            $unmatched[] = $entry['barcode'];
        }
    }
    return ['changes' => $changes, 'unchanged' => $unchanged, 'unmatched' => $unmatched];
}
