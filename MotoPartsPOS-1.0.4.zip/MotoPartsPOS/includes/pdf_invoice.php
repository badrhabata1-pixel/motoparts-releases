<?php
/**
 * بنود فاتورة المورد من ملف PDF، داخل الخادم المدمج بلا Python ولا أدوات خارجية.
 * منقول سطراً بسطر من tools/pdf_invoices_extract.py (الخوارزمية المختبرة على فواتير المورد)، ونتيجته مطابقة لها:
 *
 * 1. كل حرف بموضعه من الخط المضمَّن (includes/pdf_reader.php)، والصفوف حسب خط القاعدة (y).
 * 2. المسافات بين الكلمات من الفراغ الفعلي بين الحروف، لا من حروف المسافة المرسومة.
 * 3. الترتيب المرئي ← المنطقي: عكس خوارزمية Bidi لفقرة من اليمين لليسار، فلا تنعكس الحروف ولا الأرقام.
 * 4. الأعمدة من مواضع عناوين الجدول في كل صفحة (م، الصنف، الكمية، السعر، الإجمالي). الكلمات تُقارن بعد التطبيع
 *    (أ/إ/آ ← ا، ى ← ي، ة ← ه) وببداياتها، فاختلاف همزة أو حرف لا يُضيّع العنوان.
 * 5. البند = صف يبدأ برقم مسلسل (م) ثم نص ثم أرقام الكمية والسعر. ما عداه يُستبعد بلا فحص: ترويسة الصفحة،
 *    والجدول السفلي (الإجمالي، الرصيد السابق، المطلوب، الباقي، التفقيط)، والتوقيعات.
 * 6. لا رفض: لا يُشترط صف إجمالي ولا مطابقة مجموع الكميات. تسلسل "م" والكمية × السعر = إجمالي السطر للعلم فقط.
 */
require_once __DIR__ . '/pdf_reader.php';

const PDF_EXTRACT_VERSION = 2;       // يُبطل ما حُفظ من قراءات سابقة بجوار الملفات المرفوعة
const PDF_ROW_TOLERANCE = 0.6;       // نقاط: حروف السطر الواحد على خط قاعدة واحد تقريباً
const PDF_SPACE_FRACTION = 0.45;     // فراغ أكبر من 45% من عرض المسافة = مسافة بين كلمتين
const PDF_WHITESPACE = '\x{09}-\x{0D}\x{1C}-\x{20}\x{85}\x{A0}\x{1680}\x{2000}-\x{200A}\x{2028}\x{2029}\x{202F}\x{205F}\x{3000}';

/** str.isspace() في Python: نص غير فارغ كله مسافات (بتعريف Unicode). */
function pdf_isspace(string $s): bool
{
    return $s !== '' && preg_match('/^[' . PDF_WHITESPACE . ']+$/u', $s) === 1;
}

/** الصفوف من الأعلى للأسفل؛ الحرف يلحق بالصف إن كان على خط قاعدته تقريباً. */
function pdf_rows(array $glyphs): array
{
    usort($glyphs, function ($a, $b) { return $b[0] <=> $a[0]; });
    $rows = [];
    $last = -1;
    foreach ($glyphs as $g) {
        if ($last >= 0 && abs($rows[$last]['y'] - $g[0]) <= PDF_ROW_TOLERANCE) {
            $rows[$last]['glyphs'][] = $g;
        } else {
            $rows[] = ['y' => $g[0], 'glyphs' => [$g]];
            $last++;
        }
    }
    return $rows;
}

/**
 * حروف بلا نص في خريطة ToUnicode للملف (U+0000): Chrome (Skia/PDF) يرسم الياء في أول الكلمة ووسطها بخط FreeSerif
 * رمزين، النقطتين وجسم الحرف، ويكتب نصهما U+0000، فتصبح "الكمية" "الكم ة" ويضيع عنوان الجدول ومعه كل البنود.
 * الرموز المتجاورة بلا نص بجوار حرف عربي = ياء، والنقطتان وحدهما بجوار ى = ي. ما ليس بجوار حرف عربي يبقى كما هو.
 */
function pdf_recover_letters(array $glyphs): array
{
    $blank = function (array $g): bool { return $g[3] === "\0" || $g[3] === ''; };
    if (!array_filter($glyphs, $blank)) {
        return $glyphs;
    }
    $arabic = function (?array $g): bool { return $g !== null && !pdf_isspace($g[3]) && pdf_bidi_class(mb_substr($g[3], 0, 1)) === 'R'; };
    usort($glyphs, function ($a, $b) { return [$a[1], $a[2]] <=> [$b[1], $b[2]]; });
    $out = [];
    $n = count($glyphs);
    for ($i = 0; $i < $n;) {
        if (!$blank($glyphs[$i])) {
            $out[] = $glyphs[$i++];
            continue;
        }
        [$x0, $x1] = [$glyphs[$i][1], $glyphs[$i][2]];
        $j = $i;
        while ($j + 1 < $n && $blank($glyphs[$j + 1]) && $glyphs[$j + 1][1] - $x1 <= PDF_SPACE_FRACTION * $glyphs[$j + 1][4]) {
            $x1 = max($x1, $glyphs[++$j][2]);
        }
        $prev = $out ? count($out) - 1 : null;
        $next = $j + 1 < $n ? $glyphs[$j + 1] : null;
        if ($arabic($prev === null ? null : $out[$prev]) || $arabic($next)) {
            if ($x1 - $x0 >= 0.5) {
                $out[] = [$glyphs[$i][0], $x0, $x1, 'ي', $glyphs[$i][4]];
            } elseif ($prev !== null && preg_match('/^[\x{0649}\x{FEEF}\x{FEF0}]$/u', $out[$prev][3])) {
                $out[$prev][3] = 'ي';
            } elseif ($next !== null && preg_match('/^[\x{0649}\x{FEEF}\x{FEF0}]$/u', $next[3])) {
                $glyphs[$j + 1][3] = 'ي';
            }
        } else {
            array_push($out, ...array_slice($glyphs, $i, $j - $i + 1));
        }
        $i = $j + 1;
    }
    return $out;
}

/** كلمات الصف بالترتيب المرئي (يسار ← يمين): حروف متجاورة بلا فراغ بينها. @return array<int, array> */
function pdf_visual_words(array $glyphs): array
{
    $ink = array_values(array_filter($glyphs, function ($g) { return !pdf_isspace($g[3]); }));
    usort($ink, function ($a, $b) { return [$a[1], $a[2]] <=> [$b[1], $b[2]]; });
    $words = [];
    $cur = [];
    foreach ($ink as $g) {
        if ($cur && $g[1] - $cur[count($cur) - 1][2] > PDF_SPACE_FRACTION * $g[4]) {
            $words[] = $cur;
            $cur = [];
        }
        $cur[] = $g;
    }
    if ($cur) {
        $words[] = $cur;
    }
    return $words;
}

/** النص بالترتيب المرئي (يسار ← يمين)، والمسافات من الفراغ الفعلي بين الحروف. */
function pdf_visual_line(array $glyphs): string
{
    $ink = array_values(array_filter($glyphs, function ($g) { return !pdf_isspace($g[3]); }));
    usort($ink, function ($a, $b) { return [$a[1], $a[2]] <=> [$b[1], $b[2]]; });
    $out = '';
    $prev = null;
    foreach ($ink as $g) {
        if ($prev !== null && $g[1] - $prev[2] > PDF_SPACE_FRACTION * $g[4]) {
            $out .= ' ';
        }
        $out .= $g[3];
        $prev = $g;
    }
    return $out;
}

/**
 * صنف الحرف في خوارزمية Bidi كما يعيده unicodedata.bidirectional في Python، مختصراً إلى ما تحتاجه
 * pdf_visual_to_logical: R (عربي/عبري)، L (لاتيني)، N (أرقام EN/AN)، CS، ES، ET، وON لكل ما عداها.
 */
function pdf_bidi_class(string $ch): string
{
    $cp = mb_ord($ch, 'UTF-8');
    if ($cp === false) {
        return 'ON';
    }
    if ($cp < 0x80) {
        if ($cp >= 0x30 && $cp <= 0x39) {
            return 'N';
        }
        if (($cp >= 0x41 && $cp <= 0x5A) || ($cp >= 0x61 && $cp <= 0x7A)) {
            return 'L';
        }
        if (strpos(',./:', $ch) !== false) {
            return 'CS';
        }
        if ($ch === '+' || $ch === '-') {
            return 'ES';
        }
        if ($ch === '#' || $ch === '$' || $ch === '%') {
            return 'ET';
        }
        return 'ON';
    }
    if ($cp >= 0x0600 && $cp <= 0x06FF) {
        if (($cp >= 0x0600 && $cp <= 0x0605) || ($cp >= 0x0660 && $cp <= 0x0669) || $cp === 0x066B || $cp === 0x066C || $cp === 0x06DD
            || ($cp >= 0x06F0 && $cp <= 0x06F9)) {
            return 'N';
        }
        if ($cp === 0x060C) {
            return 'CS';
        }
        if ($cp === 0x0609 || $cp === 0x060A || $cp === 0x066A) {
            return 'ET';
        }
        if (($cp >= 0x0610 && $cp <= 0x061A) || ($cp >= 0x064B && $cp <= 0x065F) || $cp === 0x0670 || ($cp >= 0x06D6 && $cp <= 0x06DC)
            || ($cp >= 0x06DF && $cp <= 0x06E4) || $cp === 0x06E7 || $cp === 0x06E8 || ($cp >= 0x06EA && $cp <= 0x06ED)) {
            return 'NSM';
        }
        if ($cp === 0x0606 || $cp === 0x0607 || $cp === 0x060E || $cp === 0x060F || $cp === 0x06DE || $cp === 0x06E9) {
            return 'ON';
        }
        return 'R';
    }
    if (($cp >= 0x0590 && $cp <= 0x08FF) || ($cp >= 0xFB1D && $cp <= 0xFDFD) || ($cp >= 0xFE70 && $cp <= 0xFEFE) || $cp === 0x200F) {
        return 'R';
    }
    if ($cp === 0xA0 || $cp === 0x202F || $cp === 0x2044 || in_array($cp, [0xFE50, 0xFE52, 0xFE55, 0xFF0C, 0xFF0E, 0xFF0F, 0xFF1A], true)) {
        return 'CS';
    }
    if (in_array($cp, [0x207A, 0x207B, 0x208A, 0x208B, 0x2212, 0xFE62, 0xFE63, 0xFF0B, 0xFF0D], true)) {
        return 'ES';
    }
    if (($cp >= 0xA2 && $cp <= 0xA5) || $cp === 0xB0 || $cp === 0xB1 || ($cp >= 0x2030 && $cp <= 0x2034) || ($cp >= 0x20A0 && $cp <= 0x20CF)
        || in_array($cp, [0xFE5F, 0xFE69, 0xFE6A, 0xFF03, 0xFF04, 0xFF05, 0xFFE0, 0xFFE1, 0xFFE5, 0xFFE6], true)) {
        return 'ET';
    }
    if (($cp >= 0xB2 && $cp <= 0xB3) || $cp === 0xB9 || ($cp >= 0x2070 && $cp <= 0x2079) || ($cp >= 0x2080 && $cp <= 0x2089) || ($cp >= 0xFF10 && $cp <= 0xFF19)) {
        return 'N';
    }
    return ($cp === 0x200E || preg_match('/^\p{L}$/u', $ch)) ? 'L' : 'ON';
}

/** أشكال العرض العربية (مثل ﻻ) إلى حروفها الأصلية (NFKC)، حرفاً حرفاً. */
function pdf_unpresent(string $text): string
{
    static $forms = null;
    if (!preg_match('/[\x{FB50}-\x{FDFF}\x{FE70}-\x{FEFF}]/u', $text)) {
        return $text;
    }
    $forms = $forms ?? require __DIR__ . '/pdf_arabic_forms.php';
    return preg_replace_callback('/[\x{FB50}-\x{FDFF}\x{FE70}-\x{FEFF}]/u', function ($m) use ($forms) {
        return $forms[mb_ord($m[0], 'UTF-8')] ?? $m[0];
    }, $text);
}

/**
 * عكس خوارزمية Bidi لفقرة اتجاهها الأساسي من اليمين لليسار، بلا تضمين صريح:
 * - يُقلب السطر كله فتصبح الحروف العربية بترتيبها المنطقي.
 * - كل كتلة تحتوي حرفاً لاتينياً تُعاد كما تُقرأ يساراً ليمين (الأرقام بعد حرف لاتيني تُعامل لاتينية، W7).
 * - كتلة أرقام بلا لاتيني: كل رقم يُعاد وحده، ومعه الفاصل المنفرد بين رقمين مثل 16/90 و1,500 (W4)
 *   وعلامات مثل % الملاصقة للرقم (W5). المسافات بين الأرقام تبقى عربية الاتجاه: "12 / 500" تبقى كما هي.
 * - الأقواس داخل النص العربي معكوسة الشكل عند الرسم، فتُعاد إلى أصلها.
 */
function pdf_visual_to_logical(string $visual): string
{
    static $mirror = ['(' => ')', ')' => '(', '[' => ']', ']' => '[', '{' => '}', '}' => '{', '<' => '>', '>' => '<'];
    $chars = $visual === '' ? [] : array_reverse(mb_str_split($visual, 1, 'UTF-8'));
    $n = count($chars);
    $cls = array_map('pdf_bidi_class', $chars);
    $out = [];
    $i = 0;
    while ($i < $n) {
        if ($cls[$i] === 'R') {
            $out[] = $chars[$i++];
            continue;
        }
        $j = $i;
        while ($j < $n && $cls[$j] !== 'R') {
            $j++;
        }
        $block = array_slice($chars, $i, $j - $i);
        $bcls = array_slice($cls, $i, $j - $i);
        $s = 0;
        $e = count($block);
        while ($s < $e && $bcls[$s] !== 'L' && $bcls[$s] !== 'N') {
            $s++;
        }
        while ($e > $s && $bcls[$e - 1] !== 'L' && $bcls[$e - 1] !== 'N') {
            $e--;
        }
        foreach (array_slice($block, 0, $s) as $c) {
            $out[] = $mirror[$c] ?? $c;
        }
        $core = array_slice($block, $s, $e - $s);
        $coreCls = array_slice($bcls, $s, $e - $s);
        $len = count($core);
        if (in_array('L', $coreCls, true)) {
            foreach (array_reverse($core) as $c) {
                $out[] = $c;
            }
        } else {
            $k = 0;
            while ($k < $len) {
                if ($coreCls[$k] === 'N' || ($coreCls[$k] === 'ET' && $k + 1 < $len && $coreCls[$k + 1] === 'N')) {
                    $m = $k;
                    while ($m < $len && (
                        $coreCls[$m] === 'N'
                        || (($coreCls[$m] === 'CS' || $coreCls[$m] === 'ES') && $m + 1 < $len && $coreCls[$m + 1] === 'N' && $m > $k && $coreCls[$m - 1] === 'N')
                        || $coreCls[$m] === 'ET'
                    )) {
                        $m++;
                    }
                    foreach (array_reverse(array_slice($core, $k, $m - $k)) as $c) {
                        $out[] = $c;
                    }
                    $k = $m;
                } else {
                    $out[] = $mirror[$core[$k]] ?? $core[$k];
                    $k++;
                }
            }
        }
        foreach (array_slice($block, $e) as $c) {
            $out[] = $mirror[$c] ?? $c;
        }
        $i = $j;
    }
    // أشكال العرض العربية إلى حروفها الأصلية، بعد الترتيب لا قبله
    $text = pdf_unpresent(implode('', $out));
    $text = preg_replace('/[' . PDF_WHITESPACE . ']+/u', ' ', $text);
    return preg_replace('/^[' . PDF_WHITESPACE . ']+|[' . PDF_WHITESPACE . ']+$/u', '', $text);
}

/** حروف الصف الواقعة بين حدي عمود (من بداية الحرف). */
function pdf_column(array $row, float $lo, float $hi): array
{
    return array_values(array_filter($row['glyphs'], function ($g) use ($lo, $hi) { return $lo <= $g[1] && $g[1] < $hi; }));
}

/** "1,265.00" ← 126500 بالمئات (الفواصل والمسافات تُحذف، تقريب نصف لأعلى عند الخانة الثالثة)، أو null. */
function pdf_parse_number(string $text): ?int
{
    $t = str_replace([',', ' ', "\u{00A0}"], '', normalize_digits($text));
    if (!preg_match('/^-?\d+(\.\d+)?$/', $t)) {
        return null;
    }
    $neg = $t[0] === '-';
    $t = ltrim($t, '-');
    $whole = strstr($t, '.', true);
    $frac = $whole === false ? '' : substr($t, strlen($whole) + 1);
    $whole = $whole === false ? $t : $whole;
    $value = (int) $whole * 100 + intdiv((int) substr($frac . '000', 0, 3) + 5, 10);
    return $neg ? -$value : $value;
}

/** الكلمة للتعرف عليها: أ/إ/آ ← ا، ى ← ي، ة ← ه، بلا تشكيل ولا تطويل ولا مسافات. */
function pdf_norm(string $text): string
{
    return str_replace(' ', '', normalize_search($text));
}

/** دور عنوان عمود في الجدول من كلمته بعد التطبيع، أو null. */
function pdf_header_role(string $word): ?string
{
    $w = pdf_norm($word);
    if ($w === 'م' || $w === 'مسلسل' || $w === '#') {
        return 'seq';
    }
    $starts = function (string ...$prefixes) use ($w): bool {
        foreach ($prefixes as $p) {
            if (mb_strpos($w, $p) === 0) {
                return true;
            }
        }
        return false;
    };
    $has = function (string ...$parts) use ($w): bool {
        foreach ($parts as $p) {
            if (mb_strpos($w, $p) !== false) {
                return true;
            }
        }
        return false;
    };
    if ($starts('الكم', 'كم', 'العدد', 'عدد')) {
        return 'qty';
    }
    if ($has('سعر')) {
        return 'price';
    }
    if ($has('جمال', 'قيمه', 'مبلغ')) {
        return 'total';
    }
    if ($has('صنف', 'بيان', 'اسم')) {
        return 'name';
    }
    return null;
}

/**
 * صف عناوين الجدول وحدود الأعمدة من مواضع العناوين: يكفي م والصنف والكمية، والسعر والإجمالي إن وُجدا.
 * @return array{0: ?float, 1: ?array}
 */
function pdf_find_header(array $rows): array
{
    foreach ($rows as $row) {
        $at = [];
        foreach (pdf_visual_words($row['glyphs']) as $grp) {
            $role = pdf_header_role(pdf_visual_to_logical(implode('', array_column($grp, 3))));
            if ($role !== null && !isset($at[$role])) {
                $at[$role] = [$grp[0][1], $grp[count($grp) - 1][2]];
            }
        }
        if (!isset($at['seq'], $at['name'], $at['qty'])) {
            continue;
        }
        [$qty, $seq] = [$at['qty'], $at['seq']];
        $price = $at['price'] ?? null;
        $total = $at['total'] ?? null;
        if (!($qty[1] < $at['name'][0] && $at['name'][1] < $seq[0])) {
            continue;                                       // ليس جدولاً من اليمين لليسار: م ثم الصنف ثم الكمية
        }
        // الأرقام محاذاة لليمين تحت عناوينها، والاسم محاذى لليمين وينتهي قبل عمود "م" بنحو 10 نقاط.
        $cols = [];
        $left = -1e9;
        if ($price !== null && $price[1] < $qty[0]) {
            if ($total !== null && $total[1] < $price[0]) {
                $edge = ($total[1] + $price[0]) / 2;
                $cols['total'] = [$left, $edge];
                $left = $edge;
            }
            $edge = ($price[1] + $qty[0]) / 2;
            $cols['price'] = [$left, $edge];
            $left = $edge;
        } elseif ($total !== null && $total[1] < $qty[0]) {
            $edge = ($total[1] + $qty[0]) / 2;
            $cols['total'] = [$left, $edge];
            $left = $edge;
        }
        $cols['qty'] = [$left, $qty[1] + 50];
        $cols['name'] = [$qty[1] + 50, $seq[0] - 8];
        $cols['seq'] = [$seq[0] - 8, 1e9];
        return [$row['y'], $cols];
    }
    return [null, null];
}

/**
 * البند بالقاعدة البسيطة، بلا أعمدة: الكلمة الأولى من اليمين رقم مسلسل، وفي اليسار رقمان أو ثلاثة
 * (الإجمالي ثم السعر ثم الكمية مرئياً)، وما بينهما نص = اسم الصنف. @return ?array{seq:int, name:string, qty:int, price:int, line_total:?int}
 */
function pdf_row_by_words(array $glyphs): ?array
{
    $words = pdf_visual_words($glyphs);
    $last = count($words) - 1;
    if ($last < 3) {
        return null;
    }
    $seq = str_replace(' ', '', pdf_visual_to_logical(implode('', array_column($words[$last], 3))));
    if (!ctype_digit($seq)) {
        return null;
    }
    $nums = [];
    $k = 0;
    while ($k < $last - 1 && count($nums) < 3) {
        $value = pdf_parse_number(pdf_visual_to_logical(implode('', array_column($words[$k], 3))));
        if ($value === null) {
            break;
        }
        $nums[] = $value;
        $k++;
    }
    if (count($nums) < 2) {
        return null;
    }
    $name = pdf_visual_to_logical(pdf_visual_line(array_merge(...array_slice($words, $k, $last - $k))));
    if (!preg_match('/\p{L}/u', $name)) {
        return null;
    }
    [$total, $price, $qty] = count($nums) === 3 ? $nums : [null, $nums[0], $nums[1]];
    return ['seq' => (int) $seq, 'name' => $name, 'qty' => $qty, 'price' => $price, 'line_total' => $total];
}

/** أول رقم في سطر فيه العنوان (بعد التطبيع)، مثل "كود الفاتورة 9999". */
function pdf_labelled_value(array $texts, array $labels, string $pattern): ?string
{
    foreach ($texts as $text) {
        $norm = pdf_norm($text);
        foreach ($labels as $label) {
            if (mb_strpos($norm, pdf_norm($label)) !== false && preg_match($pattern, normalize_digits($text), $m)) {
                return $m[0];
            }
        }
    }
    return null;
}

/**
 * بنود فاتورة PDF. لا يُرفض شيء: ما يُكتشف من ملاحظات (problems) للعلم في المعاينة فقط.
 * @return array{v:int, file:string, pages:int, invoice_code:?string, invoice_date:?string,
 *   items: array<int, array{page:int, y:float, seq:int, name:string, qty:int, price:?int, line_total:?int}>,
 *   skipped: array, checks: array{seq_contiguous:bool, arithmetic_mismatches:array}, problems: string[]}
 */
function pdf_extract_invoice(string $path, string $fileName = ''): array
{
    $doc = PdfDocument::open($path);
    $pages = $doc->pages();
    if (!$pages) {
        throw new UserError('ملف PDF بلا صفحات.');
    }
    $items = [];
    $skipped = [];
    $problems = [];
    $invoiceCode = $invoiceDate = null;
    $anyText = false;
    foreach ($pages as $p => $page) {
        $pno = $p + 1;
        $glyphs = pdf_page_glyphs($doc, $page);
        $anyText = $anyText || $glyphs;
        $rows = pdf_rows($glyphs);
        foreach ($rows as &$r) {
            $r['glyphs'] = pdf_recover_letters($r['glyphs']);
        }
        unset($r);
        $texts = array_map(function ($r) { return pdf_visual_to_logical(pdf_visual_line($r['glyphs'])); }, $rows);
        if ($invoiceCode === null) {
            $invoiceCode = pdf_labelled_value($texts, ['كود الفاتورة', 'رقم الفاتورة'], '/\d{2,}/');
            $invoiceDate = pdf_labelled_value($texts, ['التاريخ'], '#\d{4}[/-]\d{1,2}[/-]\d{1,2}|\d{1,2}[/-]\d{1,2}[/-]\d{4}#');
        }
        [$headerY, $cols] = pdf_find_header($rows);
        // صفحة بلا عناوين جدول: ما تحت رأس الصفحة (آخره سطر "العنوان") يُقرأ بالقاعدة البسيطة وحدها.
        $pageTop = null;
        foreach ($rows as $k => $r) {
            if (mb_strpos(pdf_norm($texts[$k]), 'العنوان') === 0) {
                $pageTop = $r['y'];
                break;
            }
        }
        $top = $headerY ?? $pageTop;
        foreach ($rows as $k => $row) {
            if ($top !== null && $row['y'] >= $top - PDF_ROW_TOLERANCE) {
                continue;                                   // رأس الصفحة وعناوين الجدول
            }
            $item = null;
            if ($cols !== null) {
                $parts = [];
                foreach ($cols as $key => [$lo, $hi]) {
                    $parts[$key] = pdf_visual_to_logical(pdf_visual_line(pdf_column($row, $lo, $hi)));
                }
                $seqText = str_replace(' ', '', $parts['seq']);
                $qty = pdf_parse_number($parts['qty']);
                if (ctype_digit($seqText) && $qty !== null && $parts['name'] !== '') {
                    // حرف ملاصق لحد عمود: التقسيم قد يكون خاطئاً، فيُنبَّه عليه في المعاينة.
                    foreach ($row['glyphs'] as $g) {
                        if (pdf_isspace($g[3])) {
                            continue;
                        }
                        foreach (['name', 'seq', 'qty'] as $key) {
                            [$lo, $hi] = $cols[$key];
                            if ($lo <= $g[1] && $g[1] < $hi && ($g[1] - $lo < 2 || $hi - $g[2] < 2)) {
                                $problems[] = 'صفحة ' . $pno . ' م ' . $seqText . ': الحرف "' . $g[3] . '" ملاصق لحد عمود ' . $key;
                            }
                        }
                    }
                    $item = ['seq' => (int) $seqText, 'name' => $parts['name'], 'qty' => $qty,
                             'price' => isset($parts['price']) ? pdf_parse_number($parts['price']) : null,
                             'line_total' => isset($parts['total']) ? pdf_parse_number($parts['total']) : null];
                }
            }
            $item = $item ?? pdf_row_by_words($row['glyphs']);
            if ($item !== null) {
                $items[] = ['page' => $pno, 'y' => round($row['y'], 1)] + $item;
            } else {
                $skipped[] = ['page' => $pno, 'reason' => 'ذيل الفاتورة', 'text' => $texts[$k]];
            }
        }
    }
    if (!$anyText) {
        throw new UserError('ملف PDF بلا نص (صورة ممسوحة ضوئياً)، فلا يمكن قراءة بنوده. اطلب من المورد الفاتورة كملف PDF من برنامجه، أو اكتبها في Excel.');
    }

    // ── للعلم فقط ──
    $seqs = array_column($items, 'seq');
    $arithmetic = [];
    foreach ($items as $it) {
        if ($it['price'] === null || $it['line_total'] === null) {
            continue;
        }
        $expect = intdiv($it['price'] * $it['qty'] + 50, 100);
        if (abs($expect - $it['line_total']) > 1) {
            $arithmetic[] = [$it['seq'], from_hundredths($it['qty']) . ' × ' . from_hundredths($it['price']) . ' = ' . from_hundredths($expect) . ' ≠ ' . from_hundredths($it['line_total'])];
        }
    }
    foreach ($items as $it) {
        if (strpos($it['name'], "\u{FFFD}") !== false) {
            $problems[] = 'م ' . $it['seq'] . ': حرف غير معروف في الاسم';
        }
    }

    return [
        'v' => PDF_EXTRACT_VERSION,
        'file' => $fileName !== '' ? $fileName : basename($path),
        'pages' => count($pages),
        'invoice_code' => $invoiceCode,
        'invoice_date' => $invoiceDate,
        'items' => $items,
        'skipped' => $skipped,
        'checks' => [
            'seq_contiguous' => $seqs === ($items ? range(1, count($items)) : []),
            'arithmetic_mismatches' => $arithmetic,
        ],
        'problems' => $problems,
    ];
}
