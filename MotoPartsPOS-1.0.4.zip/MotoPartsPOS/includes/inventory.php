<?php
/**
 * منطق الأصناف المشترك بين نقطة البيع والمخزون والاستيراد والمرتجعات.
 */

const PRODUCT_COLUMNS = 'id, barcode, product_name, notes, stock_quantity, buy_price, sell_price, is_barcoded, is_quick_access, min_alert_qty, is_active';

/** شكل الصنف في ردود JSON. القيم العشرية تبقى نصوصاً ("12.50") فلا تمر بأي float. */
function product_out(array $p): array
{
    return [
        'id'          => (int) $p['id'],
        'barcode'     => (string) $p['barcode'],
        'name'        => (string) $p['product_name'],
        'notes'       => (string) ($p['notes'] ?? ''),
        'stock'       => (string) $p['stock_quantity'],
        'buy_price'   => (string) $p['buy_price'],
        'sell_price'  => (string) $p['sell_price'],
        'is_barcoded' => (int) $p['is_barcoded'],
        'is_quick'    => (int) ($p['is_quick_access'] ?? 0),
        'min_alert'   => (string) $p['min_alert_qty'],
        'is_active'   => (int) $p['is_active'],
    ];
}

/**
 * شرط البحث المشترك بين البحث الحي وطباعة الملصقات: كل كلمة يجب أن توجد في search_key المطبَّع،
 * وكلمة واحدة تطابق أيضاً بداية الباركود.
 * @return array{0: string, 1: array, 2: string} [شرط WHERE، المعاملات، الباركود التام للترتيب أو '']
 */
function product_filter_sql(string $q, string $filter): array
{
    $where = [$filter === 'inactive' ? 'is_active = 0' : 'is_active = 1'];
    $params = [];
    $filters = [
        'barcoded'   => 'is_barcoded = 1',
        'unbarcoded' => 'is_barcoded = 0',
        'quick'      => 'is_quick_access = 1',
        'low'        => 'stock_quantity <= min_alert_qty',
        'negative'   => 'stock_quantity < 0',
        'zero_price' => 'sell_price = 0',
    ];
    if (isset($filters[$filter])) {
        $where[] = $filters[$filter];
    }
    $tokens = search_tokens($q);
    if (!$tokens) {
        return [implode(' AND ', $where), $params, ''];
    }
    $exact = normalize_barcode($q);
    $parts = [];
    foreach ($tokens as $token) {
        $parts[] = 'search_key LIKE ?';
        $params[] = '%' . like_escape($token) . '%';
    }
    $condition = '(' . implode(' AND ', $parts) . ')';
    if (count($tokens) === 1 && $exact !== '' && strpos($exact, ' ') === false) {
        $condition = '(' . $condition . ' OR barcode LIKE ?)';
        $params[] = like_escape($exact) . '%';
    }
    $where[] = $condition;
    return [implode(' AND ', $where), $params, $exact];
}

const FAST_SELLERS_DAYS = 30;
const FAST_SELLERS_LIMIT = 40;

/**
 * الأكثر مبيعاً (نافذة F1 وتصفية الملصقات): صافي الكمية المباعة آخر 30 يوماً، الأكثر أولاً، ومعه عمود sold.
 * $where على أعمدة products بلا بادئة، مثل شرط product_filter_sql.
 */
function fast_sellers(PDO $pdo, string $columns, string $where = 'is_active = 1', array $params = []): array
{
    $since = (new DateTimeImmutable('today'))->modify('-' . FAST_SELLERS_DAYS . ' days')->format('Y-m-d H:i:s');
    $st = $pdo->prepare("SELECT $columns, s.sold
                           FROM (SELECT ii.product_id, SUM(ii.quantity - ii.returned_qty) AS sold
                                   FROM invoice_items ii
                                   JOIN invoices i ON i.id = ii.invoice_id
                                  WHERE i.created_at >= ?
                                  GROUP BY ii.product_id) s
                           JOIN products p ON p.id = s.product_id
                          WHERE s.sold > 0 AND $where
                          ORDER BY s.sold DESC
                          LIMIT " . FAST_SELLERS_LIMIT);
    $st->execute(array_merge([$since], $params));
    return $st->fetchAll();
}

function find_product(PDO $pdo, int $id, bool $forUpdate = false): ?array
{
    $st = $pdo->prepare('SELECT ' . PRODUCT_COLUMNS . ' FROM products WHERE id = ?' . ($forUpdate ? ' FOR UPDATE' : ''));
    $st->execute([$id]);
    $row = $st->fetch();
    return $row ?: null;
}

/**
 * القيمة التالية من جدول sequences مع قفل الصف حتى نهاية المعاملة.
 * لا يُستدعى إلا داخل معاملة مفتوحة.
 */
function sequence_lock(PDO $pdo, string $name, int $start): int
{
    $st = $pdo->prepare('SELECT next_value FROM sequences WHERE name = ? FOR UPDATE');
    $st->execute([$name]);
    $value = $st->fetchColumn();
    if ($value === false) {
        $pdo->prepare('INSERT INTO sequences (name, next_value) VALUES (?, ?)')->execute([$name, $start]);
        return $start;
    }
    return max((int) $value, $start);
}

function sequence_store(PDO $pdo, string $name, int $next): void
{
    $pdo->prepare('UPDATE sequences SET next_value = ? WHERE name = ?')->execute([$next, $name]);
}

/**
 * يحجز $count باركوداً متتالياً (داخل معاملة مفتوحة).
 *
 * يبدأ من التسلسل المقفول، ويتقدم بعد أكبر باركود رقمي بنفس عدد الخانات (قاعدة "آخر رقم + 1")،
 * فباركود مصنع من 13 خانة لا يقفز بالتسلسل. ويتخطى أي رقم مستخدم يدوياً داخل النطاق.
 *
 * @return string[]
 */
function allocate_barcodes(PDO $pdo, int $count): array
{
    if ($count < 1) {
        return [];
    }
    $next = sequence_lock($pdo, 'barcode', (int) BARCODE_START);

    $st = $pdo->prepare("SELECT MAX(barcode) FROM products WHERE CHAR_LENGTH(barcode) = ? AND barcode REGEXP '^[0-9]+$'");
    $st->execute([strlen((string) $next)]);
    $max = $st->fetchColumn();
    if ($max !== null && $max !== false && (int) $max >= $next) {
        $next = (int) $max + 1;
    }

    $codes = [];
    while (count($codes) < $count) {
        $hi = $next + ($count - count($codes)) - 1;
        $taken = barcodes_taken($pdo, $next, $hi);
        for ($v = $next; $v <= $hi; $v++) {
            if (!isset($taken[(string) $v])) {
                $codes[] = (string) $v;
            }
        }
        $next = $hi + 1;
    }
    sequence_store($pdo, 'barcode', $next);
    return $codes;
}

/** الباركودات الرقمية المستخدمة في النطاق [$lo, $hi]. أرقام بنفس الطول تُقارن نصياً بشكل صحيح عبر الفهرس الفريد. */
function barcodes_taken(PDO $pdo, int $lo, int $hi): array
{
    $loS = (string) $lo;
    $hiS = (string) $hi;
    if (strlen($loS) !== strlen($hiS)) {
        $edge = (int) ('1' . str_repeat('0', strlen($hiS) - 1));    // 999999 → 1000000
        return barcodes_taken($pdo, $lo, $edge - 1) + barcodes_taken($pdo, $edge, $hi);
    }
    $st = $pdo->prepare('SELECT barcode FROM products WHERE barcode BETWEEN ? AND ?');
    $st->execute([$loS, $hiS]);
    $taken = [];
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $code) {
        if (ctype_digit($code) && strlen($code) === strlen($loS)) {
            $taken[$code] = true;
        }
    }
    return $taken;
}

function barcode_exists(PDO $pdo, string $barcode, int $exceptId = 0): bool
{
    $st = $pdo->prepare('SELECT id FROM products WHERE barcode = ? AND id <> ? LIMIT 1');
    $st->execute([$barcode, $exceptId]);
    return $st->fetchColumn() !== false;
}

/** سطر في دفتر حركة المخزون. الكميات بالمئات. */
function record_movement(PDO $pdo, int $productId, int $changeH, int $balanceH, string $reason, ?int $refId = null, string $note = ''): void
{
    static $statements = [];
    $key = spl_object_id($pdo);
    if (!isset($statements[$key])) {
        $statements[$key] = $pdo->prepare('INSERT INTO stock_movements (product_id, change_qty, balance_after, reason, ref_id, note)
                                           VALUES (?, ?, ?, ?, ?, ?)');
    }
    $statements[$key]->execute([
        $productId, from_hundredths($changeH), from_hundredths($balanceH), $reason, $refId, clean_text($note),
    ]);
}

/**
 * يملأ search_key للأصناف التي أُضيفت من خارج التطبيق (phpMyAdmin مثلاً) أو كلها عند $all.
 * لا يغيّر updated_at لأن الاسم نفسه لم يتغير.
 */
function rebuild_search_keys(PDO $pdo, bool $all = false): int
{
    $rows = $pdo->query('SELECT id, product_name FROM products' . ($all ? '' : " WHERE search_key = ''"))->fetchAll();
    if (!$rows) {
        return 0;
    }
    $update = $pdo->prepare('UPDATE products SET search_key = ?, updated_at = updated_at WHERE id = ?');
    with_transaction($pdo, function () use ($rows, $update): void {
        foreach ($rows as $row) {
            $update->execute([normalize_search($row['product_name']), $row['id']]);
        }
    });
    return count($rows);
}

/** معنى أسباب الحركة للعرض. */
function movement_reason_label(string $reason): string
{
    $labels = [
        'create'  => 'رصيد افتتاحي',
        'sale'    => 'بيع',
        'return'  => 'مرتجع',
        'void'    => 'إلغاء فاتورة',
        'restock' => 'توريد',
        'adjust'  => 'جرد',
        'price'   => 'تعديل سعر',
        'clear'   => 'إفراغ المخزون',
    ];
    return $labels[$reason] ?? $reason;
}
