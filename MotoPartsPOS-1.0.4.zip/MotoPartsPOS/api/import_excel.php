<?php
/**
 * استيراد الأصناف من Excel/CSV بأعمدة [الصنف، الكمية، سعر البيع، (سعر الشراء)]، أو من فاتورة مورد PDF
 * (ورقة افتراضية [م، الصنف، الكمية، سعر الشراء، الإجمالي] من includes/pdf_invoice.php)، على خطوتين:
 *   POST action=preview + file        يحفظ الملف مؤقتاً، ويعيد لكل ورقة الأعمدة المكتشفة، والصفوف المتطابقة بالاسم
 *                                     مع أصناف المخزن (للمقارنة واختيار الإجراء)، وعدد الأصناف الجديدة وعينة منها
 *   POST action=rescan + token + sheet + map(JSON)   إعادة قراءة ورقة بأعمدة اختارها المستخدم
 *   POST action=commit + token + sheets(JSON) + decisions(JSON) + min_alert_qty + is_barcoded
 *
 * الصف الجديد (لا صنف نشط بالاسم نفسه) = صنف بباركود متسلسل جديد بكميته وسعره. الصف المتطابق يتبع اختيار
 * المستخدم: زيادة الكمية وتحديث السعر، أو صنف مستقل بباركود جديد، أو تخطٍّ (includes/importer.php: apply_import).
 * كل الاستيراد في معاملة واحدة، وكل إضافة أو تعديل رصيد يُسجَّل في stock_movements.
 * فاتورة PDF يُحفظ رقمها وبصمة ملفها في app_meta عند التنفيذ؛ رفعها مرة أخرى يُظهر تنبيهاً في المعاينة ولا يمنعها.
 */
require __DIR__ . '/../includes/api.php';
require __DIR__ . '/../includes/inventory.php';
require __DIR__ . '/../includes/importer.php';

require_method('POST');
set_time_limit(300);

const IMPORT_MAX_ROWS = 100000;
const IMPORT_NEW_SAMPLE = 100;

/** مفتاح فاتورة PDF في app_meta: بصمة الملف، كما في tools/import_pdf_items.php. */
function pdf_import_key(string $path): string
{
    return 'pdf:' . substr((string) hash_file('sha256', $path), 0, 40);
}

/**
 * استيراد سابق لفاتورة PDF (الملف نفسه أو رقم الفاتورة نفسه) من الشاشة أو من tools/import_pdf_items.php، أو null.
 * للتنبيه فقط: الفاتورة الجديدة تُقبل، والمرفوعة سابقاً يُنبَّه عليها ولا تُمنع.
 * @return ?array{file:string, invoice:string, items:int, at:string}
 */
function pdf_previous_import(PDO $pdo, string $path, ?string $code): ?array
{
    $key = pdf_import_key($path);
    $sql = 'SELECT meta_value FROM app_meta WHERE meta_key = ?';
    $params = [$key];
    if ($code !== null && $code !== '') {
        $sql .= " OR (meta_key LIKE 'pdf:%' AND meta_value LIKE ?)";
        $params[] = '%"invoice":"' . like_escape($code) . '"%';
    }
    $st = $pdo->prepare($sql . ' ORDER BY meta_key = ? DESC LIMIT 1');
    $st->execute(array_merge($params, [$key]));
    $value = $st->fetchColumn();
    $data = $value === false ? null : json_decode((string) $value, true);
    if (!is_array($data)) {
        return null;
    }
    return ['file' => (string) ($data['file'] ?? ''), 'invoice' => (string) ($data['invoice'] ?? ''),
            'items' => (int) ($data['items'] ?? 0), 'at' => (string) ($data['at'] ?? '')];
}

/** ورقة كما تُعرض في المعاينة: الأعمدة والإحصاءات، والمتطابقات كلها، وعينة من الجديد. */
function import_sheet_preview(PDO $pdo, SpreadsheetReader $reader, array $sheet, ?array $map, string $path): array
{
    $scan = scan_import_sheet($reader, $sheet['index'], $map, true);
    $matches = match_import_names($pdo, array_column($scan['rows'], 0));
    $price = function (?int $v): ?string { return $v === null ? null : from_hundredths($v); };
    $matched = [];
    $newSample = [];
    $newCount = 0;
    foreach ($scan['rows'] as [$name, $qty, $sell, $buy, $rowNum]) {
        $item = ['key' => $sheet['index'] . ':' . $rowNum, 'row' => $rowNum, 'name' => $name,
                 'qty' => from_hundredths($qty), 'sell' => $price($sell), 'buy' => $price($buy)];
        if (isset($matches[$name])) {
            $matched[] = $item + ['matches' => $matches[$name]];
        } else {
            $newCount++;
            if (count($newSample) < IMPORT_NEW_SAMPLE) {
                $newSample[] = $item;
            }
        }
    }
    unset($scan['rows'], $scan['sample']);
    $pdf = $reader->info($sheet['index']);
    if ($pdf !== null) {
        $pdf['previous'] = pdf_previous_import($pdo, $path, $pdf['invoice_code']);
    }
    return ['index' => $sheet['index'], 'name' => $sheet['name'], 'hidden' => $sheet['hidden']] + $scan
        + ['matched' => $matched, 'new_count' => $newCount, 'new_sample' => $newSample, 'pdf' => $pdf];
}

$action = (string) ($_POST['action'] ?? '');

if ($action === 'preview') {
    $upload = store_upload('file', 'import');
    $reader = SpreadsheetReader::open($upload['path'], $upload['name']);
    $pdo = db();
    $sheets = [];
    foreach ($reader->sheets() as $sheet) {
        $sheets[] = import_sheet_preview($pdo, $reader, $sheet, null, $upload['path']);
    }
    json_ok(['token' => $upload['token'], 'file_name' => $upload['name'], 'sheets' => $sheets]);
}

if ($action === 'rescan') {
    $upload = load_upload((string) ($_POST['token'] ?? ''), 'import');
    $index = (int) ($_POST['sheet'] ?? 0);
    $map = json_decode((string) ($_POST['map'] ?? 'null'), true);
    $reader = SpreadsheetReader::open($upload['path'], $upload['name']);
    $sheets = array_column($reader->sheets(), null, 'index');
    if (!isset($sheets[$index])) {
        throw new UserError('الورقة غير موجودة في الملف.');
    }
    json_ok(['sheet' => import_sheet_preview(db(), $reader, $sheets[$index], is_array($map) ? $map : null, $upload['path'])]);
}

if ($action !== 'commit') {
    throw new UserError('إجراء غير معروف.');
}

$upload = load_upload((string) ($_POST['token'] ?? ''), 'import');
$selection = json_decode((string) ($_POST['sheets'] ?? '[]'), true);
if (!is_array($selection) || !$selection) {
    throw new UserError('اختر ورقة واحدة على الأقل للاستيراد.');
}
$decisions = json_decode((string) ($_POST['decisions'] ?? '{}'), true);
if (!is_array($decisions)) {
    throw new UserError('اختيارات الأصناف المتطابقة غير صالحة. أعد معاينة الملف.');
}
$minAlert = to_hundredths(trim((string) ($_POST['min_alert_qty'] ?? DEFAULT_MIN_ALERT)));
if ($minAlert === null || $minAlert < 0) {
    throw new UserError('حد التنبيه غير صالح.');
}
$isBarcoded = ($_POST['is_barcoded'] ?? '1') === '1' ? 1 : 0;

$reader = SpreadsheetReader::open($upload['path'], $upload['name']);
$names = array_column($reader->sheets(), 'name', 'index');
$rows = [];
$perSheet = [];
foreach ($selection as $choice) {
    $index = (int) ($choice['index'] ?? -1);
    if (!isset($names[$index]) || empty($choice['include'])) {
        continue;
    }
    $scan = scan_import_sheet($reader, $index, $choice, true);
    if ($scan['map']['name'] === null) {
        throw new UserError('حدد عمود اسم الصنف في الورقة "' . $names[$index] . '".');
    }
    foreach ($scan['rows'] as [$name, $qty, $sell, $buy, $rowNum]) {
        $rows[] = [$index . ':' . $rowNum, $name, $qty, $sell, $buy];
    }
    $skipped = $scan['stats']['empty_name'] + $scan['stats']['total_row'] + $scan['stats']['header_repeat'];
    $perSheet[] = ['name' => $names[$index], 'rows' => count($scan['rows']), 'skipped' => $skipped];
    if (count($rows) > IMPORT_MAX_ROWS) {
        throw new UserError('عدد الصفوف أكبر من ' . IMPORT_MAX_ROWS . '. قسّم الملف إلى أجزاء.');
    }
}
if (!$rows) {
    throw new UserError('لا توجد صفوف صالحة للاستيراد في الأوراق المختارة.');
}

$note = 'استيراد: ' . $upload['name'];
$pdf = $reader->info(0);
$result = with_transaction(db(), function (PDO $pdo) use ($rows, $decisions, $minAlert, $isBarcoded, $note, $pdf, $upload): array {
    $result = apply_import($pdo, $rows, $decisions, $minAlert, $isBarcoded, $note);
    if ($pdf !== null) {
        // رقم الفاتورة وبصمة ملفها: رفعها مرة أخرى يُظهر تنبيه "سبق استيرادها" في المعاينة.
        meta_set($pdo, pdf_import_key($upload['path']), json_encode([
            'file' => mb_substr($upload['name'], 0, 80), 'invoice' => (string) $pdf['invoice_code'], 'items' => count($rows), 'at' => date('Y-m-d H:i'),
        ], JSON_UNESCAPED_UNICODE));
    }
    return $result;
});

discard_upload($upload, $reader);
$codes = $result['codes'];
json_ok([
    'inserted'      => count($codes),
    'separate'      => $result['separate'],
    'added'         => $result['added'],
    'price_updated' => $result['price_updated'],
    'skipped'       => $result['skipped'],
    'first_barcode' => $codes ? $codes[0] : null,
    'last_barcode'  => $codes ? $codes[count($codes) - 1] : null,
    'updated_ids'   => $result['product_ids'],
    'sheets'        => $perSheet,
]);
