<?php defined('IN_APP') || exit; ?>
<div class="cards-grid">
  <section class="card" id="importCard">
    <div class="card__head"><h2 class="card__title"><svg class="icon"><use href="#i-upload"/></svg> استيراد الأصناف من Excel أو CSV أو PDF</h2></div>
    <div class="card__body stack">
      <p class="muted">أعمدة الملف: <strong>اسم الصنف</strong> و<strong>الكمية</strong> و<strong>سعر البيع</strong>، واختيارياً <strong>سعر الشراء</strong>.
        الصنف الجديد يأخذ باركوداً متسلسلاً بكميته وسعره. الصنف الذي يطابق اسمه صنفاً في المخزن يظهر في المعاينة بجوار الصنف الحالي،
        وتختار له: زيادة الكمية وتحديث السعر، أو صنفاً مستقلاً بباركود جديد، أو التخطي.</p>
      <p class="muted"><strong>فاتورة المورد PDF</strong> تُرفع كما هي: كل سطر يبدأ برقم مسلسل ثم اسم الصنف ثم الكمية والسعر بند، ويُقرأ على هذا الجهاز بلا إنترنت.
        ويُترك الجدول السفلي (الإجمالي، الرصيد السابق، المطلوب، الباقي)، وسعر الفاتورة يُسجَّل سعر شراء. الفاتورة التي سبق استيرادها يظهر لها تنبيه.
        يلزم أن يكون الملف نصاً من برنامج المورد، لا صورة ممسوحة.</p>
      <form id="importForm" class="stack">
        <input type="file" name="file" accept=".xlsx, .xls, .csv, .pdf" class="input" required>
        <div class="form-grid">
          <label class="field">
            <span class="field__label">حد التنبيه للأصناف المستوردة</span>
            <input class="input" name="min_alert_qty" inputmode="decimal" value="<?= h(DEFAULT_MIN_ALERT) ?>">
          </label>
          <div class="field">
            <span class="field__label">النوع</span>
            <label class="check"><input type="checkbox" name="is_barcoded" checked> <span>ستُلصق عليها ملصقات باركود</span></label>
          </div>
        </div>
        <div class="btn-row"><button class="btn btn--primary" type="submit">معاينة الملف</button></div>
      </form>
      <div id="importPreview" class="stack" hidden></div>
      <div id="importResult" hidden></div>
    </div>
  </section>

  <section class="card">
    <div class="card__head"><h2 class="card__title"><svg class="icon"><use href="#i-receipt"/></svg> تحديث الأسعار بالجملة</h2></div>
    <div class="card__body stack">
      <p class="muted">أعمدة الملف: <strong>الباركود</strong> و<strong>السعر الجديد</strong>، واختيارياً <strong>سعر الشراء الجديد</strong>.
        الخلية الفارغة تعني "بلا تغيير"، ولن يتغير أي سعر قبل أن تراجع المعاينة وتؤكد.</p>
      <form id="pricesForm" class="stack">
        <input type="file" name="file" accept=".xlsx,.csv,.txt" class="input" required>
        <div class="btn-row"><button class="btn btn--primary" type="submit">معاينة التغييرات</button></div>
      </form>
      <div id="pricesPreview" class="stack" hidden></div>
      <div id="pricesResult" hidden></div>
    </div>
  </section>

  <section class="card">
    <div class="card__head"><h2 class="card__title"><svg class="icon"><use href="#i-download"/></svg> قالب الأسعار (Excel)</h2></div>
    <div class="card__body stack">
      <p class="muted">نزّل قالب الأسعار، واكتب السعر الجديد أمام كل صنف في Excel، ثم ارفعه في "تحديث الأسعار بالجملة".
        احفظه بصيغة xlsx حتى لا يغيّر Excel أرقام الباركود الطويلة.</p>
      <div class="btn-row">
        <button class="btn" type="button" data-export="prices">قالب الأسعار (كل الأصناف)</button>
        <button class="btn" type="button" data-export="prices" data-filter="zero_price">قالب الأصناف بسعر 0.00</button>
      </div>
      <p class="muted small">ملصقات الباركود تُعاين وتُطبع من صفحة <a href="index.php?page=labels">الملصقات</a> مباشرة.</p>
    </div>
  </section>

  <section class="card">
    <div class="card__head"><h2 class="card__title"><svg class="icon"><use href="#i-layers"/></svg> النسخ الاحتياطي</h2></div>
    <div class="card__body stack">
      <p class="muted">نسخة تلقائية يومياً عند أول تشغيل، ويُحتفظ بآخر <?= (int) BACKUP_KEEP ?> نسخة في
        <code>storage/backups</code>. انسخ أحدث نسخة إلى فلاشة أسبوعياً: النسخ على القرص نفسه لا تحمي من تلفه.</p>
      <div class="btn-row"><button class="btn btn--primary" type="button" data-action="backup-now">نسخة احتياطية الآن</button></div>
      <div id="backupList"></div>
      <p class="muted small">الاستعادة: phpMyAdmin ← قاعدة <code><?= h(DB_NAME) ?></code> ← استيراد ← اختر ملف ‎.sql.gz.</p>
    </div>
  </section>
</div>
