<?php defined('IN_APP') || exit; ?>
<section class="toolbar">
  <label class="search-field">
    <svg class="icon"><use href="#i-search"/></svg>
    <input id="invSearch" class="input" type="search" autocomplete="off" spellcheck="false"
           placeholder="ابحث بالاسم أو الباركود… مثال: مساعد، عرنوس، مارش هوجان">
  </label>
  <select id="invFilter" class="input select" aria-label="تصفية الأصناف">
    <option value="all">كل الأصناف</option>
    <option value="barcoded">بباركود (عليها ملصق)</option>
    <option value="unbarcoded">بدون باركود (يدوي)</option>
    <option value="quick">الوصول السريع [F3]</option>
    <option value="low">منخفض المخزون</option>
    <option value="negative">رصيد سالب</option>
    <option value="zero_price">سعر البيع 0.00</option>
    <option value="inactive">المحذوفة (المخفية)</option>
  </select>
  <button class="btn btn--primary" type="button" data-action="new"><svg class="icon"><use href="#i-plus"/></svg> صنف جديد</button>
  <button class="btn" type="button" data-action="labels" title="طباعة ملصقات الأصناف الظاهرة حسب البحث والتصفية"><svg class="icon"><use href="#i-printer"/></svg> طباعة الملصقات</button>
  <span class="spacer"></span>
  <button class="btn btn--danger-solid" type="button" data-action="delete-all" title="حذف كل أصناف المخزون (يطلب تأكيداً)">حذف كل الأصناف 🗑️</button>
</section>

<section class="card card--flush">
  <div class="table-wrap">
    <table class="grid inv-table">
      <thead>
        <tr>
          <th>الباركود</th>
          <th>الصنف</th>
          <th>الملاحظات</th>
          <th>النوع</th>
          <th class="num">الكمية</th>
          <th class="num">سعر الشراء</th>
          <th class="num">سعر البيع</th>
          <th class="num">حد التنبيه</th>
          <th class="actions-col">إجراءات</th>
        </tr>
      </thead>
      <tbody id="invBody"><tr><td colspan="9" class="empty">جارٍ التحميل…</td></tr></tbody>
    </table>
  </div>
  <div class="pager">
    <span id="invCount" class="muted"></span>
    <div class="pager__buttons">
      <button class="btn btn--sm" type="button" data-action="prev">السابق</button>
      <button class="btn btn--sm" type="button" data-action="next">التالي</button>
    </div>
  </div>
</section>

<dialog id="productDialog" class="dialog" aria-labelledby="productTitle">
  <form id="productForm" novalidate>
    <div class="dialog__head">
      <h2 class="dialog__title" id="productTitle">صنف جديد</h2>
      <button class="icon-btn" type="button" data-close aria-label="إغلاق"><svg class="icon"><use href="#i-x"/></svg></button>
    </div>
    <div class="dialog__body stack">
      <label class="field">
        <span class="field__label">اسم الصنف *</span>
        <input class="input" name="product_name" maxlength="255" required autocomplete="off">
      </label>
      <div class="form-grid">
        <label class="field">
          <span class="field__label">الباركود</span>
          <input class="input mono" name="barcode" maxlength="100" dir="ltr" autocomplete="off" placeholder="يُولَّد تلقائياً">
        </label>
        <div class="field">
          <span class="field__label">النوع</span>
          <label class="check"><input type="checkbox" name="is_barcoded" checked> <span>عليه ملصق باركود</span></label>
          <label class="check"><input type="checkbox" name="is_quick_access"> <span><svg class="icon icon--bolt"><use href="#i-bolt"/></svg> وصول سريع في شاشة البيع (F3)</span></label>
        </div>
        <label class="field" data-create-only>
          <span class="field__label">الكمية الافتتاحية</span>
          <input class="input" name="stock_quantity" inputmode="decimal" autocomplete="off" value="0">
        </label>
        <label class="field">
          <span class="field__label">حد التنبيه</span>
          <input class="input" name="min_alert_qty" inputmode="decimal" autocomplete="off">
        </label>
        <label class="field">
          <span class="field__label">سعر الشراء</span>
          <input class="input" name="buy_price" inputmode="decimal" autocomplete="off" value="0.00">
        </label>
        <label class="field">
          <span class="field__label">سعر البيع</span>
          <input class="input" name="sell_price" inputmode="decimal" autocomplete="off" value="0.00">
        </label>
      </div>
      <label class="field">
        <span class="field__label">ملاحظات الصنف (تتحدث تلقائياً من آخر بيع عليه ملاحظة)</span>
        <textarea class="input textarea" name="notes" maxlength="255" rows="2" placeholder="مثال: الكيس فيه 45 من أصل 50"></textarea>
      </label>
      <div class="field" id="barcodePreview" hidden>
        <span class="field__label">الملصق</span>
        <div class="preview-area" id="editLabelPreview"></div>
        <div class="btn-row"><button class="btn btn--sm" type="button" data-action="label-from-edit"><svg class="icon"><use href="#i-printer"/></svg> طباعة ملصق</button></div>
      </div>
      <div id="productHistory" hidden>
        <h3 class="subhead">آخر حركات المخزون</h3>
        <div class="table-wrap table-wrap--short">
          <table class="grid grid--compact">
            <thead><tr><th>التاريخ</th><th>الحركة</th><th class="num">التغيير</th><th class="num">الرصيد بعدها</th><th>ملاحظة</th></tr></thead>
            <tbody id="historyBody"></tbody>
          </table>
        </div>
      </div>
      <div class="alert alert--danger" id="productError" hidden></div>
    </div>
    <div class="dialog__foot">
      <button class="btn btn--ghost" type="button" data-close>إلغاء</button>
      <button class="btn btn--primary" type="submit">حفظ</button>
    </div>
  </form>
</dialog>

<dialog id="labelDialog" class="dialog" aria-labelledby="labelTitle">
  <form id="labelForm" novalidate>
    <div class="dialog__head">
      <h2 class="dialog__title" id="labelTitle">ملصق الباركود</h2>
      <button class="icon-btn" type="button" data-close aria-label="إغلاق"><svg class="icon"><use href="#i-x"/></svg></button>
    </div>
    <div class="dialog__body stack">
      <p class="stock-product" id="labelProduct"></p>
      <div class="preview-area" id="labelPreviewBox"></div>
      <div class="form-grid">
        <label class="field">
          <span class="field__label">الورق والمقاس</span>
          <select class="input select" name="preset"></select>
        </label>
        <label class="field">
          <span class="field__label">عدد النسخ</span>
          <input class="input input--lg" name="copies" inputmode="numeric" autocomplete="off">
        </label>
      </div>
      <div class="checks">
        <label class="check"><input type="checkbox" name="showName"> <span>اسم الصنف</span></label>
        <label class="check"><input type="checkbox" name="showPrice"> <span>السعر</span></label>
        <label class="check"><input type="checkbox" name="showCode"> <span>رقم الباركود</span></label>
      </div>
      <div class="alert alert--warn" id="labelNoPrice" hidden>الصنف بلا سعر بيع، فسيُطبع الملصق بدون سعر.</div>
      <div class="alert alert--danger" id="labelWeak" hidden>خطوط هذا الباركود ستكون أرفع من نقطتي طباعة على هذا المقاس، وقد لا يقرؤها الماسح. اختر مقاساً أعرض، أو غيّر دقة الطابعة من "إعدادات أكثر".</div>
    </div>
    <div class="dialog__foot">
      <a class="btn btn--ghost" id="labelMore" href="index.php?page=labels">إعدادات أكثر…</a>
      <span class="spacer"></span>
      <button class="btn btn--ghost" type="button" data-close>إلغاء</button>
      <button class="btn btn--primary" type="submit"><svg class="icon"><use href="#i-printer"/></svg> طباعة</button>
    </div>
  </form>
</dialog>

<dialog id="deleteAllDialog" class="dialog dialog--narrow" aria-labelledby="deleteAllTitle">
  <form id="deleteAllForm" novalidate autocomplete="off">
    <div class="dialog__head">
      <h2 class="dialog__title" id="deleteAllTitle">حذف كل الأصناف 🗑️</h2>
      <button class="icon-btn" type="button" data-close aria-label="إغلاق"><svg class="icon"><use href="#i-x"/></svg></button>
    </div>
    <div class="dialog__body stack">
      <div class="alert alert--danger">
        <strong>سيُحذف كل صنف في المخزون: <span data-count="total">…</span> صنف.</strong>
        <ul>
          <li><span data-count="sold">…</span> صنف له مبيعات سابقة: يُخفى ويصبح رصيده 0 بحركة "إفراغ المخزون"، ويبقى في الفواتير والتقارير القديمة. تجده في تصفية "المحذوفة".</li>
          <li><span data-count="unsold">…</span> صنف بلا مبيعات: يُحذف نهائياً.</li>
        </ul>
      </div>
      <p class="muted small">تُؤخذ نسخة احتياطية كاملة من قاعدة البيانات قبل الحذف. الفواتير والمبيعات لا تتأثر.</p>
      <label class="field">
        <span class="field__label">للموافقة اكتب: <strong>تأكيد الحذف</strong></span>
        <input class="input" name="confirm_text" autocomplete="off" spellcheck="false">
      </label>
      <label class="field">
        <span class="field__label">أو كلمة مرور المدير</span>
        <input class="input" name="password" type="password" autocomplete="new-password">
      </label>
      <div class="alert alert--danger" id="deleteAllError" hidden></div>
    </div>
    <div class="dialog__foot">
      <button class="btn btn--ghost" type="button" data-close>إلغاء</button>
      <button class="btn btn--danger-solid" type="submit" disabled>حذف كل الأصناف</button>
    </div>
  </form>
</dialog>

<dialog id="stockDialog" class="dialog dialog--narrow" aria-labelledby="stockTitle">
  <form id="stockForm" novalidate>
    <div class="dialog__head">
      <h2 class="dialog__title" id="stockTitle">تعديل الرصيد</h2>
      <button class="icon-btn" type="button" data-close aria-label="إغلاق"><svg class="icon"><use href="#i-x"/></svg></button>
    </div>
    <div class="dialog__body stack">
      <p class="stock-product" id="stockProduct"></p>
      <p>الرصيد الحالي: <strong id="stockCurrent"></strong></p>
      <div class="segmented" role="radiogroup">
        <label><input type="radio" name="mode" value="restock" checked> <span>توريد (إضافة كمية)</span></label>
        <label><input type="radio" name="mode" value="adjust"> <span>جرد (الرصيد الفعلي)</span></label>
      </div>
      <label class="field">
        <span class="field__label" id="stockQtyLabel">الكمية الواردة</span>
        <input class="input input--lg" name="quantity" inputmode="decimal" autocomplete="off" required>
      </label>
      <label class="field">
        <span class="field__label">ملاحظة (اختياري)</span>
        <input class="input" name="note" maxlength="255" autocomplete="off" placeholder="مثال: فاتورة المورد رقم 512">
      </label>
      <p class="muted">الرصيد بعد العملية: <strong id="stockAfter">—</strong></p>
      <div class="alert alert--danger" id="stockError" hidden></div>
    </div>
    <div class="dialog__foot">
      <button class="btn btn--ghost" type="button" data-close>إلغاء</button>
      <button class="btn btn--primary" type="submit">تنفيذ</button>
    </div>
  </form>
</dialog>
