<?php
defined('IN_APP') || exit;

// يوم واحد (?date=) أو فترة من - إلى شاملة اليومين (?date_from=&date_to=؛ أي منهما وحده = يوم واحد، والمقلوبان يُبدَّلان).
$today = date('Y-m-d');
$dateFrom = valid_date($_GET['date_from'] ?? null);
$dateTo = valid_date($_GET['date_to'] ?? null);
$isRange = $dateFrom !== null || $dateTo !== null;
if ($isRange) {
    $dateFrom = $dateFrom ?? $dateTo;
    $dateTo = $dateTo ?? $dateFrom;
    if ($dateFrom > $dateTo) {
        [$dateFrom, $dateTo] = [$dateTo, $dateFrom];
    }
    $date = $dateTo;
} else {
    $date = valid_date($_GET['date'] ?? null) ?? $today;
    $dateFrom = $dateTo = $date;
}
$from = day_range($dateFrom)[0];
$to = day_range($dateTo)[1];
$oneDay = $dateFrom === $dateTo;
// التاريخ معزول (<bdi>) فلا يعكس النص العربي قبله ترتيب أجزائه (01-10-2026 بدل 2026-10-01).
$bdi = function (string $d): string { return '<bdi>' . h($d) . '</bdi>'; };
$periodHtml = $oneDay ? $bdi($dateFrom) : 'من ' . $bdi($dateFrom) . ' إلى ' . $bdi($dateTo);
$days = (int) (new DateTimeImmutable($dateFrom))->diff(new DateTimeImmutable($dateTo))->days + 1;
$where = $oneDay ? 'في هذا اليوم' : 'في هذه الفترة';

$st = $pdo->prepare("SELECT COUNT(*) AS cnt, COALESCE(SUM(total_amount), 0) AS sales, COALESCE(SUM(status = 'void'), 0) AS voided
                       FROM invoices WHERE created_at >= ? AND created_at < ?");
$st->execute([$from, $to]);
$day = $st->fetch();

$st = $pdo->prepare('SELECT COALESCE(SUM(amount), 0) FROM invoice_returns WHERE created_at >= ? AND created_at < ?');
$st->execute([$from, $to]);
$returnsC = to_hundredths((string) $st->fetchColumn()) ?? 0;

$salesC = to_hundredths((string) $day['sales']) ?? 0;
$invoiceCount = (int) $day['cnt'];
$averageC = $invoiceCount > 0 ? intdiv($salesC, $invoiceCount) : 0;

$st = $pdo->prepare('SELECT COUNT(*) FROM invoice_items ii JOIN invoices i ON i.id = ii.invoice_id
                      WHERE i.created_at >= ? AND i.created_at < ? AND ii.unit_price = 0');
$st->execute([$from, $to]);
$zeroLines = (int) $st->fetchColumn();

// الأصناف المباعة في الفترة: صافي الكمية بعد المرتجع، والإيراد بعد المرتجع، الأكثر كمية أولاً.
const REPORT_ITEMS_LIMIT = 500;
$st = $pdo->prepare('SELECT ii.product_id, MAX(ii.product_name) AS name, MAX(ii.barcode) AS barcode,
                            SUM(ii.quantity - ii.returned_qty) AS qty, SUM(ii.subtotal - COALESCE(r.amount, 0)) AS revenue
                       FROM invoice_items ii
                       JOIN invoices i ON i.id = ii.invoice_id
                       LEFT JOIN (SELECT invoice_item_id, SUM(subtotal) AS amount FROM invoice_return_items GROUP BY invoice_item_id) r
                              ON r.invoice_item_id = ii.id
                      WHERE i.created_at >= ? AND i.created_at < ?
                      GROUP BY ii.product_id
                     HAVING qty > 0
                      ORDER BY qty DESC, revenue DESC');
$st->execute([$from, $to]);
$top = $st->fetchAll();
$soldKinds = count($top);
$soldQtyC = 0;
foreach ($top as $row) {
    $soldQtyC += to_hundredths((string) $row['qty']) ?? 0;
}
$top = array_slice($top, 0, REPORT_ITEMS_LIMIT);

$lowCount = (int) $pdo->query('SELECT COUNT(*) FROM products WHERE is_active = 1 AND stock_quantity <= min_alert_qty')->fetchColumn();
$low = $pdo->query('SELECT id, barcode, product_name, stock_quantity, min_alert_qty, is_barcoded
                      FROM products WHERE is_active = 1 AND stock_quantity <= min_alert_qty
                     ORDER BY stock_quantity ASC, product_name ASC LIMIT 100')->fetchAll();
$isToday = !$isRange && $date === $today;
$invoicesLink = $isRange ? 'index.php?page=invoices&date_from=' . rawurlencode($dateFrom) . '&date_to=' . rawurlencode($dateTo)
                         : 'index.php?page=invoices&date=' . rawurlencode($date);
?>
<section class="toolbar">
  <form class="toolbar__form toolbar__form--wrap" method="get" id="dateForm">
    <input type="hidden" name="page" value="reports">
    <div class="segmented segmented--inline" role="radiogroup" aria-label="مدة التقرير">
      <label><input type="radio" name="mode" value="day"<?= $isRange ? '' : ' checked' ?>> <span>يوم</span></label>
      <label><input type="radio" name="mode" value="range"<?= $isRange ? ' checked' : '' ?>> <span>فترة محددة [من - إلى]</span></label>
    </div>
    <label class="field field--inline" data-mode="day"<?= $isRange ? ' hidden' : '' ?>>
      <span class="field__label">تقرير يوم</span>
      <input class="input" type="date" name="date" value="<?= h($date) ?>" max="<?= h($today) ?>"<?= $isRange ? ' disabled' : '' ?>>
    </label>
    <div class="date-range" data-mode="range"<?= $isRange ? '' : ' hidden' ?>>
      <label class="field field--inline"><span class="field__label">من تاريخ</span>
        <input class="input" type="date" name="date_from" value="<?= h($isRange ? $dateFrom : date('Y-m-01')) ?>" max="<?= h($today) ?>"<?= $isRange ? '' : ' disabled' ?>></label>
      <label class="field field--inline"><span class="field__label">إلى تاريخ</span>
        <input class="input" type="date" name="date_to" value="<?= h($isRange ? $dateTo : $today) ?>" max="<?= h($today) ?>"<?= $isRange ? '' : ' disabled' ?>></label>
      <button class="btn btn--primary btn--sm" type="submit">عرض</button>
    </div>
    <?php if (!$isToday): ?><a class="btn btn--sm" href="index.php?page=reports">اليوم</a><?php endif; ?>
  </form>
  <a class="btn" href="<?= h($invoicesLink) ?>"><svg class="icon"><use href="#i-receipt"/></svg> <?= $isRange ? 'فواتير هذه الفترة' : 'فواتير هذا اليوم' ?></a>
</section>
<?php if ($isRange): ?>
  <p class="report-period">تقرير الفترة <strong><?= $periodHtml ?></strong> (<?= $days ?> يوم)</p>
<?php endif; ?>

<section class="kpis">
  <div class="kpi kpi--accent">
    <span class="kpi__label">صافي المبيعات</span>
    <strong class="kpi__value"><?= h(money_display($salesC - $returnsC)) ?></strong>
    <span class="kpi__unit"><?= h(APP_CURRENCY) ?></span>
  </div>
  <div class="kpi">
    <span class="kpi__label">إجمالي المبيعات</span>
    <strong class="kpi__value"><?= h(money_display($salesC)) ?></strong>
    <span class="kpi__unit"><?= h(APP_CURRENCY) ?></span>
  </div>
  <div class="kpi">
    <span class="kpi__label">المرتجعات والإلغاء</span>
    <strong class="kpi__value"><?= h(money_display($returnsC)) ?></strong>
    <span class="kpi__unit"><?= h(APP_CURRENCY) ?></span>
  </div>
  <div class="kpi">
    <span class="kpi__label">عدد الفواتير</span>
    <strong class="kpi__value"><?= $invoiceCount ?></strong>
    <span class="kpi__unit"><?= (int) $day['voided'] > 0 ? 'منها ' . (int) $day['voided'] . ' ملغاة' : 'فاتورة' ?></span>
  </div>
  <div class="kpi">
    <span class="kpi__label">متوسط الفاتورة</span>
    <strong class="kpi__value"><?= h(money_display($averageC)) ?></strong>
    <span class="kpi__unit"><?= h(APP_CURRENCY) ?></span>
  </div>
  <div class="kpi">
    <span class="kpi__label">الأصناف المباعة</span>
    <strong class="kpi__value"><?= h(qty_display($soldQtyC)) ?></strong>
    <span class="kpi__unit">قطعة من <?= $soldKinds ?> صنف</span>
  </div>
</section>
<?php if ($zeroLines > 0): ?>
  <div class="alert alert--warn"><?= $zeroLines ?> بند بيع بسعر 0.00 <?= $where ?>: الأسعار لم تُحدَّد بعد لهذه الأصناف.</div>
<?php endif; ?>

<div class="cards-grid">
  <section class="card card--flush">
    <div class="card__head"><h2 class="card__title">الأصناف المباعة — <?= $periodHtml ?> <span class="badge badge--info"><?= $soldKinds ?></span></h2></div>
    <?php if (!$top): ?>
      <p class="empty">لا توجد مبيعات <?= $where ?>.</p>
    <?php else: ?>
      <?php if ($soldKinds > count($top)): ?><p class="muted small card__note">أعلى <?= count($top) ?> صنفاً كمية من <?= $soldKinds ?>.</p><?php endif; ?>
      <div class="table-wrap table-wrap--tall">
        <table class="grid">
          <thead><tr><th>الصنف</th><th>الباركود</th><th class="num">الكمية</th><th class="num">الإيراد</th></tr></thead>
          <tbody>
          <?php foreach ($top as $row): ?>
            <tr>
              <td><?= h($row['name']) ?></td>
              <td class="mono"><?= h($row['barcode']) ?></td>
              <td class="num"><?= h(qty_display((string) $row['qty'])) ?></td>
              <td class="num"><?= h(money_display((string) $row['revenue'])) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </section>

  <section class="card card--flush">
    <div class="card__head">
      <h2 class="card__title">تنبيه نقص المخزون <span class="badge badge--danger"><?= $lowCount ?></span></h2>
      <?php if ($lowCount > count($low)): ?>
        <a class="btn btn--sm" href="index.php?page=inventory&amp;filter=low">عرض الكل في المخزون</a>
      <?php endif; ?>
    </div>
    <?php if (!$low): ?>
      <p class="empty">لا توجد أصناف تحت حد التنبيه.</p>
    <?php else: ?>
      <div class="table-wrap table-wrap--tall">
        <table class="grid">
          <thead><tr><th>الصنف</th><th>الباركود</th><th class="num">الرصيد</th><th class="num">حد التنبيه</th></tr></thead>
          <tbody>
          <?php foreach ($low as $row): ?>
            <tr>
              <td><?= h($row['product_name']) ?><?= (int) $row['is_barcoded'] ? '' : ' <span class="badge badge--muted">يدوي</span>' ?></td>
              <td class="mono"><?= h($row['barcode']) ?></td>
              <td class="num qty-low"><?= h(qty_display((string) $row['stock_quantity'])) ?></td>
              <td class="num"><?= h(qty_display((string) $row['min_alert_qty'])) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </section>
</div>
