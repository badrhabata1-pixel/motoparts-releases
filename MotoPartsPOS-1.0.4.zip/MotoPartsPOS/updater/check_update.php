<?php
/**
 * فحص التحديث. المصدر UPDATE_MANIFEST_URL:
 * - رابط HTTPS: النتيجة تُحفظ UPDATE_CHECK_CACHE_SECONDS فقط (لا حظر يومي)، فإصدار يُرفع في منتصف اليوم يظهر
 *   خلال دقيقة. الرابط يُطلب بمعامل ?t= يتغير كل دقيقة فلا تعيد شبكة GitHub نسخة قديمة من latest_version.json.
 *   انقطاع الإنترنت حالة طبيعية في المحل: يعيد available=false بهدوء ولا يعطّل أي شيء.
 * - مسار latest_version.json في مجلد على هذا الجهاز أو فلاشة: يُقرأ في كل فحص، فيكفي نسخ الملفين
 *   (latest_version.json و MotoPartsPOS-x.y.z.zip) إلى المجلد ليظهر إشعار التحديث.
 */
require __DIR__ . '/../includes/api.php';
require __DIR__ . '/../includes/http.php';
require __DIR__ . '/lib.php';

require_method('GET');

const UPDATE_CHECK_CACHE_SECONDS = 60;

if (UPDATE_MANIFEST_URL === '') {
    json_ok(['enabled' => false, 'current' => APP_VERSION, 'available' => false]);
}

$local = updater_local_manifest();
$state = updater_load_state();
$age = time() - (int) ($state['checked_at'] ?? 0);
if ($local === null && ($_GET['force'] ?? '') !== '1' && $age >= 0 && $age < UPDATE_CHECK_CACHE_SECONDS && is_array($state['result'] ?? null)
    && ($state['result']['current'] ?? '') === APP_VERSION) {
    json_ok($state['result'] + ['cached' => true]);
}

$result = ['enabled' => true, 'source' => $local === null ? 'online' : 'local', 'current' => APP_VERSION, 'available' => false];
$body = null;
if ($local !== null) {
    if (is_file($local)) {
        $body = (string) file_get_contents($local, false, null, 0, 65536);
    } else {
        $result['offline'] = true;
        $result['message'] = 'لا يوجد ملف تحديث في ' . $local;
    }
} else {
    $url = UPDATE_MANIFEST_URL . (strpos(UPDATE_MANIFEST_URL, '?') === false ? '?' : '&') . 't=' . intdiv(time(), 60);
    $response = http_get($url, 8, null, 65536);
    if ($response['error'] !== null || $response['status'] !== 200) {
        $result['offline'] = true;
        $result['message'] = 'تعذر الوصول إلى خادم التحديث.';
    } else {
        $body = (string) $response['body'];
    }
}

if ($body !== null) {
    try {
        // BOM: ملف عُدّل وحُفظ بالمفكرة.
        $manifest = updater_validate_manifest(json_decode(preg_replace('/^\xEF\xBB\xBF/', '', $body), true),
            $local === null ? null : dirname($local));
        $result['latest'] = $manifest['version'];
        $result['notes'] = $manifest['notes'];
        $result['available'] = version_compare($manifest['version'], APP_VERSION, '>');
        if ($result['available'] && isset($manifest['file']) && !is_file($manifest['file'])) {
            $result['available'] = false;
            $result['message'] = 'حزمة التحديث ' . basename($manifest['file']) . ' غير موجودة بجوار latest_version.json.';
        }
        if ($result['available']) {
            $state['manifest'] = $manifest;
        } else {
            unset($state['manifest']);
        }
    } catch (UserError $e) {
        $result['message'] = $e->getMessage();
    }
}

$state['checked_at'] = time();
unset($state['checked_on']);
$state['result'] = $result;
updater_save_state($state);
json_ok($result);
