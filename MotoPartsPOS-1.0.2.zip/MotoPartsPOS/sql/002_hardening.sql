-- 002: تقوية المخطط (انظر تقرير الفحص المعماري، قسم "تعديلات المخطط على قاعدة البيانات").
-- كل جملة آمنة لإعادة التشغيل (IF EXISTS / IF NOT EXISTS) ولا تحذف أي بيانات.
-- تعمل أيضاً على قاعدة أُنشئت من نسخة أقدم من المخطط (بلا min_alert_qty أو الفهارس).
-- الصيغة خاصة بـ MariaDB (المرفقة مع XAMPP).

-- ── products ──────────────────────────────────────────────────────────────
ALTER TABLE products ADD COLUMN IF NOT EXISTS min_alert_qty DECIMAL(10,2) DEFAULT 5.00 AFTER is_barcoded;
ALTER TABLE products ADD COLUMN IF NOT EXISTS search_key VARCHAR(255) NOT NULL DEFAULT '' AFTER product_name;
ALTER TABLE products ADD COLUMN IF NOT EXISTS is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER min_alert_qty;
ALTER TABLE products ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP NULL DEFAULT NULL AFTER created_at;

-- لا NULL في الأرقام: NULL - 1 = NULL كان سيُفسد الرصيد بصمت.
UPDATE products SET stock_quantity = 0 WHERE stock_quantity IS NULL;
UPDATE products SET buy_price = 0 WHERE buy_price IS NULL;
UPDATE products SET sell_price = 0 WHERE sell_price IS NULL;
UPDATE products SET is_barcoded = 1 WHERE is_barcoded IS NULL;
UPDATE products SET min_alert_qty = 5.00 WHERE min_alert_qty IS NULL;
ALTER TABLE products
    MODIFY stock_quantity DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    MODIFY buy_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    MODIFY sell_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    MODIFY is_barcoded TINYINT(1) NOT NULL DEFAULT 1,
    MODIFY min_alert_qty DECIMAL(10,2) NOT NULL DEFAULT 5.00;

-- idx_barcode مكرر: قيد UNIQUE على barcode ينشئ فهرساً بالفعل.
ALTER TABLE products DROP INDEX IF EXISTS idx_barcode;
ALTER TABLE products ADD INDEX IF NOT EXISTS idx_name (product_name);
ALTER TABLE products ADD INDEX IF NOT EXISTS idx_active_barcoded (is_active, is_barcoded);

-- ── invoices ──────────────────────────────────────────────────────────────
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS client_uuid CHAR(36) NULL DEFAULT NULL AFTER invoice_number;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS returned_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER total_amount;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS status VARCHAR(12) NOT NULL DEFAULT 'completed' AFTER returned_amount;

UPDATE invoices SET total_amount = 0 WHERE total_amount IS NULL;
UPDATE invoices SET customer_name = 'عميل نقدي' WHERE customer_name IS NULL OR customer_name = '';
UPDATE invoices SET customer_phone = '' WHERE customer_phone IS NULL;
ALTER TABLE invoices
    MODIFY customer_name VARCHAR(150) NOT NULL DEFAULT 'عميل نقدي',
    MODIFY customer_phone VARCHAR(50) NOT NULL DEFAULT '',
    MODIFY total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00;

-- مفتاح عدم التكرار: إعادة إرسال الفاتورة نفسها تعيد الفاتورة المحفوظة بدلاً من إنشاء ثانية.
ALTER TABLE invoices ADD UNIQUE INDEX IF NOT EXISTS uq_client_uuid (client_uuid);
ALTER TABLE invoices ADD INDEX IF NOT EXISTS idx_created (created_at);

-- ── invoice_items ─────────────────────────────────────────────────────────
-- لقطة من الباركود والاسم وقت البيع: تعديل بطاقة الصنف لاحقاً لا يغيّر الفواتير القديمة.
ALTER TABLE invoice_items ADD COLUMN IF NOT EXISTS barcode VARCHAR(100) NOT NULL DEFAULT '' AFTER product_id;
ALTER TABLE invoice_items ADD COLUMN IF NOT EXISTS product_name VARCHAR(255) NOT NULL DEFAULT '' AFTER barcode;
ALTER TABLE invoice_items ADD COLUMN IF NOT EXISTS returned_qty DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER subtotal;
UPDATE invoice_items ii JOIN products p ON p.id = ii.product_id
   SET ii.barcode = p.barcode, ii.product_name = p.product_name
 WHERE ii.product_name = '';

-- ON DELETE CASCADE كان يمحو بنود المبيعات بصمت عند حذف صنف. الأصناف التي لها مبيعات تُخفى ولا تُحذف.
ALTER TABLE invoice_items DROP FOREIGN KEY IF EXISTS invoice_items_ibfk_2;
ALTER TABLE invoice_items ADD CONSTRAINT fk_items_product FOREIGN KEY IF NOT EXISTS (product_id) REFERENCES products (id) ON DELETE RESTRICT;

-- ── جداول جديدة ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS app_meta (
    meta_key VARCHAR(50) NOT NULL PRIMARY KEY,
    meta_value VARCHAR(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- تسلسل الباركود ورقم الفاتورة. يُقفل بـ SELECT ... FOR UPDATE فلا يتكرر رقم حتى مع جهازي كاشير.
CREATE TABLE IF NOT EXISTS sequences (
    name VARCHAR(30) NOT NULL PRIMARY KEY,
    next_value BIGINT UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO sequences (name, next_value) VALUES ('barcode', 100001), ('invoice', 1);
UPDATE sequences
   SET next_value = GREATEST(next_value, (SELECT COALESCE(MAX(CAST(barcode AS UNSIGNED)), 0) + 1 FROM products WHERE barcode REGEXP '^[0-9]{6}$'))
 WHERE name = 'barcode';
UPDATE sequences
   SET next_value = GREATEST(next_value, (SELECT COALESCE(MAX(CAST(invoice_number AS UNSIGNED)), 0) + 1 FROM invoices WHERE invoice_number REGEXP '^[0-9]+$'))
 WHERE name = 'invoice';

-- دفتر حركة المخزون: كل تغيير في الرصيد (بيع، مرتجع، توريد، جرد) بسطر يحمل الرصيد بعده.
CREATE TABLE IF NOT EXISTS stock_movements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    change_qty DECIMAL(10,2) NOT NULL,
    balance_after DECIMAL(10,2) NOT NULL,
    reason VARCHAR(20) NOT NULL,
    ref_id INT NULL,
    note VARCHAR(255) NOT NULL DEFAULT '',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_mv_product (product_id, id),
    CONSTRAINT fk_mv_product FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- المرتجعات بتاريخها الفعلي: تُخصم من مبيعات يوم الإرجاع، لا يوم البيع.
CREATE TABLE IF NOT EXISTS invoice_returns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    is_void TINYINT(1) NOT NULL DEFAULT 0,
    note VARCHAR(255) NOT NULL DEFAULT '',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ret_created (created_at),
    CONSTRAINT fk_ret_invoice FOREIGN KEY (invoice_id) REFERENCES invoices (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS invoice_return_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    return_id INT NOT NULL,
    invoice_item_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_ri_return FOREIGN KEY (return_id) REFERENCES invoice_returns (id) ON DELETE CASCADE,
    CONSTRAINT fk_ri_item FOREIGN KEY (invoice_item_id) REFERENCES invoice_items (id) ON DELETE RESTRICT,
    CONSTRAINT fk_ri_product FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
