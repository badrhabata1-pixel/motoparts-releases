-- 007: تسجيل الدخول. جدول المستخدمين والمستخدم الافتراضي (مدير).
-- كلمة المرور مخزنة كبصمة bcrypt من password_hash() في PHP، لا نصاً صريحاً، وتُفحص بـ password_verify().
-- اسم المستخدم لا يفرّق بين الحروف الكبيرة والصغيرة (ترتيب utf8mb4_unicode_ci)، وكلمة المرور تفرّق.
-- آمن لإعادة التشغيل: INSERT IGNORE لا يكتب فوق مستخدم موجود ولا فوق كلمة مرور غُيّرت لاحقاً.

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username VARCHAR(50) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'admin',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO users (username, password_hash, role)
VALUES ('ADMin_motor', '$2y$10$keHex0Rs8X1w1/Qncb7DPONSUVpdnSOok0Qcpryuivpw.dm9or9Ky', 'admin');
