-- 006: الفاتورة التي رجعت كل كمياتها بمرتجعات جزئية تُغلق (void) "مرتجعة بالكامل"،
-- كما يفعل حفظ المرتجع تلقائياً من هذا الإصدار. الحالة فقط تتغير: المبالغ والمخزون والتقارير كما هي.
-- آمن لإعادة التشغيل: لا يلمس إلا فواتير مكتملة لم يبقَ فيها أي كمية.

UPDATE invoices i
   SET i.status = 'void'
 WHERE i.status = 'completed'
   AND EXISTS (SELECT 1 FROM invoice_items ii WHERE ii.invoice_id = i.id)
   AND NOT EXISTS (SELECT 1 FROM invoice_items ii WHERE ii.invoice_id = i.id AND ii.quantity > ii.returned_qty);
