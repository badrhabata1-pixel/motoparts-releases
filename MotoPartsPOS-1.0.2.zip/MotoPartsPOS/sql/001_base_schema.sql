-- 001: المخطط الأصلي كما ورد في المواصفات حرفياً.
-- التعديلات عليه ومبرراتها في 002_hardening.sql (وفي تقرير الفحص المعماري).
-- يمكن استيراد هذا الملف من phpMyAdmin مباشرة؛ أداة الترحيل في install.php تتجاهل سطري CREATE DATABASE و USE.

CREATE DATABASE IF NOT EXISTS motoparts_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE motoparts_db;

-- 1. Inventory & Products Table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    barcode VARCHAR(100) NOT NULL UNIQUE,
    product_name VARCHAR(255) NOT NULL,
    stock_quantity DECIMAL(10, 2) DEFAULT 0.00,
    buy_price DECIMAL(10, 2) DEFAULT 0.00,
    sell_price DECIMAL(10, 2) DEFAULT 0.00,
    is_barcoded TINYINT(1) DEFAULT 1,
    min_alert_qty DECIMAL(10, 2) DEFAULT 5.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_barcode (barcode),
    INDEX idx_name (product_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Invoices Master Table
CREATE TABLE IF NOT EXISTS invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(50) NOT NULL UNIQUE,
    customer_name VARCHAR(150) DEFAULT 'عميل نقدي',
    customer_phone VARCHAR(50) DEFAULT '',
    total_amount DECIMAL(10, 2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Invoice Items Line Details
CREATE TABLE IF NOT EXISTS invoice_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity DECIMAL(10, 2) NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
