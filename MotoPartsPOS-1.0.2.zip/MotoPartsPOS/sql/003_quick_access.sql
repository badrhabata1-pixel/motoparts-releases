-- 003: الوصول السريع [F3]: أصناف يختارها الكاشير أو المالك لتظهر في نافذة F3 وتُضاف للفاتورة بنقرة واحدة.
-- NOT NULL: علامة فارغة (NULL) لا تُعدّ مفعّلة ولا معطّلة، فتختفي من القائمة ومن التصفية معاً.

ALTER TABLE products ADD COLUMN IF NOT EXISTS is_quick_access TINYINT(1) NOT NULL DEFAULT 0 AFTER is_barcoded;

-- نافذة F3 تجلب is_quick_access = 1 AND is_active = 1، والفهرس المركب يجيبها مباشرة دون مسح الجدول.
ALTER TABLE products ADD INDEX IF NOT EXISTS idx_quick_access (is_quick_access, is_active);
