-- 005: ملاحظات البنود والأصناف.
-- invoice_items.notes: ملاحظة الكاشير على سطر البيع (مثال: "أخذ 5 من أصل 50") وتبقى مع الفاتورة.
-- products.notes: آخر حالة للصنف؛ تتحدث من أي بيع يحمل ملاحظة، ويمكن تعديلها يدوياً من المخزون.
-- NOT NULL DEFAULT '': الملاحظة الفارغة نص فارغ دائماً، فلا حاجة لمعالجة NULL في أي مكان.

ALTER TABLE invoice_items ADD COLUMN IF NOT EXISTS notes VARCHAR(255) NOT NULL DEFAULT '' AFTER subtotal;
ALTER TABLE products ADD COLUMN IF NOT EXISTS notes VARCHAR(255) NOT NULL DEFAULT '' AFTER search_key;
