<?php
/**
 * تسجيل الخروج: POST فقط من زر الشريط العلوي ومعه رمز الجلسة (csrf)،
 * فلا تستطيع صفحة من موقع آخر إخراج الكاشير برابط.
 */
define('PUBLIC_PAGE', true);
require __DIR__ . '/includes/bootstrap.php';

if (!request_host_allowed()) {
    http_response_code(403);
    exit('Forbidden host');
}

$site = $_SERVER['HTTP_SEC_FETCH_SITE'] ?? '';
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST' || ($site !== '' && $site !== 'same-origin')
    || !auth_csrf_valid($_POST['csrf'] ?? null)) {
    header('Location: index.php');
    exit;
}

auth_logout();
header('Location: login.php?bye=1');
