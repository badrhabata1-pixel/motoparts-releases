<?php
/**
 * حفظ الفاتورة في معاملة واحدة (ACID): رقم الفاتورة، البنود، خصم المخزون، ودفتر الحركة.
 *
 * POST JSON: {client_uuid, customer_name, customer_phone, save_prices, items: [{product_id, quantity, unit_price, note}]}
 *
 * - الخادم يعيد حساب كل الإجماليات بأعداد صحيحة (قروش) ولا يثق بأي إجمالي من المتصفح.
 * - ملاحظة البند (مثل "أخذ 5 من أصل 50") تُحفظ مع السطر وفي دفتر الحركة، وتصبح ملاحظة الصنف في المخزون.
 *   البند بلا ملاحظة لا يمسح ملاحظة الصنف.
 * - client_uuid يجعل الحفظ آمناً لإعادة الإرسال: الطلب المكرر يعيد الفاتورة المحفوظة نفسها.
 * - الأصناف تُقفل بترتيب id ثابت، فلا يحدث deadlock بين جهازي كاشير.
 */
require __DIR__ . '/../includes/api.php';
require __DIR__ . '/../includes/inventory.php';

require_method('POST');
$in = request_json();

$uuid = strtolower((string) ($in['client_uuid'] ?? ''));
if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/', $uuid)) {
    throw new UserError('معرّف الفاتورة غير صالح. أعد تحميل الصفحة.');
}
$customer = clean_text((string) ($in['customer_name'] ?? ''), 150);
if ($customer === '') {
    $customer = 'عميل نقدي';
}
$phone = preg_replace('/[^0-9+\- ]/', '', clean_text(normalize_digits((string) ($in['customer_phone'] ?? '')), 50)) ?? '';
$savePrices = !empty($in['save_prices']);

$items = $in['items'] ?? null;
if (!is_array($items) || !$items) {
    throw new UserError('الفاتورة فارغة.');
}
if (count($items) > 500) {
    throw new UserError('عدد البنود كبير جداً (الحد 500 بند).');
}

$lines = [];
foreach (array_values($items) as $i => $item) {
    $n = $i + 1;
    $productId = (int) ($item['product_id'] ?? 0);
    $qty = to_hundredths(is_scalar($item['quantity'] ?? null) ? (string) $item['quantity'] : '');
    $price = to_hundredths(is_scalar($item['unit_price'] ?? null) ? (string) $item['unit_price'] : '');
    if ($productId <= 0) {
        throw new UserError("البند رقم $n: صنف غير صالح.");
    }
    if ($qty === null || $qty <= 0 || $qty > 9999999) {
        throw new UserError("البند رقم $n: الكمية يجب أن تكون بين 0.01 و 99999.99.");
    }
    if ($price === null || $price < 0 || $price > 999999999) {
        throw new UserError("البند رقم $n: السعر غير صالح.");
    }
    $note = is_scalar($item['note'] ?? null) ? clean_text((string) $item['note'], 255) : '';
    $lines[] = ['product_id' => $productId, 'qty' => $qty, 'price' => $price, 'note' => $note];
}

function invoice_summary(PDO $pdo, string $where, array $params): ?array
{
    $st = $pdo->prepare("SELECT i.id, i.invoice_number, i.customer_name, i.total_amount, i.created_at,
                                (SELECT COUNT(*) FROM invoice_items ii WHERE ii.invoice_id = i.id) AS line_count
                           FROM invoices i WHERE $where");
    $st->execute($params);
    $row = $st->fetch();
    if (!$row) {
        return null;
    }
    return [
        'id'            => (int) $row['id'],
        'number'        => (string) $row['invoice_number'],
        'customer_name' => (string) $row['customer_name'],
        'total'         => (string) $row['total_amount'],
        'created_at'    => (string) $row['created_at'],
        'lines'         => (int) $row['line_count'],
    ];
}

$pdo = db();
$existing = invoice_summary($pdo, 'i.client_uuid = ?', [$uuid]);
if ($existing) {
    json_ok(['invoice' => $existing, 'duplicate' => true, 'warnings' => [], 'prices_saved' => 0]);
}

try {
    $result = with_transaction($pdo, function (PDO $pdo) use ($lines, $uuid, $customer, $phone, $savePrices): array {
        $ids = array_values(array_unique(array_column($lines, 'product_id')));
        sort($ids);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $st = $pdo->prepare("SELECT id, barcode, product_name, stock_quantity, sell_price, is_active
                               FROM products WHERE id IN ($placeholders) ORDER BY id FOR UPDATE");
        $st->execute($ids);
        $products = [];
        foreach ($st as $row) {
            $products[(int) $row['id']] = $row;
        }

        $requested = [];
        foreach ($lines as $line) {
            $p = $products[$line['product_id']] ?? null;
            if (!$p) {
                throw new UserError('صنف في الفاتورة لم يعد موجوداً في المخزون. احذفه من الفاتورة.', 409,
                    ['code' => 'missing_product', 'product_id' => $line['product_id']]);
            }
            if (!(int) $p['is_active']) {
                throw new UserError('الصنف "' . $p['product_name'] . '" محذوف من المخزون. احذفه من الفاتورة.', 409,
                    ['code' => 'inactive_product', 'product_id' => $line['product_id']]);
            }
            $requested[$line['product_id']] = ($requested[$line['product_id']] ?? 0) + $line['qty'];
        }

        $balance = [];
        $short = [];
        foreach ($requested as $pid => $qty) {
            $balance[$pid] = to_hundredths((string) $products[$pid]['stock_quantity']) ?? 0;
            if ($qty > $balance[$pid]) {
                $short[] = [
                    'product_id' => $pid,
                    'name'       => $products[$pid]['product_name'],
                    'stock'      => from_hundredths($balance[$pid]),
                    'requested'  => from_hundredths($qty),
                ];
            }
        }
        if ($short && !ALLOW_NEGATIVE_STOCK) {
            throw new UserError('الكمية المطلوبة أكبر من الرصيد المسجل لبعض الأصناف.', 409,
                ['code' => 'insufficient_stock', 'items' => $short]);
        }
        $warnings = [];
        foreach ($short as $s) {
            $warnings[] = 'الرصيد أصبح سالباً: ' . $s['name'];
        }

        $number = sequence_lock($pdo, 'invoice', 1);
        $taken = $pdo->prepare('SELECT 1 FROM invoices WHERE invoice_number = ?');
        while (true) {
            $taken->execute([(string) $number]);
            if ($taken->fetchColumn() === false) {
                break;
            }
            $number++;
        }
        sequence_store($pdo, 'invoice', $number + 1);

        $total = 0;
        foreach ($lines as $k => $line) {
            $lines[$k]['subtotal'] = line_subtotal($line['price'], $line['qty']);
            $total += $lines[$k]['subtotal'];
        }

        $pdo->prepare('INSERT INTO invoices (invoice_number, client_uuid, customer_name, customer_phone, total_amount)
                       VALUES (?, ?, ?, ?, ?)')
            ->execute([(string) $number, $uuid, $customer, $phone, from_hundredths($total)]);
        $invoiceId = (int) $pdo->lastInsertId();

        $insertItem = $pdo->prepare('INSERT INTO invoice_items (invoice_id, product_id, barcode, product_name, quantity, unit_price, subtotal, notes)
                                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $deduct = $pdo->prepare('UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?');
        $setNote = $pdo->prepare('UPDATE products SET notes = ? WHERE id = ?');
        foreach ($lines as $line) {
            $pid = $line['product_id'];
            $p = $products[$pid];
            $insertItem->execute([
                $invoiceId, $pid, $p['barcode'], $p['product_name'],
                from_hundredths($line['qty']), from_hundredths($line['price']), from_hundredths($line['subtotal']), $line['note'],
            ]);
            $deduct->execute([from_hundredths($line['qty']), $pid]);
            $balance[$pid] -= $line['qty'];
            record_movement($pdo, $pid, -$line['qty'], $balance[$pid], 'sale', $invoiceId, $line['note']);
            if ($line['note'] !== '') {
                $setNote->execute([$line['note'], $pid]);       // آخر حالة للصنف في المخزون
            }
        }

        // اختياري: السعر الذي كتبه الكاشير يصبح سعر البيع للأصناف التي سعرها صفر فقط.
        $pricesSaved = 0;
        if ($savePrices) {
            $setPrice = $pdo->prepare('UPDATE products SET sell_price = ?, updated_at = NOW() WHERE id = ? AND sell_price = 0');
            $done = [];
            foreach ($lines as $line) {
                $pid = $line['product_id'];
                if ($line['price'] > 0 && !isset($done[$pid]) && (to_hundredths((string) $products[$pid]['sell_price']) ?? 0) === 0) {
                    $setPrice->execute([from_hundredths($line['price']), $pid]);
                    $pricesSaved += $setPrice->rowCount();
                    $done[$pid] = true;
                }
            }
        }

        return ['id' => $invoiceId, 'warnings' => $warnings, 'prices_saved' => $pricesSaved];
    });
} catch (PDOException $e) {
    // طلبان متزامنان بنفس client_uuid: الثاني يصطدم بالفهرس الفريد، فنعيد الفاتورة التي حفظها الأول.
    if ((int) ($e->errorInfo[1] ?? 0) === 1062 && strpos($e->getMessage(), 'uq_client_uuid') !== false) {
        $existing = invoice_summary($pdo, 'i.client_uuid = ?', [$uuid]);
        if ($existing) {
            json_ok(['invoice' => $existing, 'duplicate' => true, 'warnings' => [], 'prices_saved' => 0]);
        }
    }
    throw $e;
}

json_ok([
    'invoice'      => invoice_summary($pdo, 'i.id = ?', [$result['id']]),
    'duplicate'    => false,
    'warnings'     => $result['warnings'],
    'prices_saved' => $result['prices_saved'],
]);
