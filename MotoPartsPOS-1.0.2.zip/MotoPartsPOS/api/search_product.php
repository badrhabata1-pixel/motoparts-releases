<?php
/**
 * البحث عن الأصناف.
 *   GET ?barcode=100001                    مطابقة تامة على الفهرس الفريد (الماسح الضوئي)
 *   GET ?list=fast                         الأكثر مبيعاً آخر 30 يوماً (نافذة F1)
 *   GET ?list=unbarcoded                   الأصناف اليدوية بلا ملصق (نافذة F2)
 *   GET ?list=quick                        أصناف الوصول السريع (نافذة F3)، من الفهرس idx_quick_access
 *   GET ?q=مساعد&filter=low&limit=50&offset=0&count=1&dups=1
 *       بحث حي: كل كلمة يجب أن توجد في search_key المطبَّع (ى=ي، ة=ه، أ=ا).
 */
require __DIR__ . '/../includes/api.php';
require __DIR__ . '/../includes/inventory.php';

require_method('GET');
$pdo = db();

if (isset($_GET['barcode'])) {
    $code = normalize_barcode((string) $_GET['barcode']);
    if ($code === '') {
        throw new UserError('الباركود فارغ.');
    }
    $st = $pdo->prepare('SELECT ' . PRODUCT_COLUMNS . ' FROM products WHERE barcode = ? LIMIT 1');
    $st->execute([$code]);
    $product = $st->fetch();
    if (!$product) {
        throw new UserError('الباركود غير مسجل: ' . $code, 404, ['code' => 'not_found', 'barcode' => $code]);
    }
    if (!(int) $product['is_active']) {
        throw new UserError('هذا الصنف محذوف من المخزون: ' . $product['product_name'], 410, ['code' => 'inactive']);
    }
    json_ok(['product' => product_out($product)]);
}

$q = clean_text((string) ($_GET['q'] ?? ''), 100);
$list = (string) ($_GET['list'] ?? '');
$filter = (string) ($_GET['filter'] ?? 'all');
$limit = max(1, min(300, (int) ($_GET['limit'] ?? 30)));
$offset = max(0, (int) ($_GET['offset'] ?? 0));

if ($list === 'fast' && $q === '') {
    $items = [];
    foreach (fast_sellers($pdo, PRODUCT_COLUMNS) as $row) {
        $items[] = product_out($row) + ['sold' => (string) $row['sold']];
    }
    json_ok(['items' => $items]);
}

if ($list === 'unbarcoded' || $list === 'quick') {
    $filter = $list;
    $limit = max($limit, 300);
}

[$whereSql, $params, $exact] = product_filter_sql($q, $filter);

$order = 'product_name ASC, id ASC';       // الأسماء المكررة تظهر متجاورة
$orderParams = [];
if ($filter === 'low' || $filter === 'negative') {
    $order = 'stock_quantity ASC, ' . $order;
}
if ($exact !== '') {
    $order = '(barcode = ?) DESC, ' . $order;
    $orderParams[] = $exact;
}

$st = $pdo->prepare('SELECT ' . PRODUCT_COLUMNS . " FROM products WHERE $whereSql ORDER BY $order LIMIT $limit OFFSET $offset");
$st->execute(array_merge($params, $orderParams));
$rows = $st->fetchAll();
$result = ['items' => array_map('product_out', $rows)];

if (!empty($_GET['count'])) {
    $st = $pdo->prepare("SELECT COUNT(*) FROM products WHERE $whereSql");
    $st->execute($params);
    $result['total'] = (int) $st->fetchColumn();
}

// عدد السجلات التي تحمل الاسم نفسه: نتيجة قاعدة عدم الدمج، تظهر كشارة "مكرر ×3" في المخزون.
if (!empty($_GET['dups']) && $rows) {
    $names = array_values(array_unique(array_column($rows, 'product_name')));
    $in = implode(',', array_fill(0, count($names), '?'));
    $st = $pdo->prepare("SELECT product_name, COUNT(*) AS n FROM products
                          WHERE is_active = 1 AND product_name IN ($in)
                          GROUP BY product_name HAVING n > 1");
    $st->execute($names);
    $dups = [];
    foreach ($st as $row) {
        $dups[mb_strtolower(trim($row['product_name']))] = (int) $row['n'];
    }
    foreach ($result['items'] as &$item) {
        $item['dups'] = $dups[mb_strtolower(trim($item['name']))] ?? 1;
    }
    unset($item);
}

json_ok($result);
