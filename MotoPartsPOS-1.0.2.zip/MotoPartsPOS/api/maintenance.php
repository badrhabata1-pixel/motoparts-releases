<?php
/**
 * الصيانة والنسخ الاحتياطي.
 *   POST {action: daily}    أول تشغيل في اليوم: نسخة احتياطية، حذف النسخ الأقدم من BACKUP_KEEP، تنظيف الملفات المؤقتة
 *   POST {action: backup}   نسخة احتياطية الآن
 *   GET  ?action=backups    قائمة النسخ
 *   GET  ?action=download&file=...   تنزيل نسخة (لنقلها إلى فلاشة)
 */
require __DIR__ . '/../includes/api.php';
require __DIR__ . '/../includes/inventory.php';
require __DIR__ . '/../includes/backup.php';

set_time_limit(300);
$dir = storage_path('backups');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    $action = (string) ($_GET['action'] ?? 'backups');
    if ($action === 'download') {
        $file = basename((string) ($_GET['file'] ?? ''));
        if (!preg_match('/^[A-Za-z0-9_\-]+-\d{8}-\d{6}\.sql\.gz$/', $file) || !is_file($dir . '/' . $file)) {
            throw new UserError('ملف النسخة غير موجود.', 404);
        }
        header('Content-Type: application/gzip');
        header('Content-Disposition: attachment; filename="' . $file . '"');
        header('Content-Length: ' . filesize($dir . '/' . $file));
        header('Cache-Control: no-store');
        readfile($dir . '/' . $file);
        exit;
    }
    json_ok(['items' => list_backups($dir), 'dir' => str_replace('/', '\\', $dir), 'keep' => (int) BACKUP_KEEP]);
}

require_method('POST');
$in = request_json();
$action = (string) ($in['action'] ?? '');
$pdo = db();

if ($action === 'backup') {
    $backup = backup_database($pdo, $dir);
    prune_backups($dir, (int) BACKUP_KEEP);
    json_ok(['file' => basename($backup['file']), 'size' => $backup['size']]);
}

if ($action === 'daily') {
    // قفل على مستوى الخادم: لو فُتحت نافذتان معاً تعمل المهمة مرة واحدة فقط.
    if ((int) $pdo->query("SELECT GET_LOCK('motoparts_daily', 0)")->fetchColumn() !== 1) {
        json_ok(['ran' => false, 'busy' => true]);
    }
    // json_ok() ينهي السكربت فلا يصل إلى finally، لذلك تُجهَّز النتيجة أولاً ثم يُحرَّر القفل ثم يُرسل الرد.
    try {
        $today = date('Y-m-d');
        $result = ['ran' => false];
        if (meta_get($pdo, 'daily_run_on') !== $today) {
            $backup = backup_database($pdo, $dir);
            $pruned = prune_backups($dir, (int) BACKUP_KEEP);
            $keys = rebuild_search_keys($pdo);
            foreach (glob(storage_path('tmp') . '/*') ?: [] as $tmp) {
                if (is_file($tmp) && filemtime($tmp) < time() - 86400) {
                    @unlink($tmp);
                }
            }
            meta_set($pdo, 'daily_run_on', $today);
            $result = ['ran' => true, 'backup' => basename($backup['file']), 'size' => $backup['size'], 'pruned' => $pruned, 'search_keys' => $keys];
        }
    } finally {
        $pdo->query("SELECT RELEASE_LOCK('motoparts_daily')");
    }
    json_ok($result);
}

throw new UserError('إجراء غير معروف.');
