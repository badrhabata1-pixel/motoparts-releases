<?php
/**
 * تحديث الأسعار بالجملة من ملف [الباركود، السعر الجديد، (سعر الشراء الجديد)]، على خطوتين:
 *   POST action=preview + file (+ sheet)          ما سيتغير فعلاً، والباركودات غير الموجودة، والقيم غير الصالحة
 *   POST action=rescan + token + sheet + map(JSON)  المعاينة نفسها بورقة أو أعمدة اختارها المستخدم
 *   POST action=commit + token + sheet + map(JSON)  التحديث في معاملة واحدة
 * الخلية الفارغة تعني "بلا تغيير" وليست صفراً، فملف فيه سعر البيع فقط لا يمس سعر الشراء.
 */
require __DIR__ . '/../includes/api.php';
require __DIR__ . '/../includes/inventory.php';
require __DIR__ . '/../includes/importer.php';

require_method('POST');
set_time_limit(300);

$action = (string) ($_POST['action'] ?? '');
if ($action === 'preview') {
    $upload = store_upload('file', 'prices');
} elseif ($action === 'rescan' || $action === 'commit') {
    $upload = load_upload((string) ($_POST['token'] ?? ''), 'prices');
} else {
    throw new UserError('إجراء غير معروف.');
}

$reader = SpreadsheetReader::open($upload['path'], $upload['name']);
$sheets = $reader->sheets();
$sheetIndex = isset($_POST['sheet']) && $_POST['sheet'] !== '' ? (int) $_POST['sheet'] : null;
if ($sheetIndex === null) {
    foreach ($sheets as $sheet) {
        if (!$sheet['hidden']) {
            $sheetIndex = $sheet['index'];
            break;
        }
    }
}
if (!isset(array_column($sheets, 'name', 'index')[$sheetIndex])) {
    throw new UserError('الورقة المختارة غير موجودة في الملف.');
}
$map = $action === 'preview' ? null : json_decode((string) ($_POST['map'] ?? 'null'), true);

$scan = scan_price_sheet($reader, (int) $sheetIndex, is_array($map) ? $map : null);
$pdo = db();
$match = match_price_entries($pdo, $scan['entries']);

if ($action !== 'commit') {
    $sample = [];
    foreach (array_slice($match['changes'], 0, 25) as $c) {
        $sample[] = [
            'barcode'  => $c['barcode'], 'name' => $c['name'],
            'old_sell' => from_hundredths($c['old_sell']), 'new_sell' => from_hundredths($c['new_sell']),
            'old_buy'  => from_hundredths($c['old_buy']), 'new_buy' => from_hundredths($c['new_buy']),
        ];
    }
    $missingColumn = $scan['map']['barcode'] === null || ($scan['map']['sell'] === null && $scan['map']['buy'] === null);
    json_ok([
        'token'     => $upload['token'],
        'file_name' => $upload['name'],
        'sheets'    => $sheets,
        'sheet'     => $sheetIndex,
        'map'       => $scan['map'],
        'columns'   => $scan['columns'],
        'missing_column' => $missingColumn,
        'summary'   => $scan['counts'] + [
            'with_price' => count($scan['entries']),
            'changed'    => count($match['changes']),
            'unchanged'  => $match['unchanged'],
            'unmatched'  => count($match['unmatched']),
        ],
        'changes_sample'   => $sample,
        'unmatched_sample' => array_slice($match['unmatched'], 0, 40),
        'invalid_sample'   => $scan['invalid'],
    ]);
}

if (!$match['changes']) {
    discard_upload($upload, $reader);
    json_ok(['updated' => 0, 'unmatched' => count($match['unmatched'])]);
}

$updated = with_transaction($pdo, function (PDO $pdo) use ($match): int {
    $st = $pdo->prepare('UPDATE products SET sell_price = ?, buy_price = ?, updated_at = NOW() WHERE id = ?');
    $count = 0;
    foreach ($match['changes'] as $c) {
        $st->execute([from_hundredths($c['new_sell']), from_hundredths($c['new_buy']), $c['id']]);
        $count += $st->rowCount();
    }
    return $count;
});

discard_upload($upload, $reader);
json_ok(['updated' => $updated, 'unmatched' => count($match['unmatched'])]);
