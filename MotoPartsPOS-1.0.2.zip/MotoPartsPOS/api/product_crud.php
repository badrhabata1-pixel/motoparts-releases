<?php
/**
 * إدارة الأصناف.
 *   GET  ?id=5                                  تفاصيل الصنف وآخر حركات مخزونه
 *   POST {action: create|update|restock|adjust|delete|restore, ...}
 *   POST {action: quick, id, value: 0|1}        تفعيل أو إلغاء الوصول السريع [F3]
 *
 * تغييرات الرصيد تمر فقط عبر restock (توريد) و adjust (جرد) حتى يُسجَّل كل تغيير في دفتر الحركة.
 */
require __DIR__ . '/../includes/api.php';
require __DIR__ . '/../includes/inventory.php';

$pdo = db();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    $id = (int) ($_GET['id'] ?? 0);
    $product = find_product($pdo, $id);
    if (!$product) {
        throw new UserError('الصنف غير موجود.', 404);
    }
    $st = $pdo->prepare('SELECT created_at, reason, change_qty, balance_after, note, ref_id
                           FROM stock_movements WHERE product_id = ? ORDER BY id DESC LIMIT 15');
    $st->execute([$id]);
    $movements = [];
    foreach ($st as $m) {
        $movements[] = [
            'created_at' => (string) $m['created_at'],
            'reason'     => movement_reason_label((string) $m['reason']),
            'change'     => (string) $m['change_qty'],
            'balance'    => (string) $m['balance_after'],
            'note'       => (string) $m['note'],
        ];
    }
    $sold = $pdo->prepare('SELECT 1 FROM invoice_items WHERE product_id = ? LIMIT 1');
    $sold->execute([$id]);
    json_ok(['product' => product_out($product), 'movements' => $movements, 'has_sales' => $sold->fetchColumn() !== false]);
}

require_method('POST');
$in = request_json();
$action = (string) ($in['action'] ?? '');
$id = (int) ($in['id'] ?? 0);

/** حقول بطاقة الصنف من الطلب، مع التحقق. الأسعار الفارغة = 0.00 (قاعدة الأسعار غير النهائية). */
function product_fields(array $in): array
{
    $name = clean_text((string) ($in['product_name'] ?? ''));
    if ($name === '') {
        throw new UserError('اسم الصنف مطلوب.');
    }
    $fields = ['product_name' => $name];
    $numbers = ['buy_price' => 'سعر الشراء', 'sell_price' => 'سعر البيع', 'min_alert_qty' => 'حد التنبيه'];
    foreach ($numbers as $key => $label) {
        $raw = trim((string) ($in[$key] ?? ''));
        if ($raw === '') {
            $value = $key === 'min_alert_qty' ? (int) to_hundredths(DEFAULT_MIN_ALERT) : 0;
        } else {
            $value = to_hundredths($raw);
            if ($value === null || $value < 0 || $value > 999999999) {
                throw new UserError($label . ' غير صالح.');
            }
        }
        $fields[$key] = from_hundredths($value);
    }
    $fields['is_barcoded'] = array_key_exists('is_barcoded', $in) ? (empty($in['is_barcoded']) ? 0 : 1) : 1;
    // null = لم يُرسل: التعديل يبقي القيمة الحالية بدل أن يلغي الوصول السريع بصمت.
    $fields['is_quick_access'] = array_key_exists('is_quick_access', $in) ? (empty($in['is_quick_access']) ? 0 : 1) : null;
    // الملاحظة كذلك: null = لم تُرسل فتبقى كما هي، و'' = مسحها عمداً من نافذة التعديل.
    $fields['notes'] = array_key_exists('notes', $in) && is_scalar($in['notes']) ? clean_text((string) $in['notes'], 255) : null;
    $barcode = normalize_barcode((string) ($in['barcode'] ?? ''));
    if ($barcode !== '' && !preg_match('~^[0-9A-Za-z.\-/]{1,100}$~', $barcode)) {
        throw new UserError('الباركود يقبل أرقاماً وحروفاً لاتينية فقط.');
    }
    $fields['barcode'] = $barcode;
    return $fields;
}

function quantity_input(array $in, string $key, bool $allowZero): int
{
    $value = to_hundredths(trim((string) ($in[$key] ?? '')));
    if ($value === null || $value < 0 || (!$allowZero && $value === 0) || $value > 999999999) {
        throw new UserError('الكمية غير صالحة.');
    }
    return $value;
}

function locked_product(PDO $pdo, int $id): array
{
    $product = find_product($pdo, $id, true);
    if (!$product) {
        throw new UserError('الصنف غير موجود.', 404);
    }
    return $product;
}

switch ($action) {
    case 'create':
        $f = product_fields($in);
        $stock = trim((string) ($in['stock_quantity'] ?? '')) === '' ? 0 : quantity_input($in, 'stock_quantity', true);
        $product = with_transaction($pdo, function (PDO $pdo) use ($f, $stock): array {
            if ($f['barcode'] === '') {
                $f['barcode'] = allocate_barcodes($pdo, 1)[0];
            } elseif (barcode_exists($pdo, $f['barcode'])) {
                throw new UserError('الباركود ' . $f['barcode'] . ' مستخدم لصنف آخر.', 409);
            }
            $pdo->prepare('INSERT INTO products (barcode, product_name, search_key, notes, stock_quantity, buy_price, sell_price, is_barcoded, is_quick_access, min_alert_qty)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute([$f['barcode'], $f['product_name'], normalize_search($f['product_name']), (string) $f['notes'], from_hundredths($stock),
                           $f['buy_price'], $f['sell_price'], $f['is_barcoded'], (int) $f['is_quick_access'], $f['min_alert_qty']]);
            $newId = (int) $pdo->lastInsertId();
            if ($stock !== 0) {
                record_movement($pdo, $newId, $stock, $stock, 'create');
            }
            return find_product($pdo, $newId);
        });
        json_ok(['product' => product_out($product)]);

    case 'update':
        $f = product_fields($in);
        $product = with_transaction($pdo, function (PDO $pdo) use ($id, $f): array {
            $current = locked_product($pdo, $id);
            if ($f['barcode'] === '') {
                $f['barcode'] = $current['barcode'];
            } elseif (barcode_exists($pdo, $f['barcode'], $id)) {
                throw new UserError('الباركود ' . $f['barcode'] . ' مستخدم لصنف آخر.', 409);
            }
            $pdo->prepare('UPDATE products SET barcode = ?, product_name = ?, search_key = ?, notes = COALESCE(?, notes), buy_price = ?, sell_price = ?,
                                  is_barcoded = ?, is_quick_access = COALESCE(?, is_quick_access), min_alert_qty = ?, updated_at = NOW()
                            WHERE id = ?')
                ->execute([$f['barcode'], $f['product_name'], normalize_search($f['product_name']), $f['notes'], $f['buy_price'],
                           $f['sell_price'], $f['is_barcoded'], $f['is_quick_access'], $f['min_alert_qty'], $id]);
            return find_product($pdo, $id);
        });
        json_ok(['product' => product_out($product)]);

    case 'restock':
        $qty = quantity_input($in, 'quantity', false);
        $note = clean_text((string) ($in['note'] ?? ''));
        $product = with_transaction($pdo, function (PDO $pdo) use ($id, $qty, $note): array {
            $current = locked_product($pdo, $id);
            $balance = (to_hundredths((string) $current['stock_quantity']) ?? 0) + $qty;
            if ($balance > 9999999999) {
                throw new UserError('الرصيد الناتج أكبر من الحد المسموح.');
            }
            $pdo->prepare('UPDATE products SET stock_quantity = stock_quantity + ? WHERE id = ?')->execute([from_hundredths($qty), $id]);
            record_movement($pdo, $id, $qty, $balance, 'restock', null, $note);
            return find_product($pdo, $id);
        });
        json_ok(['product' => product_out($product)]);

    case 'adjust':
        $target = quantity_input($in, 'new_quantity', true);
        $note = clean_text((string) ($in['note'] ?? ''));
        $product = with_transaction($pdo, function (PDO $pdo) use ($id, $target, $note): array {
            $current = locked_product($pdo, $id);
            $delta = $target - (to_hundredths((string) $current['stock_quantity']) ?? 0);
            if ($delta !== 0) {
                $pdo->prepare('UPDATE products SET stock_quantity = ? WHERE id = ?')->execute([from_hundredths($target), $id]);
                record_movement($pdo, $id, $delta, $target, 'adjust', null, $note);
            }
            return find_product($pdo, $id);
        });
        json_ok(['product' => product_out($product)]);

    case 'delete':
        // صنف له مبيعات يُخفى فقط (is_active = 0) فيبقى في الفواتير القديمة؛ صنف لم يُبع يُحذف نهائياً.
        $mode = with_transaction($pdo, function (PDO $pdo) use ($id): string {
            locked_product($pdo, $id);
            $sold = $pdo->prepare('SELECT 1 FROM invoice_items WHERE product_id = ? LIMIT 1');
            $sold->execute([$id]);
            if ($sold->fetchColumn() !== false) {
                $pdo->prepare('UPDATE products SET is_active = 0, updated_at = NOW() WHERE id = ?')->execute([$id]);
                return 'soft';
            }
            $pdo->prepare('DELETE FROM products WHERE id = ?')->execute([$id]);
            return 'hard';
        });
        json_ok(['mode' => $mode]);

    case 'quick':
        // تفعيل أو إلغاء الوصول السريع [F3] بضغطة واحدة من شاشة البيع أو المخزون.
        $value = empty($in['value']) ? 0 : 1;
        $product = find_product($pdo, $id);
        if (!$product) {
            throw new UserError('الصنف غير موجود.', 404);
        }
        if ($value === 1 && !(int) $product['is_active']) {
            throw new UserError('الصنف محذوف من المخزون، فلا يمكن إضافته للوصول السريع.', 409);
        }
        $pdo->prepare('UPDATE products SET is_quick_access = ? WHERE id = ?')->execute([$value, $id]);
        json_ok(['product' => product_out(find_product($pdo, $id))]);

    case 'restore':
        $product = with_transaction($pdo, function (PDO $pdo) use ($id): array {
            locked_product($pdo, $id);
            $pdo->prepare('UPDATE products SET is_active = 1, updated_at = NOW() WHERE id = ?')->execute([$id]);
            return find_product($pdo, $id);
        });
        json_ok(['product' => product_out($product)]);

    default:
        throw new UserError('إجراء غير معروف.');
}
