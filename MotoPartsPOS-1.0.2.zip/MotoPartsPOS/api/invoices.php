<?php
/**
 * سجل الفواتير والمرتجعات.
 *   GET  ?action=list&q=&from=&to=&status=&page=   بحث برقم الفاتورة أو اسم العميل أو هاتفه، مع ملخص المبالغ
 *        status: completed (بلا مرتجع) | returned (بها مرتجع جزئي) | void (ملغاة)
 *   GET  ?action=get&id=                     الفاتورة وبنودها ومرتجعاتها
 *   POST {action: return, invoice_id, items: [{item_id, quantity}], restock: true|false, note}   مرتجع جزئي
 *        restock=true:  الكمية ترجع لرصيد الصنف (حركة "مرتجع" في دفتر المخزون)
 *        restock=false: مرتجع مالي فقط: يُخصم المبلغ من الفاتورة ورصيد الصنف لا يتغير
 *        إذا لم يبقَ في الفاتورة أي كمية بعد المرتجع تتحول حالتها تلقائياً إلى void (مرتجعة بالكامل)
 *   POST {action: void, invoice_id, restock: true|false, note}             إلغاء الفاتورة كلها
 *        restock=true:  ما تبقى من كل صنف يرجع للمخزون (حركة "إلغاء فاتورة" في دفتر المخزون)
 *        restock=false: إلغاء مستندي: الفاتورة تخرج من المبيعات وأرصدة الأصناف لا تتغير
 *
 * لا تُحذف أي فاتورة فعلياً. الإلغاء والمرتجع يُسجَّلان في invoice_returns بتاريخ تنفيذهما،
 * فيُخصمان من مبيعات ذلك اليوم ولا تتغير تقارير الأيام المُقفلة.
 */
require __DIR__ . '/../includes/api.php';
require __DIR__ . '/../includes/inventory.php';

$pdo = db();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// كيف أُلغيت الفاتورة: 1 مع إرجاع المخزون، 0 بدونه، NULL غير ملغاة.
const VOID_MODE_SQL = '(SELECT MIN(r.restocked) FROM invoice_returns r WHERE r.invoice_id = i.id AND r.is_void = 1)';

function invoice_out(array $row): array
{
    return [
        'id'             => (int) $row['id'],
        'number'         => (string) $row['invoice_number'],
        'created_at'     => (string) $row['created_at'],
        'customer_name'  => (string) $row['customer_name'],
        'customer_phone' => (string) $row['customer_phone'],
        'total'          => (string) $row['total_amount'],
        'returned'       => (string) $row['returned_amount'],
        'status'         => (string) $row['status'],
        'void_restocked' => isset($row['void_restocked']) ? (int) $row['void_restocked'] : null,
        'lines'          => isset($row['line_count']) ? (int) $row['line_count'] : null,
    ];
}

function load_invoice(PDO $pdo, int $id): array
{
    $st = $pdo->prepare('SELECT i.*, ' . VOID_MODE_SQL . ' AS void_restocked FROM invoices i WHERE i.id = ?');
    $st->execute([$id]);
    $invoice = $st->fetch();
    if (!$invoice) {
        throw new UserError('الفاتورة غير موجودة.', 404);
    }
    $items = $pdo->prepare('SELECT ii.id, ii.product_id, ii.barcode, ii.product_name, ii.quantity, ii.unit_price, ii.subtotal, ii.returned_qty, ii.notes,
                                   (SELECT COALESCE(SUM(ri.subtotal), 0) FROM invoice_return_items ri WHERE ri.invoice_item_id = ii.id) AS returned_amount
                              FROM invoice_items ii WHERE ii.invoice_id = ? ORDER BY ii.id');
    $items->execute([$id]);
    $lines = [];
    foreach ($items as $it) {
        $lines[] = [
            'id' => (int) $it['id'], 'product_id' => (int) $it['product_id'], 'barcode' => (string) $it['barcode'],
            'name' => (string) $it['product_name'], 'quantity' => (string) $it['quantity'], 'unit_price' => (string) $it['unit_price'],
            'subtotal' => (string) $it['subtotal'], 'returned_qty' => (string) $it['returned_qty'], 'returned_amount' => (string) $it['returned_amount'],
            'notes' => (string) $it['notes'],
        ];
    }
    $rets = $pdo->prepare('SELECT r.id, r.created_at, r.amount, r.is_void, r.restocked, r.note, ri.quantity, ri.subtotal, ii.product_name
                             FROM invoice_returns r
                             LEFT JOIN invoice_return_items ri ON ri.return_id = r.id
                             LEFT JOIN invoice_items ii ON ii.id = ri.invoice_item_id
                            WHERE r.invoice_id = ? ORDER BY r.id, ri.id');
    $rets->execute([$id]);
    $returns = [];
    foreach ($rets as $r) {
        $rid = (int) $r['id'];
        if (!isset($returns[$rid])) {
            $returns[$rid] = ['id' => $rid, 'created_at' => (string) $r['created_at'], 'amount' => (string) $r['amount'],
                              'is_void' => (int) $r['is_void'], 'restocked' => (int) $r['restocked'], 'note' => (string) $r['note'], 'items' => []];
        }
        if ($r['product_name'] !== null) {
            $returns[$rid]['items'][] = ['name' => (string) $r['product_name'], 'quantity' => (string) $r['quantity'], 'subtotal' => (string) $r['subtotal']];
        }
    }
    return ['invoice' => invoice_out($invoice), 'items' => $lines, 'returns' => array_values($returns)];
}

/**
 * ينفذ مرتجعاً أو إلغاءً داخل معاملة مفتوحة. $wanted = [invoice_item_id => الكمية بالمئات].
 * الجزء الأخير من أي سطر يُحسب بالفرق الدقيق، فمجموع مرتجعات السطر يساوي إجماليه تماماً.
 * $restock = false: تُسجَّل الكميات مرتجعة/ملغاة على البنود دون لمس جدول products ولا دفتر الحركة.
 * المرتجع الذي يُنهي آخر كمية في الفاتورة يحوّل حالتها إلى void، فلا يبقى فيها ما يُرجع أو يُلغى.
 */
function process_return(PDO $pdo, int $invoiceId, array $wanted, string $note, bool $void, bool $restock = true): array
{
    $st = $pdo->prepare('SELECT id, status FROM invoices WHERE id = ? FOR UPDATE');
    $st->execute([$invoiceId]);
    $invoice = $st->fetch();
    if (!$invoice) {
        throw new UserError('الفاتورة غير موجودة.', 404);
    }
    if ($invoice['status'] === 'void') {
        throw new UserError('هذه الفاتورة ملغاة بالفعل.', 409);
    }
    $st = $pdo->prepare('SELECT id, product_id, product_name, quantity, unit_price, subtotal, returned_qty
                           FROM invoice_items WHERE invoice_id = ? ORDER BY id FOR UPDATE');
    $st->execute([$invoiceId]);
    $rows = [];
    foreach ($st as $row) {
        $rows[(int) $row['id']] = $row;
    }
    if ($void) {
        $wanted = [];
        foreach ($rows as $itemId => $row) {
            $left = (to_hundredths((string) $row['quantity']) ?? 0) - (to_hundredths((string) $row['returned_qty']) ?? 0);
            if ($left > 0) {
                $wanted[$itemId] = $left;
            }
        }
    }

    $prevSum = $pdo->prepare('SELECT COALESCE(SUM(subtotal), 0) FROM invoice_return_items WHERE invoice_item_id = ?');
    $lines = [];
    $amount = 0;
    foreach ($wanted as $itemId => $qty) {
        $row = $rows[$itemId] ?? null;
        if (!$row) {
            throw new UserError('بند غير موجود في هذه الفاتورة.');
        }
        $left = (to_hundredths((string) $row['quantity']) ?? 0) - (to_hundredths((string) $row['returned_qty']) ?? 0);
        if ($qty > $left) {
            throw new UserError('كمية المرتجع للصنف "' . $row['product_name'] . '" أكبر من المتبقي (' . qty_display($left) . ').');
        }
        $price = to_hundredths((string) $row['unit_price']) ?? 0;
        if ($qty === $left) {
            $prevSum->execute([$itemId]);
            $subtotal = (to_hundredths((string) $row['subtotal']) ?? 0) - (to_hundredths((string) $prevSum->fetchColumn()) ?? 0);
        } else {
            $subtotal = line_subtotal($price, $qty);
        }
        $lines[] = ['item_id' => $itemId, 'product_id' => (int) $row['product_id'], 'qty' => $qty, 'price' => $price, 'subtotal' => $subtotal];
        $amount += $subtotal;
    }
    if (!$lines && !$void) {
        throw new UserError('اكتب كمية مرتجع لصنف واحد على الأقل.');
    }

    $returnId = null;
    $restockedQty = 0;
    if ($lines) {
        $pdo->prepare('INSERT INTO invoice_returns (invoice_id, amount, is_void, restocked, note) VALUES (?, ?, ?, ?, ?)')
            ->execute([$invoiceId, from_hundredths($amount), $void ? 1 : 0, $restock ? 1 : 0, $note]);
        $returnId = (int) $pdo->lastInsertId();

        $balance = [];
        if ($restock) {
            // الأصناف تُقفل بترتيب id ثابت، كما في حفظ الفاتورة، فلا يحدث deadlock بين عمليتين متزامنتين.
            $ids = array_values(array_unique(array_column($lines, 'product_id')));
            sort($ids);
            $st = $pdo->prepare('SELECT id, stock_quantity FROM products WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY id FOR UPDATE');
            $st->execute($ids);
            foreach ($st as $p) {
                $balance[(int) $p['id']] = to_hundredths((string) $p['stock_quantity']) ?? 0;
            }
        }

        $insert = $pdo->prepare('INSERT INTO invoice_return_items (return_id, invoice_item_id, product_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?, ?)');
        $markItem = $pdo->prepare('UPDATE invoice_items SET returned_qty = returned_qty + ? WHERE id = ?');
        $addStock = $pdo->prepare('UPDATE products SET stock_quantity = stock_quantity + ? WHERE id = ?');
        foreach ($lines as $line) {
            $insert->execute([$returnId, $line['item_id'], $line['product_id'], from_hundredths($line['qty']), from_hundredths($line['price']), from_hundredths($line['subtotal'])]);
            $markItem->execute([from_hundredths($line['qty']), $line['item_id']]);
            if ($restock) {
                $addStock->execute([from_hundredths($line['qty']), $line['product_id']]);
                $balance[$line['product_id']] = ($balance[$line['product_id']] ?? 0) + $line['qty'];
                record_movement($pdo, $line['product_id'], $line['qty'], $balance[$line['product_id']], $void ? 'void' : 'return', $invoiceId, $note);
                $restockedQty += $line['qty'];
            }
        }
    }
    $closed = $void;
    if (!$void) {
        $st = $pdo->prepare('SELECT COUNT(*) FROM invoice_items WHERE invoice_id = ? AND quantity > returned_qty');
        $st->execute([$invoiceId]);
        $closed = (int) $st->fetchColumn() === 0;
    }
    $pdo->prepare('UPDATE invoices SET returned_amount = returned_amount + ?, status = ? WHERE id = ?')
        ->execute([from_hundredths($amount), $closed ? 'void' : 'completed', $invoiceId]);

    return [
        'id'           => $returnId,
        'amount'       => from_hundredths($amount),
        'restocked'    => $restock,
        'lines'        => count($lines),
        'restocked_qty' => from_hundredths($restockedQty),
        'closed'       => $closed,
    ];
}

if ($method === 'GET') {
    $action = (string) ($_GET['action'] ?? 'list');
    if ($action === 'get') {
        json_ok(load_invoice($pdo, (int) ($_GET['id'] ?? 0)));
    }

    $q = clean_text((string) ($_GET['q'] ?? ''), 60);
    $from = valid_date($_GET['from'] ?? null);
    $to = valid_date($_GET['to'] ?? null);
    $status = (string) ($_GET['status'] ?? '');
    $page = max(1, (int) ($_GET['page'] ?? 1));
    $perPage = 25;

    $where = [];
    $params = [];
    if ($q !== '') {
        $digits = normalize_digits($q);
        $where[] = '(i.invoice_number = ? OR i.customer_name LIKE ? OR i.customer_phone LIKE ?)';
        array_push($params, $digits, '%' . like_escape($q) . '%', '%' . like_escape($digits) . '%');
    }
    if ($from !== null) {
        $where[] = 'i.created_at >= ?';
        $params[] = day_range($from)[0];
    }
    if ($to !== null) {
        $where[] = 'i.created_at < ?';
        $params[] = day_range($to)[1];
    }
    $statuses = [
        'completed' => "i.status = 'completed' AND i.returned_amount = 0",
        'returned'  => "i.status = 'completed' AND i.returned_amount > 0",
        'void'      => "i.status = 'void'",
    ];
    if (isset($statuses[$status])) {
        $where[] = $statuses[$status];
    }
    $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $st = $pdo->prepare("SELECT COUNT(*) AS n, COALESCE(SUM(i.total_amount), 0) AS total, COALESCE(SUM(i.returned_amount), 0) AS returned
                           FROM invoices i $whereSql");
    $st->execute($params);
    $sum = $st->fetch();
    $count = (int) $sum['n'];
    $offset = ($page - 1) * $perPage;

    $st = $pdo->prepare('SELECT i.*, ' . VOID_MODE_SQL . " AS void_restocked,
                                (SELECT COUNT(*) FROM invoice_items ii WHERE ii.invoice_id = i.id) AS line_count
                           FROM invoices i $whereSql ORDER BY i.id DESC LIMIT $perPage OFFSET $offset");
    $st->execute($params);
    $totalC = to_hundredths((string) $sum['total']) ?? 0;
    $returnedC = to_hundredths((string) $sum['returned']) ?? 0;
    json_ok([
        'items'   => array_map('invoice_out', $st->fetchAll()),
        'total'   => $count,
        'page'    => $page,
        'pages'   => max(1, (int) ceil($count / $perPage)),
        'summary' => ['count' => $count, 'total' => from_hundredths($totalC), 'returned' => from_hundredths($returnedC), 'net' => from_hundredths($totalC - $returnedC)],
    ]);
}

require_method('POST');
$in = request_json();
$action = (string) ($in['action'] ?? '');
$invoiceId = (int) ($in['invoice_id'] ?? 0);
$note = clean_text((string) ($in['note'] ?? ''));

if ($action === 'return') {
    $wanted = [];
    foreach ((array) ($in['items'] ?? []) as $item) {
        $itemId = (int) ($item['item_id'] ?? 0);
        $raw = trim((string) ($item['quantity'] ?? ''));
        if ($itemId <= 0 || $raw === '') {
            continue;
        }
        $qty = to_hundredths($raw);
        if ($qty === null || $qty < 0) {
            throw new UserError('كمية مرتجع غير صالحة.');
        }
        if ($qty > 0) {
            $wanted[$itemId] = ($wanted[$itemId] ?? 0) + $qty;
        }
    }
    // بلا restock = السلوك القديم (إرجاع المخزون).
    $restock = !array_key_exists('restock', $in) || !empty($in['restock']);
    $result = with_transaction($pdo, function (PDO $pdo) use ($invoiceId, $wanted, $note, $restock): array {
        return process_return($pdo, $invoiceId, $wanted, $note, false, $restock);
    });
    json_ok(['return' => $result] + load_invoice($pdo, $invoiceId));
}

if ($action === 'void') {
    // بلا restock = السلوك القديم (إرجاع المخزون)، فلا يتغير معنى أي طلب سابق.
    $restock = !array_key_exists('restock', $in) || !empty($in['restock']);
    if ($note === '') {
        $note = $restock ? 'إلغاء الفاتورة مع إرجاع الأصناف للمخزون' : 'حذف الفاتورة دون تعديل المخزون';
    }
    $result = with_transaction($pdo, function (PDO $pdo) use ($invoiceId, $note, $restock): array {
        return process_return($pdo, $invoiceId, [], $note, true, $restock);
    });
    json_ok(['return' => $result] + load_invoice($pdo, $invoiceId));
}

throw new UserError('إجراء غير معروف.');
