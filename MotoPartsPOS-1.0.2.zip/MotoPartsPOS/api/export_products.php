<?php
/**
 * قالب الأسعار بصيغة Excel (xlsx): يملؤه المالك ثم يرفعه في "تحديث الأسعار بالجملة".
 *   GET ?filter=zero_price   الأصناف التي سعرها 0.00 فقط (اختياري)
 * الباركود يُكتب نصاً، فلا يحوّله Excel إلى صيغة علمية.
 * ملصقات الباركود لا تُصدَّر: تُعاين وتُطبع من صفحة الملصقات مباشرة (views/labels.php).
 */
require __DIR__ . '/../includes/api.php';
require __DIR__ . '/../includes/inventory.php';
require __DIR__ . '/../includes/xlsx_writer.php';

require_method('GET');
set_time_limit(120);

$filters = [
    'barcoded'   => ' AND is_barcoded = 1',
    'unbarcoded' => ' AND is_barcoded = 0',
    'low'        => ' AND stock_quantity <= min_alert_qty',
    'zero_price' => ' AND sell_price = 0',
];
$where = 'is_active = 1' . ($filters[$_GET['filter'] ?? ''] ?? '');

$rows = db()->query("SELECT barcode, product_name, stock_quantity, buy_price, sell_price
                       FROM products WHERE $where ORDER BY id");

$xlsx = new XlsxWriter('الأسعار', [16, 52, 10, 16, 16, 14, 18]);
$xlsx->addRow(['الباركود', 'الصنف', 'الكمية', 'سعر البيع الحالي', 'سعر الشراء الحالي', 'السعر الجديد', 'سعر الشراء الجديد'], true);
foreach ($rows as $p) {
    $xlsx->addRow([$p['barcode'], $p['product_name'], (float) $p['stock_quantity'], (float) $p['sell_price'], (float) $p['buy_price'], null, null]);
}

$data = $xlsx->build();
$file = 'motoparts-prices-' . date('Ymd-Hi') . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $file . '"');
header('Content-Length: ' . strlen($data));
header('Cache-Control: no-store');
echo $data;
