<?php
/**
 * الأصناف المطلوب طباعة ملصقاتها (صفحة الملصقات):
 *   GET ?ids=12,7,30              أصناف محددة، بالترتيب نفسه
 *   GET ?from=100002&to=100500    نطاق باركود، مثل أصناف استيراد واحد
 *   GET ?q=مارش&filter=low        نفس شروط البحث والتصفية في شاشة المخزون، و filter=fast للأكثر مبيعاً (نافذة F1)
 *   GET ?q=&filter=quick&count=1  العدد فقط، لزر "إضافة الكل" دون تحميل الأصناف
 * الحد 2000 صنف في الطلب الواحد؛ truncated=true يعني أن هناك المزيد.
 */
require __DIR__ . '/../includes/api.php';
require __DIR__ . '/../includes/inventory.php';

require_method('GET');

const LABELS_MAX = 2000;
const LABEL_COLUMNS = 'id, barcode, product_name, sell_price, stock_quantity';

$pdo = db();

if (isset($_GET['ids'])) {
    $ids = array_slice(array_values(array_unique(array_filter(array_map('intval', explode(',', (string) $_GET['ids'])), function ($id) {
        return $id > 0;
    }))), 0, LABELS_MAX);
    if (!$ids) {
        throw new UserError('لم يُحدَّد أي صنف.');
    }
    $st = $pdo->prepare('SELECT ' . LABEL_COLUMNS . ' FROM products WHERE is_active = 1 AND id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')');
    $st->execute($ids);
    $byId = [];
    foreach ($st as $row) {
        $byId[(int) $row['id']] = $row;
    }
    $rows = [];
    foreach ($ids as $id) {
        if (isset($byId[$id])) {
            $rows[] = $byId[$id];
        }
    }
} elseif (isset($_GET['from'], $_GET['to'])) {
    $from = normalize_barcode((string) $_GET['from']);
    $to = normalize_barcode((string) $_GET['to']);
    if (!ctype_digit($from) || !ctype_digit($to) || strlen($from) !== strlen($to)) {
        throw new UserError('نطاق الباركود غير صالح.');
    }
    // أرقام بنفس عدد الخانات تُقارن نصياً بشكل صحيح، فيستخدم الاستعلام الفهرس الفريد.
    $st = $pdo->prepare('SELECT ' . LABEL_COLUMNS . " FROM products
                          WHERE is_active = 1 AND barcode BETWEEN ? AND ? AND CHAR_LENGTH(barcode) = ? AND barcode REGEXP '^[0-9]+$'
                          ORDER BY barcode LIMIT " . (LABELS_MAX + 1));
    $st->execute([$from, $to, strlen($from)]);
    $rows = $st->fetchAll();
} else {
    $q = clean_text((string) ($_GET['q'] ?? ''), 100);
    $filter = (string) ($_GET['filter'] ?? 'all');
    $countOnly = !empty($_GET['count']);
    if ($filter === 'fast') {
        [$whereSql, $params] = product_filter_sql($q, 'all');
        $rows = fast_sellers($pdo, LABEL_COLUMNS, $whereSql, $params);
        if ($countOnly) {
            json_ok(['count' => count($rows)]);
        }
    } else {
        [$whereSql, $params, $exact] = product_filter_sql($q, $filter);
        if ($countOnly) {
            $st = $pdo->prepare("SELECT COUNT(*) FROM products WHERE $whereSql");
            $st->execute($params);
            json_ok(['count' => (int) $st->fetchColumn()]);
        }
        // بترتيب الإدخال (ترتيب فواتير المورد)، والباركود المطابق تماماً أولاً.
        $order = $exact !== '' ? '(barcode = ?) DESC, id' : 'id';
        $st = $pdo->prepare('SELECT ' . LABEL_COLUMNS . " FROM products WHERE $whereSql ORDER BY $order LIMIT " . (LABELS_MAX + 1));
        $st->execute($exact !== '' ? array_merge($params, [$exact]) : $params);
        $rows = $st->fetchAll();
    }
}

$items = [];
foreach (array_slice($rows, 0, LABELS_MAX) as $row) {
    $items[] = [
        'id'         => (int) $row['id'],
        'barcode'    => (string) $row['barcode'],
        'name'       => (string) $row['product_name'],
        'sell_price' => (string) $row['sell_price'],
        'stock'      => (string) $row['stock_quantity'],
    ];
}
json_ok(['items' => $items, 'truncated' => count($rows) > LABELS_MAX, 'max' => LABELS_MAX]);
