<?php
/**
 * موجّه الصفحات: index.php?page=pos|invoices|inventory|labels|import|reports (الافتراضي: نقطة البيع).
 * كل الصفحات تمر من هنا، فالمسارات النسبية (api/…، assets/…) تعمل أياً كان المنفذ أو اسم المجلد.
 * bootstrap.php يحوّل غير المسجل إلى login.php قبل أي شيء هنا.
 */
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/migrations.php';

if (!request_host_allowed()) {
    http_response_code(403);
    exit('Forbidden host');
}

$pages = [
    'pos'       => ['title' => 'نقطة البيع', 'scripts' => ['invoice_view', 'pos']],
    'invoices'  => ['title' => 'الفواتير', 'scripts' => ['invoice_view', 'invoices']],
    'inventory' => ['title' => 'المخزون', 'scripts' => ['barcode', 'inventory']],
    'labels'    => ['title' => 'الملصقات', 'scripts' => ['barcode', 'labels']],
    'import'    => ['title' => 'الاستيراد والأسعار', 'scripts' => ['import']],
    'reports'   => ['title' => 'التقارير', 'scripts' => ['reports']],
];
$page = (string) ($_GET['page'] ?? 'pos');
if (!isset($pages[$page])) {
    $page = 'pos';
}

$pdo = db_for_page();

define('IN_APP', true);
$pageTitle = $pages[$page]['title'];
$pageScripts = $pages[$page]['scripts'];

require __DIR__ . '/views/layout/header.php';
require __DIR__ . '/views/' . $page . '.php';
require __DIR__ . '/views/layout/footer.php';
