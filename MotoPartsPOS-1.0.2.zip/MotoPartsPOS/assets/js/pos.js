/*
 * شاشة البيع: الماسح الضوئي، اختصارات F1 / F2 / F3 / F9، السلة، والحفظ.
 *
 * الماسح يُميَّز بالتوقيت لا بالـ debounce: يكتب الحروف بفواصل بضعة ملي ثوانٍ وينهي القراءة بـ Enter.
 * كل ضغطة تمر بمستمع واحد على document في مرحلة الالتقاط، أياً كان العنصر المُركَّز، والحرف يُقرأ من
 * event.code (موقع المفتاح) فلا يتأثر بتخطيط لوحة المفاتيح العربية أو AZERTY (حيث يصل الرقم 1 كـ "&").
 */
(function () {
  'use strict';

  var MP = window.MP, APP = window.APP || {};
  var M = MP.money, h = MP.escapeHtml;

  var GAP = Number(APP.scanGap) || 50;     // أقصى فاصل بين حرفين من الماسح (ملي ثانية)
  var MIN_SCAN = 4;                        // أقل طول لقراءة ماسح تنتهي بـ Enter
  var IDLE_FLUSH = GAP + 30;               // ماسح مضبوط بلا Enter: تنتهي القراءة بعد هذا السكون
  var MIN_IDLE_SCAN = 6;
  var CART_KEY = 'mp_cart_v1';
  var ARABIC = /[؀-ۿ]/;

  function $(id) { return document.getElementById(id); }
  var scanInput = $('scanInput'), tbody = $('cartBody'), emptyBox = $('cartEmpty');
  var quickDlg = $('quickDialog'), quickSearch = $('quickSearch'), quickList = $('quickList');
  var qaDlg = $('quickAccessDialog'), qaSearch = $('qaSearch'), qaGrid = $('qaGrid'), qaMore = $('qaMore'), qaResults = $('qaResults');
  var checkoutDlg = $('checkoutDialog'), coForm = $('checkoutForm'), coSubmit = $('coSubmit');

  /** سطر السلة: {id, barcode, name, qtyH, priceC, basePriceC, stockH} — كل الأرقام أعداد صحيحة بالمئات. */
  var state = { lines: [], uuid: null };
  var saving = false;
  var pendingScans = [];                   // قراءات وصلت أثناء الحفظ: تُضاف للفاتورة التالية

  /* ── حفظ السلة محلياً: F5 أو انهيار المتصفح أو انقطاع الكهرباء لا يضيّع الفاتورة ── */

  function persist() {
    if (state.lines.length) MP.store.set(CART_KEY, { lines: state.lines, uuid: state.uuid });
    else MP.store.remove(CART_KEY);
  }

  function restore() {
    var saved = MP.store.get(CART_KEY, null);
    if (!saved || !Array.isArray(saved.lines)) return;
    state.lines = saved.lines.filter(function (l) {
      return l && l.id > 0 && l.qtyH > 0 && l.priceC >= 0 && typeof l.barcode === 'string';
    });
    state.lines.forEach(function (l) {
      l.note = typeof l.note === 'string' ? l.note : '';       // سلال محفوظة قبل ميزة الملاحظات
      l.noteOpen = false;
    });
    state.uuid = typeof saved.uuid === 'string' ? saved.uuid : null;
    if (state.lines.length) MP.toast('استُعيدت فاتورة لم تُحفظ (' + state.lines.length + ' صنف).', 'info');
  }

  /* ── السلة ─────────────────────────────────────────────────────────── */

  function findLine(id) {
    for (var i = 0; i < state.lines.length; i++) if (state.lines[i].id === id) return state.lines[i];
    return null;
  }

  function addProduct(p) {
    var line = findLine(p.id);
    if (line) {
      line.qtyH += 100;
    } else {
      var price = M.toHundredths(p.sell_price) || 0;
      line = { id: p.id, barcode: p.barcode, name: p.name, qtyH: 100, priceC: price, basePriceC: price, stockH: M.toHundredths(p.stock) || 0, note: '' };
      state.lines.push(line);
    }
    if (!state.uuid) state.uuid = MP.uuid();
    render(line.id);
    persist();
  }

  function removeLine(id) {
    state.lines = state.lines.filter(function (l) { return l.id !== id; });
    if (!state.lines.length) state.uuid = null;
    render();
    persist();
  }

  function clearCart() {
    state.lines = [];
    state.uuid = null;
    render();
    persist();
  }

  function cartTotal() {
    return state.lines.reduce(function (sum, l) { return sum + M.lineTotal(l.priceC, l.qtyH); }, 0);
  }

  function stockBadge(line) {
    return line.qtyH > line.stockH ? ' <span class="badge badge--danger">الرصيد ' + M.fmtQty(line.stockH) + '</span>' : '';
  }

  // ملاحظة البند تحت الاسم: رابط صغير "＋ ملاحظة" يفتح حقلاً نحيفاً، فلا يزيد ارتفاع الصفوف بلا حاجة.
  function noteHtml(line) {
    if (!line.note && !line.noteOpen) {
      return '<button type="button" class="note-toggle" data-action="note" tabindex="-1">＋ ملاحظة</button>';
    }
    return '<input class="note-input" data-field="note" maxlength="255" autocomplete="off" value="' + h(line.note || '') + '"' +
      ' placeholder="ملاحظة للبند، مثال: أخذ 5 من أصل 50" aria-label="ملاحظة البند">';
  }

  function rowHtml(line, index) {
    return '<tr data-id="' + line.id + '"' + (line.priceC === 0 ? ' class="is-zero"' : '') + '>' +
      '<td class="idx">' + (index + 1) + '</td>' +
      '<td class="mono">' + h(line.barcode) + '</td>' +
      '<td class="name"><span class="name__text">' + h(line.name) + '</span><span class="stock-flag">' + stockBadge(line) + '</span>' +
      '<div class="line-note">' + noteHtml(line) + '</div></td>' +
      '<td><input class="cell-input qty" data-field="qty" inputmode="decimal" autocomplete="off" value="' + M.fmtQty(line.qtyH) + '" aria-label="الكمية"></td>' +
      '<td><input class="cell-input price" data-field="price" inputmode="decimal" autocomplete="off" value="' + M.fmt(line.priceC) + '" aria-label="السعر"></td>' +
      '<td class="total">' + M.fmt(M.lineTotal(line.priceC, line.qtyH), true) + '</td>' +
      '<td class="del"><button class="icon-btn icon-btn--danger" type="button" data-action="remove" tabindex="-1" title="حذف السطر" aria-label="حذف السطر">' +
      '<svg class="icon"><use href="#i-trash"/></svg></button></td>' +
      '</tr>';
  }

  function render(flashId) {
    tbody.innerHTML = state.lines.map(rowHtml).join('');
    emptyBox.hidden = state.lines.length > 0;
    updateTotals();
    if (flashId != null) {
      var tr = tbody.querySelector('tr[data-id="' + flashId + '"]');
      if (tr) {
        tr.classList.add('flash');
        tr.scrollIntoView({ block: 'nearest' });
        setTimeout(function () { tr.classList.remove('flash'); }, 650);
      }
    }
  }

  // تحديث جزئي: شارة الرصيد والإجمالي فقط، فلا يُعاد رسم حقل الملاحظة أثناء الكتابة.
  function refreshRow(tr, line) {
    tr.classList.toggle('is-zero', line.priceC === 0);
    tr.querySelector('.stock-flag').innerHTML = stockBadge(line);
    tr.cells[5].textContent = M.fmt(M.lineTotal(line.priceC, line.qtyH), true);
  }

  function updateTotals() {
    var pieces = 0, zero = 0;
    state.lines.forEach(function (l) {
      pieces += l.qtyH;
      if (l.priceC === 0) zero++;
    });
    $('grandTotal').textContent = M.fmt(cartTotal(), true);
    $('statLines').textContent = state.lines.length;
    $('statPieces').textContent = M.fmtQty(pieces);
    $('statZero').textContent = zero;
    $('statZeroRow').hidden = zero === 0;
  }

  // تعديل الكمية أو السعر داخل السطر: تحديث السطر والإجمالي فقط، دون إعادة رسم الجدول.
  tbody.addEventListener('input', function (e) {
    var input = e.target;
    if (input.classList.contains('note-input')) {
      var noteLine = findLine(Number(input.closest('tr').dataset.id));
      if (noteLine) {
        noteLine.note = input.value;
        persist();
      }
      return;
    }
    if (!input.classList.contains('cell-input')) return;
    var tr = input.closest('tr');
    var line = findLine(Number(tr.dataset.id));
    if (!line) return;
    var v = M.toHundredths(input.value);
    var isQty = input.dataset.field === 'qty';
    var valid = v !== null && (isQty ? v > 0 && v <= 9999999 : v >= 0 && v <= 999999999);
    input.classList.toggle('is-invalid', !valid && input.value.trim() !== '');
    if (!valid) return;
    if (isQty) line.qtyH = v; else line.priceC = v;
    refreshRow(tr, line);
    updateTotals();
    persist();
  });

  // عند مغادرة الخانة تظهر القيمة المعتمدة؛ القيمة غير الصالحة تُستبدل بالسابقة.
  tbody.addEventListener('focusout', function (e) {
    var input = e.target;
    if (input.classList.contains('note-input')) {
      // ملاحظة فارغة عند المغادرة: يعود رابط "＋ ملاحظة" بدل الحقل.
      var noteLine = findLine(Number(input.closest('tr').dataset.id));
      if (noteLine && !noteLine.note.trim()) {
        noteLine.note = '';
        noteLine.noteOpen = false;
        input.parentNode.innerHTML = noteHtml(noteLine);
      }
      return;
    }
    if (!input.classList.contains('cell-input')) return;
    var line = findLine(Number(input.closest('tr').dataset.id));
    if (!line) return;
    input.classList.remove('is-invalid');
    input.value = input.dataset.field === 'qty' ? M.fmtQty(line.qtyH) : M.fmt(line.priceC);
  });

  tbody.addEventListener('focusin', function (e) {
    if (e.target.classList.contains('cell-input')) e.target.select();
  });

  tbody.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && (e.target.classList.contains('cell-input') || e.target.classList.contains('note-input'))) {
      e.preventDefault();
      e.target.blur();
      focusScan();
    }
  });

  tbody.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-action="remove"]');
    if (btn) {
      removeLine(Number(btn.closest('tr').dataset.id));
      return;
    }
    var noteBtn = e.target.closest('[data-action="note"]');
    if (noteBtn) {
      var line = findLine(Number(noteBtn.closest('tr').dataset.id));
      if (!line) return;
      line.noteOpen = true;
      var box = noteBtn.parentNode;
      box.innerHTML = noteHtml(line);
      box.querySelector('.note-input').focus();
    }
  });

  /* ── التركيز ───────────────────────────────────────────────────────── */

  // أي نافذة مفتوحة، بما فيها نافذة تفاصيل الفاتورة التي ينشئها invoice_view.js.
  function dialogOpen() { return !!document.querySelector('dialog[open]'); }

  function closeInvoiceView() {
    if (window.MPInvoice) MPInvoice.close();
  }

  function isEditable(el) {
    return !!el && el.nodeType === 1 && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT' || el.isContentEditable);
  }

  function isTextField(el) {
    return !!el && (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && /^(text|search|tel|number|email|url|password)$/i.test(el.type)));
  }

  function focusScan() {
    if (!dialogOpen() && document.activeElement !== scanInput) scanInput.focus({ preventScroll: true });
  }

  // الأزرار خارج النوافذ لا تأخذ التركيز، فيبقى في حقل المسح ولا يضغط Enter القادم من الماسح زراً بالخطأ.
  document.addEventListener('mousedown', function (e) {
    var btn = e.target.closest('button');
    if (btn && !btn.closest('dialog')) e.preventDefault();
  }, true);

  document.addEventListener('click', function (e) {
    if (dialogOpen() || isEditable(e.target) || e.target.closest('a')) return;
    // نقرة فتحت حقلاً للكتابة (مثل "＋ ملاحظة") تحتفظ بالتركيز فيه.
    setTimeout(function () { if (!isTextField(document.activeElement)) focusScan(); }, 0);
  });

  window.addEventListener('focus', function () { setTimeout(focusScan, 0); });
  // حدث close لا ينتشر لأعلى، لكن مرحلة الالتقاط تلتقطه من كل النوافذ.
  document.addEventListener('close', function () { setTimeout(focusScan, 0); }, true);

  /* ── الماسح الضوئي ─────────────────────────────────────────────────── */

  // arabic: ضغطة في الدفعة أنتجت حرفاً عربياً. الماسح يرسل أرقاماً، فدفعة سريعة بحروف عربية داخل
  // حقل ملاحظة هي كتابة بشرية سريعة، لا قراءة ماسح.
  var burst = { text: '', count: 0, last: 0, target: null, before: null, redirected: false, timer: 0, arabic: false };
  var ARABIC_LETTER = /[ء-يٮ-ۓ]/;

  function resetBurst() {
    clearTimeout(burst.timer);
    burst.text = '';
    burst.count = 0;
    burst.target = null;
    burst.before = null;
    burst.redirected = false;
    burst.arabic = false;
  }

  // الحرف من موقع المفتاح الفيزيائي (Digit1 = "1" في أي تخطيط)، لا من e.key.
  function codeToChar(e) {
    var code = e.code || '', m;
    if ((m = /^(?:Digit|Numpad)([0-9])$/.exec(code))) return m[1];
    if ((m = /^Key([A-Z])$/.exec(code))) return e.shiftKey ? m[1] : m[1].toLowerCase();
    if (code === 'Minus' || code === 'NumpadSubtract') return '-';
    if (code === 'Period' || code === 'NumpadDecimal') return '.';
    if (code === 'Slash' || code === 'NumpadDivide') return '/';
    if (!code && e.key && e.key.length === 1) return MP.normalizeDigits(e.key);
    return null;
  }

  // ما كتبه الماسح داخل أي حقل (كمية، سعر، بحث، اسم العميل) يُعاد كما كان قبل القراءة.
  function undoBurstTyping() {
    var t = burst.target;
    if (t && burst.before !== null && isTextField(t) && t.value !== burst.before) {
      t.value = burst.before;
      t.dispatchEvent(new Event('input', { bubbles: true }));
    }
    if (burst.redirected) scanInput.value = '';
  }

  function acceptScan(code) {
    if (quickDlg.open) quickDlg.close();
    if (qaDlg.open) qaDlg.close();
    closeInvoiceView();
    if (checkoutDlg.open && !saving) checkoutDlg.close();
    enqueueBarcode(code, false);
  }

  function onKeyDown(e) {
    if (e.key === 'F1' || e.key === 'F2' || e.key === 'F3' || e.key === 'F9') {
      e.preventDefault();                       // F1 يفتح مساعدة Chrome، و F3 يفتح شريط البحث في الصفحة
      if (e.repeat) return;
      if (e.key === 'F9') openCheckout();
      else if (e.key === 'F3') openQuickAccess();
      else openQuick(e.key === 'F1' ? 'fast' : 'unbarcoded');
      return;
    }
    if (e.ctrlKey || e.altKey || e.metaKey || e.isComposing) return;
    var now = performance.now();

    if (e.key === 'Enter') {
      onEnter(e, now);
      return;
    }
    var ch = codeToChar(e);
    if (ch === null) return;
    if (burst.count === 0 || now - burst.last > GAP) {
      resetBurst();
      burst.target = e.target;
      burst.before = isTextField(e.target) ? e.target.value : null;
    }
    burst.text += ch;
    burst.count++;
    burst.last = now;
    if (e.key && e.key.length === 1 && ARABIC_LETTER.test(e.key)) burst.arabic = true;
    clearTimeout(burst.timer);
    burst.timer = setTimeout(onIdle, IDLE_FLUSH);

    // كتابة والتركيز خارج أي حقل: نوجّهها إلى حقل المسح قبل أن يُدرج المتصفح الحرف.
    if (!isEditable(e.target) && !dialogOpen()) {
      burst.redirected = burst.redirected || burst.count === 1;
      scanInput.focus({ preventScroll: true });
    }
  }

  function onEnter(e, now) {
    clearTimeout(burst.timer);
    var fromScanner = burst.count >= MIN_SCAN && now - burst.last <= GAP * 2;
    // نص عربي في حقل المسح = اسم صنف مكتوب يدوياً مهما كانت سرعة الكتابة.
    if (fromScanner && (burst.target === scanInput || burst.redirected) && ARABIC.test(scanInput.value)) fromScanner = false;
    if (fromScanner && burst.arabic && burst.target && burst.target.classList && burst.target.classList.contains('note-input')) fromScanner = false;

    if (fromScanner) {
      e.preventDefault();
      e.stopPropagation();                      // لا يصل Enter إلى زر أو نموذج
      var code = burst.text;
      undoBurstTyping();
      resetBurst();
      acceptScan(code);
      return;
    }
    var target = e.target;
    resetBurst();
    if (target === scanInput) {
      e.preventDefault();
      var value = scanInput.value;
      scanInput.value = '';
      manualEntry(value);
    }
  }

  // ماسح مضبوط بلا لاحقة Enter: تنتهي القراءة بعد سكون قصير إن كانت طويلة وسريعة.
  function onIdle() {
    if (burst.count < MIN_IDLE_SCAN) return;
    var t = burst.target;
    if (t !== scanInput && isEditable(t)) return;
    if (ARABIC.test(scanInput.value)) return;
    var code = burst.text;
    undoBurstTyping();
    resetBurst();
    acceptScan(code);
  }

  function manualEntry(raw) {
    var value = MP.normalizeDigits(raw).trim();
    if (!value) return;
    // أرقام وحروف لاتينية مع رقم واحد على الأقل = باركود مكتوب يدوياً؛ غير ذلك = بحث بالاسم.
    if (/^[0-9A-Za-z.\-\/]+$/.test(value) && /\d/.test(value)) enqueueBarcode(value, true);
    else openQuick('search', raw.trim());
  }

  // طابور تسلسلي: قراءتان سريعتان لنفس الصنف تزيدان الكمية ولا تنشئان سطرين.
  var chain = Promise.resolve();
  function enqueueBarcode(code, manual) {
    if (saving) {
      pendingScans.push(code);
      return;
    }
    chain = chain.then(function () { return lookup(code, manual); }).catch(function (err) { console.error(err); });
  }

  function lookup(raw, manual) {
    var code = MP.normalizeDigits(raw).trim();
    if (!code) return null;
    var lower = code.toLowerCase();
    for (var i = 0; i < state.lines.length; i++) {
      if (state.lines[i].barcode.toLowerCase() === lower) {
        state.lines[i].qtyH += 100;              // الصنف في السلة: الكمية تزيد فوراً بلا شبكة
        render(state.lines[i].id);
        persist();
        MP.beep(true);
        return null;
      }
    }
    return MP.api.get('api/search_product.php', { barcode: code }, { timeout: 8000 }).then(function (res) {
      addProduct(res.product);
      MP.beep(true);
    }, function (err) {
      if (manual && err.code === 'not_found') {
        openQuick('search', raw);               // رقم مكتوب يدوياً ليس باركوداً: نبحث به في الأسماء
        return;
      }
      MP.beep(false);
      MP.toast(err.message, 'error', err.code === 'not_found'
        ? { action: { label: 'إضافة كصنف جديد', href: 'index.php?page=inventory&new=' + encodeURIComponent(code) } }
        : {});
    });
  }

  /* ── نافذة الاختيار السريع: F1 الأكثر مبيعاً، F2 بدون باركود ───────── */

  var quick = { tab: 'fast', items: [], active: -1, ctrl: null };

  function openQuick(tab, query) {
    if (checkoutDlg.open) return;
    if (qaDlg.open) qaDlg.close();
    closeInvoiceView();
    quick.tab = tab;
    Array.prototype.forEach.call(quickDlg.querySelectorAll('[data-tab]'), function (t) {
      var on = t.dataset.tab === tab;
      t.classList.toggle('is-active', on);
      t.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    quickSearch.value = query || '';
    MP.openDialog(quickDlg);
    quickSearch.focus();
    loadQuick();
  }

  function loadQuick() {
    var q = quickSearch.value.trim();
    if (quick.ctrl) quick.ctrl.abort();
    quick.ctrl = new AbortController();
    var params;
    if (q) params = { q: q, limit: 60, filter: quick.tab === 'unbarcoded' ? 'unbarcoded' : 'all' };
    else if (quick.tab === 'search') return renderQuick([], 'اكتب جزءاً من اسم الصنف أو الباركود.');
    else params = { list: quick.tab };
    MP.api.get('api/search_product.php', params, { signal: quick.ctrl.signal }).then(function (res) {
      renderQuick(res.items, emptyText(q));
    }, function (err) {
      if (err.code !== 'aborted') renderQuick([], err.message);
    });
  }

  function emptyText(q) {
    if (q) return 'لا توجد أصناف تطابق "' + q + '".';
    if (quick.tab === 'fast') return 'لا توجد مبيعات خلال آخر 30 يوماً بعد.';
    return 'لا توجد أصناف بدون باركود. حدّدها من شاشة المخزون بإلغاء خيار "عليه ملصق باركود".';
  }

  function renderQuick(items, empty) {
    quick.items = items || [];
    quick.active = quick.items.length ? 0 : -1;
    if (!quick.items.length) {
      quickList.innerHTML = '<p class="empty">' + h(empty) + '</p>';
      return;
    }
    quickList.innerHTML = quick.items.map(function (p, i) {
      var stock = M.toHundredths(p.stock) || 0;
      var low = stock <= (M.toHundredths(p.min_alert) || 0);
      var sold = p.sold ? ' · مُباع ' + M.fmtQty(M.toHundredths(p.sold) || 0) : '';
      return '<button type="button" class="quick-item' + (i === 0 ? ' is-active' : '') + '" role="option" data-index="' + i + '">' +
        '<span><span class="quick-item__name">' + h(p.name) + '</span>' +
        '<span class="quick-item__meta"><span class="mono">' + h(p.barcode) + '</span>' + sold + '</span></span>' +
        '<span class="quick-item__stock badge ' + (low ? 'badge--danger' : 'badge--muted') + '" title="الرصيد">' + M.fmtQty(stock) + '</span>' +
        '<span class="quick-item__price">' + M.fmt(M.toHundredths(p.sell_price) || 0, true) + '</span>' +
        '</button>';
    }).join('');
  }

  function moveActive(delta) {
    if (!quick.items.length) return;
    quick.active = (quick.active + delta + quick.items.length) % quick.items.length;
    Array.prototype.forEach.call(quickList.children, function (el, i) {
      el.classList.toggle('is-active', i === quick.active);
      if (i === quick.active) el.scrollIntoView({ block: 'nearest' });
    });
  }

  function pick(index) {
    var p = quick.items[index];
    if (!p) return;
    quickDlg.close();
    addProduct(p);
    MP.beep(true);
  }

  quickDlg.addEventListener('click', function (e) {
    var tab = e.target.closest('[data-tab]');
    if (tab) {
      openQuick(tab.dataset.tab, quickSearch.value);
      return;
    }
    var item = e.target.closest('.quick-item');
    if (item) pick(Number(item.dataset.index));
  });

  quickSearch.addEventListener('input', MP.debounce(loadQuick, 250));
  quickSearch.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowDown') { e.preventDefault(); moveActive(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); moveActive(-1); }
    else if (e.key === 'Enter') { e.preventDefault(); if (quick.active >= 0) pick(quick.active); }
  });

  quickDlg.addEventListener('close', function () {
    if (quick.ctrl) quick.ctrl.abort();
    setTimeout(focusScan, 0);
  });

  /* ── الوصول السريع [F3]: أصناف مختارة تُضاف للفاتورة بنقرة، وتُدار من النافذة نفسها ── */

  // quick: أصناف الوصول السريع (مربعات)، others: نتائج بحث أخرى يمكن إضافتها بزر ⚡.
  // التنقل بالأسهم يمر على المربعات ثم النتائج بنفس ترتيب العرض.
  var qa = { quick: [], others: [], active: -1, ctrl: null, busy: {} };

  function qaItems() { return qa.quick.concat(qa.others); }

  function openQuickAccess() {
    if (checkoutDlg.open) return;
    if (quickDlg.open) quickDlg.close();
    closeInvoiceView();
    qaSearch.value = '';
    MP.openDialog(qaDlg);
    qaSearch.focus();
    loadQuickAccess();
  }

  function loadQuickAccess() {
    var q = qaSearch.value.trim();
    if (qa.ctrl) qa.ctrl.abort();
    qa.ctrl = new AbortController();
    var opts = { signal: qa.ctrl.signal };
    var requests = [MP.api.get('api/search_product.php', { list: 'quick', q: q }, opts)];
    if (q) requests.push(MP.api.get('api/search_product.php', { q: q, limit: 30 }, opts));
    Promise.all(requests).then(function (res) {
      qa.quick = res[0].items;
      qa.others = res[1] ? res[1].items.filter(function (p) { return !p.is_quick; }) : [];
      renderQuickAccess();
    }, function (err) {
      if (err.code !== 'aborted') qaGrid.innerHTML = '<p class="empty">' + h(err.message) + '</p>';
    });
  }

  function starHtml(p, idx) {
    var label = p.is_quick ? 'إلغاء من الوصول السريع' : 'إضافة للوصول السريع';
    return '<button type="button" class="qa-star' + (p.is_quick ? ' is-on' : '') + '" data-star="' + idx + '" title="' + label + '"' +
      ' aria-label="' + label + '" aria-pressed="' + (p.is_quick ? 'true' : 'false') + '"><svg class="icon"><use href="#i-bolt"/></svg></button>';
  }

  function stockBadgeHtml(p) {
    var stock = M.toHundredths(p.stock) || 0;
    var low = stock <= (M.toHundredths(p.min_alert) || 0);
    return '<span class="badge ' + (low ? 'badge--danger' : 'badge--muted') + '" title="الرصيد">' + M.fmtQty(stock) + '</span>';
  }

  function priceHtml(p) {
    var price = M.toHundredths(p.sell_price) || 0;
    return price ? M.fmt(price, true) : '<span class="badge badge--warn">بلا سعر</span>';
  }

  function renderQuickAccess() {
    var q = qaSearch.value.trim();
    qa.active = qaItems().length ? 0 : -1;
    qaGrid.innerHTML = qa.quick.length
      ? qa.quick.map(function (p, i) {
          return '<div class="qa-tile">' +
            '<button type="button" class="qa-tile__main" data-pick="' + i + '" role="option" title="' + h(p.barcode) + '">' +
            '<span class="qa-tile__name">' + h(p.name) + '</span>' +
            '<span class="qa-tile__meta"><span class="qa-tile__price">' + priceHtml(p) + '</span>' + stockBadgeHtml(p) + '</span>' +
            '</button>' + starHtml(p, i) + '</div>';
        }).join('')
      : '<p class="empty">' + (q
          ? 'لا توجد أصناف وصول سريع تطابق "' + h(q) + '".'
          : 'قائمة الوصول السريع فارغة: اكتب اسم صنف بالأعلى ثم اضغط زر البرق لإضافته.') + '</p>';
    qaMore.hidden = !q;
    var base = qa.quick.length;
    qaResults.innerHTML = qa.others.length
      ? qa.others.map(function (p, j) {
          return '<div class="qa-row">' +
            '<button type="button" class="quick-item qa-row__main" data-pick="' + (base + j) + '" role="option">' +
            '<span><span class="quick-item__name">' + h(p.name) + '</span><span class="quick-item__meta mono">' + h(p.barcode) + '</span></span>' +
            stockBadgeHtml(p) + '<span class="quick-item__price">' + priceHtml(p) + '</span>' +
            '</button>' + starHtml(p, base + j) + '</div>';
        }).join('')
      : '<p class="empty">لا توجد أصناف أخرى مطابقة.</p>';
    markQuickAccessActive();
  }

  function markQuickAccessActive() {
    Array.prototype.forEach.call(qaDlg.querySelectorAll('[data-pick]'), function (el) {
      var on = Number(el.dataset.pick) === qa.active;
      el.classList.toggle('is-active', on);
      if (on) el.scrollIntoView({ block: 'nearest' });
    });
  }

  function pickQuickAccess(idx) {
    var p = qaItems()[idx];
    if (!p) return;
    qaDlg.close();
    addProduct(p);
    MP.beep(true);
  }

  function toggleQuickAccess(idx, btn) {
    var p = qaItems()[idx];
    if (!p || qa.busy[p.id]) return;
    qa.busy[p.id] = true;
    btn.disabled = true;
    MP.api.post('api/product_crud.php', { action: 'quick', id: p.id, value: p.is_quick ? 0 : 1 }).then(function (res) {
      p.is_quick = res.product.is_quick;
      qa.quick = qa.quick.filter(function (x) { return x !== p; });
      qa.others = qa.others.filter(function (x) { return x !== p; });
      if (p.is_quick) {
        qa.quick.push(p);
        qa.quick.sort(function (a, b) { return a.name.localeCompare(b.name, 'ar'); });
      } else if (qaSearch.value.trim()) {
        qa.others.unshift(p);                   // يبقى ظاهراً في النتائج ليمكن التراجع فوراً
      }
      renderQuickAccess();
      MP.toast((p.is_quick ? 'أُضيف للوصول السريع: ' : 'أُلغي من الوصول السريع: ') + p.name, p.is_quick ? 'success' : 'info');
    }, function (err) {
      btn.disabled = false;
      MP.toast(err.message, 'error');
    }).then(function () {
      delete qa.busy[p.id];
      qaSearch.focus();
    });
  }

  qaDlg.addEventListener('click', function (e) {
    var star = e.target.closest('[data-star]');
    if (star) {
      toggleQuickAccess(Number(star.dataset.star), star);
      return;
    }
    var pickBtn = e.target.closest('[data-pick]');
    if (pickBtn) pickQuickAccess(Number(pickBtn.dataset.pick));
  });

  qaSearch.addEventListener('input', MP.debounce(loadQuickAccess, 200));
  qaSearch.addEventListener('keydown', function (e) {
    var n = qaItems().length;
    var step = { ArrowDown: 1, ArrowLeft: 1, ArrowUp: -1, ArrowRight: -1 }[e.key];   // RTL: اليسار = التالي
    if (step && n) {
      e.preventDefault();
      qa.active = (qa.active + step + n) % n;
      markQuickAccessActive();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (qa.active >= 0) pickQuickAccess(qa.active);
    }
  });

  qaDlg.addEventListener('close', function () {
    if (qa.ctrl) qa.ctrl.abort();
    setTimeout(focusScan, 0);
  });

  /* ── حفظ الفاتورة ─────────────────────────────────────────────────── */

  function warnBox(kind, title, lines) {
    return '<div class="alert alert--' + kind + '"><strong>' + h(title) + '</strong><ul>' +
      lines.slice(0, 8).map(function (l) { return '<li>' + h(l.name) + '</li>'; }).join('') +
      (lines.length > 8 ? '<li>و' + (lines.length - 8) + ' أصناف أخرى</li>' : '') +
      '</ul></div>';
  }

  function openCheckout() {
    if (saving) return;
    if (!state.lines.length) {
      MP.toast('الفاتورة فارغة. امسح صنفاً أولاً.', 'warn');
      MP.beep(false);
      return;
    }
    if (quickDlg.open) quickDlg.close();
    if (qaDlg.open) qaDlg.close();
    closeInvoiceView();
    $('coTotal').textContent = M.fmt(cartTotal(), true);
    $('coLines').textContent = '(' + state.lines.length + ' صنف)';
    var zero = state.lines.filter(function (l) { return l.priceC === 0; });
    var short = state.lines.filter(function (l) { return l.qtyH > l.stockH; });
    var html = '';
    if (zero.length) html += warnBox('warn', zero.length + ' صنف بسعر 0.00، تأكد من السعر قبل الحفظ:', zero);
    if (short.length) {
      html += APP.allowNegative
        ? warnBox('warn', 'الكمية أكبر من الرصيد المسجل، وسيصبح الرصيد سالباً:', short)
        : warnBox('danger', 'الكمية أكبر من الرصيد المسجل، والحفظ ممنوع في الإعدادات:', short);
    }
    $('coWarnings').innerHTML = html;
    var canSavePrices = state.lines.some(function (l) { return l.basePriceC === 0 && l.priceC > 0; });
    $('coSavePricesRow').hidden = !canSavePrices;
    if (!canSavePrices) $('coSavePrices').checked = false;
    $('coError').hidden = true;
    MP.openDialog(checkoutDlg);
    $('coName').focus();
  }

  function showCheckoutError(message) {
    $('coError').textContent = message;
    $('coError').hidden = false;
  }

  // بطاقة "آخر فاتورة": زر يفتح تفاصيلها في مكانها (assets/js/invoice_view.js) دون مغادرة شاشة البيع.
  function showLastInvoice(inv) {
    var box = $('lastInvoice');
    var voided = inv.status === 'void';
    box.classList.toggle('is-void', voided);
    box.innerHTML = 'آخر فاتورة: <strong>#' + h(inv.number) + '</strong> — ' + M.fmt(M.toHundredths(inv.total) || 0, true) + ' ' + h(APP.currency) +
      (voided ? ' <span class="badge badge--danger">ملغاة</span>' : '') +
      '<br><span class="muted">' + h(inv.customer_name) + ' · ' + h(MP.fmtDateTime(inv.created_at)) + '</span>' +
      '<span class="last-invoice__hint">عرض التفاصيل</span>';
    box.hidden = false;
    MP.store.set('mp_last_invoice', inv);
  }

  $('lastInvoice').addEventListener('click', function () {
    var last = MP.store.get('mp_last_invoice', null);
    if (!last || !last.id || !window.MPInvoice) return;
    MPInvoice.open(last.id, {
      onChange: function (data) {
        var inv = data.invoice;
        showLastInvoice({ id: inv.id, number: inv.number, total: inv.total, customer_name: inv.customer_name,
                          created_at: inv.created_at, lines: data.items.length, status: inv.status });
      }
    }).catch(function () { /* الرسالة ظهرت */ });
  });

  function save() {
    if (saving || !state.lines.length) return;
    saving = true;
    coSubmit.disabled = true;
    coSubmit.textContent = 'جارٍ الحفظ…';
    $('coError').hidden = true;
    if (!state.uuid) state.uuid = MP.uuid();
    persist();
    var total = cartTotal();
    var payload = {
      client_uuid: state.uuid,
      customer_name: $('coName').value.trim(),
      customer_phone: $('coPhone').value.trim(),
      save_prices: $('coSavePrices').checked,
      items: state.lines.map(function (l) {
        return { product_id: l.id, quantity: M.fmt(l.qtyH), unit_price: M.fmt(l.priceC), note: (l.note || '').trim() };
      })
    };

    MP.api.post('api/save_invoice.php', payload, { timeout: 30000 }).then(function (res) {
      var inv = res.invoice;
      if (res.duplicate && M.toHundredths(inv.total) !== total) {
        // محاولة سابقة حُفظت فعلاً ثم عُدّلت السلة بعدها: نُظهر الفرق ولا نخفيه.
        state.uuid = MP.uuid();
        persist();
        showCheckoutError('هذه الفاتورة حُفظت سابقاً برقم ' + inv.number + ' بإجمالي ' + M.fmt(M.toHundredths(inv.total) || 0, true) +
          ' قبل تعديلك الأخير. احذف من السلة ما حُفظ، ثم احفظ الباقي كفاتورة جديدة.');
        MP.beep(false);
        return;
      }
      clearCart();
      checkoutDlg.close();
      coForm.reset();
      showLastInvoice(inv);
      MP.beep(true);
      MP.toast('حُفظت الفاتورة رقم ' + inv.number + ' — ' + M.fmt(M.toHundredths(inv.total) || 0, true) + ' ' + APP.currency, 'success');
      (res.warnings || []).forEach(function (w) { MP.toast(w, 'warn', { duration: 7000 }); });
      if (res.prices_saved) MP.toast('حُفظ سعر البيع لـ ' + res.prices_saved + ' صنف.', 'info');
    }, function (err) {
      var message = err.message;
      if (err.data && Array.isArray(err.data.items)) {
        message += ' ' + err.data.items.map(function (i) { return i.name + ' (الرصيد ' + i.stock + ')'; }).join('، ');
      }
      if (err.code === 'timeout') message += ' إعادة المحاولة آمنة: الفاتورة لن تُسجَّل مرتين.';
      showCheckoutError(message);
      MP.beep(false);
    }).then(function () {
      saving = false;
      coSubmit.disabled = false;
      coSubmit.innerHTML = 'حفظ <kbd>Enter</kbd>';
      pendingScans.splice(0).forEach(function (code) { enqueueBarcode(code, false); });
      if (!checkoutDlg.open) focusScan();
    });
  }

  coForm.addEventListener('submit', function (e) {
    e.preventDefault();
    save();
  });

  checkoutDlg.addEventListener('cancel', function (e) {
    if (saving) e.preventDefault();             // لا إغلاق بـ Esc أثناء الحفظ
  });
  checkoutDlg.addEventListener('close', function () { setTimeout(focusScan, 0); });

  /* ── الأزرار ───────────────────────────────────────────────────────── */

  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-action]');
    if (!el) return;
    switch (el.dataset.action) {
      case 'quick-access': openQuickAccess(); break;
      case 'quick-fast': openQuick('fast'); break;
      case 'quick-unbarcoded': openQuick('unbarcoded'); break;
      case 'checkout': openCheckout(); break;
      case 'clear':
        if (state.lines.length && window.confirm('مسح كل الأصناف من الفاتورة الحالية؟')) clearCart();
        break;
    }
  });

  /* ── البداية ───────────────────────────────────────────────────────── */

  restore();
  render();
  var last = MP.store.get('mp_last_invoice', null);
  if (last && last.number) showLastInvoice(last);
  document.addEventListener('keydown', onKeyDown, true);
  focusScan();
})();
