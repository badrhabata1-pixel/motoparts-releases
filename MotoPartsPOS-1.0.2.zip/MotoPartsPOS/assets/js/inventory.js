/*
 * شاشة المخزون: بحث حي (تأخير 250ms مع إلغاء الطلب السابق)، تصفية، صفحات من 50 صفاً،
 * إضافة وتعديل وحذف، توريد وجرد، ومعاينة ملصق الباركود وطباعته (assets/js/barcode.js).
 */
(function () {
  'use strict';

  var MP = window.MP, APP = window.APP || {}, B = window.MPBarcode;
  var M = MP.money, h = MP.escapeHtml;
  function $(id) { return document.getElementById(id); }

  var url = new URLSearchParams(location.search);
  var state = { q: '', filter: url.get('filter') || 'all', offset: 0, limit: 50, total: 0, items: [], ctrl: null, seq: 0 };
  var body = $('invBody'), table = body.closest('table'), searchEl = $('invSearch'), filterEl = $('invFilter');
  var prevBtn = document.querySelector('[data-action="prev"]'), nextBtn = document.querySelector('[data-action="next"]');

  if (filterEl.querySelector('option[value="' + state.filter + '"]')) filterEl.value = state.filter;
  else state.filter = 'all';

  /* ── القائمة ───────────────────────────────────────────────────────── */

  function load() {
    if (state.ctrl) state.ctrl.abort();
    state.ctrl = new AbortController();
    var seq = ++state.seq;
    table.classList.add('is-loading');
    MP.api.get('api/search_product.php', {
      q: state.q, filter: state.filter, limit: state.limit, offset: state.offset, count: 1, dups: 1
    }, { signal: state.ctrl.signal }).then(function (res) {
      state.items = res.items;
      state.total = res.total;
      render();
    }, function (err) {
      if (err.code !== 'aborted') MP.toast(err.message, 'error');
    }).then(function () {
      if (seq === state.seq) table.classList.remove('is-loading');
    });
  }

  function rowHtml(p, i) {
    var stock = M.toHundredths(p.stock) || 0;
    var min = M.toHundredths(p.min_alert) || 0;
    var sell = M.toHundredths(p.sell_price) || 0;
    var buy = M.toHundredths(p.buy_price) || 0;
    var inactive = !p.is_active;
    var quickLabel = p.is_quick ? 'إلغاء من الوصول السريع (F3)' : 'إضافة للوصول السريع (F3)';
    var actions = inactive
      ? '<button class="icon-btn" type="button" data-row-action="restore" title="استعادة الصنف"><svg class="icon"><use href="#i-restore"/></svg></button>'
      : '<button class="qa-star' + (p.is_quick ? ' is-on' : '') + '" type="button" data-row-action="quick" title="' + quickLabel + '" aria-label="' + quickLabel + '"' +
        ' aria-pressed="' + (p.is_quick ? 'true' : 'false') + '"><svg class="icon"><use href="#i-bolt"/></svg></button>' +
        '<button class="icon-btn" type="button" data-row-action="label" title="معاينة وطباعة ملصق الباركود"><svg class="icon"><use href="#i-printer"/></svg></button>' +
        '<button class="icon-btn" type="button" data-row-action="edit" title="تعديل"><svg class="icon"><use href="#i-edit"/></svg></button>' +
        '<button class="icon-btn" type="button" data-row-action="stock" title="توريد أو جرد"><svg class="icon"><use href="#i-layers"/></svg></button>' +
        '<button class="icon-btn icon-btn--danger" type="button" data-row-action="delete" title="حذف"><svg class="icon"><use href="#i-trash"/></svg></button>';
    // الضغط على الباركود أو اسم الصنف يفتح معاينة الملصق.
    var labelLink = function (text, cls) {
      return inactive ? h(text) : '<button type="button" class="link-btn' + cls + '" data-row-action="label" title="معاينة وطباعة ملصق الباركود">' + h(text) + '</button>';
    };
    return '<tr data-index="' + i + '"' + (inactive ? ' class="is-inactive"' : '') + '>' +
      '<td class="mono">' + labelLink(p.barcode, ' mono') + '</td>' +
      '<td>' + labelLink(p.name, '') + (p.dups > 1 ? ' <span class="badge badge--info" title="أسماء مطابقة محفوظة كسجلات مستقلة (قاعدة عدم الدمج)">مكرر ×' + p.dups + '</span>' : '') + '</td>' +
      '<td class="notes-cell"' + (p.notes ? ' title="' + h(p.notes) + '">' + h(p.notes) : '><span class="muted">—</span>') + '</td>' +
      '<td>' + (p.is_barcoded ? '<span class="badge badge--ok">باركود</span>' : '<span class="badge badge--muted">يدوي</span>') + '</td>' +
      '<td class="num' + (stock <= min ? ' qty-low' : '') + '">' + M.fmtQty(stock) + '</td>' +
      '<td class="num">' + M.fmt(buy, true) + '</td>' +
      '<td class="num">' + (sell === 0 ? '<span class="badge badge--warn">0.00</span>' : M.fmt(sell, true)) + '</td>' +
      '<td class="num">' + M.fmtQty(min) + '</td>' +
      '<td class="actions">' + actions + '</td>' +
      '</tr>';
  }

  function render() {
    if (!state.items.length) {
      body.innerHTML = '<tr><td colspan="9" class="empty">' +
        (state.q ? 'لا توجد نتائج لـ "' + h(state.q) + '".' : 'لا توجد أصناف هنا بعد. أضف صنفاً أو استورد ملف Excel.') + '</td></tr>';
    } else {
      body.innerHTML = state.items.map(rowHtml).join('');
    }
    var from = state.total ? state.offset + 1 : 0;
    var to = state.offset + state.items.length;
    $('invCount').textContent = 'عرض ' + from + '–' + to + ' من ' + state.total.toLocaleString('en-US') + ' صنف';
    prevBtn.disabled = state.offset === 0;
    nextBtn.disabled = to >= state.total;
  }

  searchEl.addEventListener('input', MP.debounce(function () {
    state.q = searchEl.value.trim();
    state.offset = 0;
    load();
  }, 250));

  filterEl.addEventListener('change', function () {
    state.filter = filterEl.value;
    state.offset = 0;
    load();
  });

  prevBtn.addEventListener('click', function () {
    state.offset = Math.max(0, state.offset - state.limit);
    load();
  });
  nextBtn.addEventListener('click', function () {
    state.offset += state.limit;
    load();
  });

  body.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-row-action]');
    if (!btn) return;
    var p = state.items[Number(btn.closest('tr').dataset.index)];
    if (!p) return;
    switch (btn.dataset.rowAction) {
      case 'quick': toggleQuick(p, btn); break;
      case 'label': openLabel(p); break;
      case 'edit': openProduct(p); break;
      case 'stock': openStock(p); break;
      case 'delete': removeProduct(p); break;
      case 'restore': restoreProduct(p); break;
    }
  });

  // الوصول السريع [F3] بضغطة واحدة: يتحدث الزر في مكانه، والجدول يُعاد تحميله فقط في تصفية "الوصول السريع".
  function toggleQuick(p, btn) {
    if (btn.disabled) return;
    btn.disabled = true;
    MP.api.post('api/product_crud.php', { action: 'quick', id: p.id, value: p.is_quick ? 0 : 1 }).then(function (res) {
      p.is_quick = res.product.is_quick;
      MP.toast((p.is_quick ? 'أُضيف للوصول السريع: ' : 'أُلغي من الوصول السريع: ') + p.name, p.is_quick ? 'success' : 'info');
      if (state.filter === 'quick') {
        load();
        return;
      }
      var label = p.is_quick ? 'إلغاء من الوصول السريع (F3)' : 'إضافة للوصول السريع (F3)';
      btn.classList.toggle('is-on', !!p.is_quick);
      btn.setAttribute('aria-pressed', p.is_quick ? 'true' : 'false');
      btn.title = label;
      btn.setAttribute('aria-label', label);
      btn.disabled = false;
    }, function (err) {
      btn.disabled = false;
      MP.toast(err.message, 'error');
    });
  }

  document.querySelector('[data-action="new"]').addEventListener('click', function () { openProduct(null); });
  // طباعة ملصقات ما يظهر الآن: نفس البحث والتصفية تنتقل إلى صفحة الملصقات.
  document.querySelector('[data-action="labels"]').addEventListener('click', function () {
    var params = new URLSearchParams({ page: 'labels', q: state.q, filter: state.filter === 'inactive' ? 'all' : state.filter });
    location.href = 'index.php?' + params.toString();
  });

  /* ── بطاقة الصنف ───────────────────────────────────────────────────── */

  var pDlg = $('productDialog'), pForm = $('productForm');
  var editing = null;

  function openProduct(product, presetBarcode) {
    editing = product || null;
    pForm.reset();
    var f = pForm.elements;
    $('productTitle').textContent = product ? 'تعديل صنف' : 'صنف جديد';
    pForm.querySelector('[data-create-only]').hidden = !!product;
    $('productError').hidden = true;
    $('productHistory').hidden = true;
    $('barcodePreview').hidden = true;
    if (product) {
      f.product_name.value = product.name;
      f.barcode.value = product.barcode;
      f.barcode.placeholder = '';
      f.is_barcoded.checked = !!product.is_barcoded;
      f.is_quick_access.checked = !!product.is_quick;
      f.notes.value = product.notes || '';
      f.buy_price.value = product.buy_price;
      f.sell_price.value = product.sell_price;
      f.min_alert_qty.value = M.fmtQty(M.toHundredths(product.min_alert) || 0);
      $('barcodePreview').hidden = false;
      B.preview($('editLabelPreview'), [product], B.settings(), { single: true, scale: 1.4 });
      loadHistory(product.id);
    } else {
      f.barcode.placeholder = 'يُولَّد تلقائياً';
      f.barcode.value = presetBarcode || '';
      f.min_alert_qty.value = APP.defaultMinAlert;
      f.buy_price.value = '0.00';
      f.sell_price.value = '0.00';
      f.stock_quantity.value = '0';
    }
    MP.openDialog(pDlg);
    f.product_name.focus();
  }

  pForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var f = pForm.elements;
    var payload = {
      action: editing ? 'update' : 'create',
      id: editing ? editing.id : 0,
      product_name: f.product_name.value,
      barcode: MP.normalizeDigits(f.barcode.value).trim(),
      is_barcoded: f.is_barcoded.checked ? 1 : 0,
      is_quick_access: f.is_quick_access.checked ? 1 : 0,
      notes: f.notes.value,
      buy_price: f.buy_price.value,
      sell_price: f.sell_price.value,
      min_alert_qty: f.min_alert_qty.value,
      stock_quantity: f.stock_quantity.value
    };
    if (editing && payload.barcode !== '' && payload.barcode.toLowerCase() !== editing.barcode.toLowerCase() &&
        !window.confirm('تغيير الباركود يعني أن الملصقات المطبوعة بالرقم القديم لن تُقرأ. متابعة؟')) {
      return;
    }
    var btn = pForm.querySelector('[type="submit"]');
    btn.disabled = true;
    MP.api.post('api/product_crud.php', payload).then(function (res) {
      pDlg.close();
      MP.toast(editing ? 'حُفظ التعديل.' : 'أُضيف الصنف بباركود ' + res.product.barcode, 'success');
      load();
    }, function (err) {
      $('productError').textContent = err.message;
      $('productError').hidden = false;
    }).then(function () { btn.disabled = false; });
  });

  function loadHistory(id) {
    MP.api.get('api/product_crud.php', { id: id }).then(function (res) {
      if (!res.movements.length) return;
      $('historyBody').innerHTML = res.movements.map(function (m) {
        var change = M.toHundredths(m.change) || 0;
        return '<tr><td>' + h(MP.fmtDateTime(m.created_at)) + '</td><td>' + h(m.reason) + '</td>' +
          '<td class="num">' + (change > 0 ? '+' : '') + M.fmtQty(change) + '</td>' +
          '<td class="num">' + M.fmtQty(M.toHundredths(m.balance) || 0) + '</td><td>' + h(m.note) + '</td></tr>';
      }).join('');
      $('productHistory').hidden = false;
    }, function () { /* السجل اختياري */ });
  }

  /* ── التوريد والجرد ────────────────────────────────────────────────── */

  var sDlg = $('stockDialog'), sForm = $('stockForm');
  var stockItem = null;

  function openStock(p) {
    stockItem = p;
    sForm.reset();
    $('stockProduct').textContent = p.name + ' — ' + p.barcode;
    $('stockCurrent').textContent = M.fmtQty(M.toHundredths(p.stock) || 0);
    $('stockError').hidden = true;
    updateStockPreview();
    MP.openDialog(sDlg);
    sForm.elements.quantity.focus();
  }

  function updateStockPreview() {
    if (!stockItem) return;
    var mode = sForm.elements.mode.value;
    $('stockQtyLabel').textContent = mode === 'restock' ? 'الكمية الواردة' : 'الرصيد الفعلي بعد العد';
    var v = M.toHundredths(sForm.elements.quantity.value);
    var current = M.toHundredths(stockItem.stock) || 0;
    $('stockAfter').textContent = v === null ? '—' : M.fmtQty(mode === 'restock' ? current + v : v);
  }
  sForm.addEventListener('input', updateStockPreview);
  sForm.addEventListener('change', updateStockPreview);

  sForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var f = sForm.elements;
    var mode = f.mode.value;
    var payload = { action: mode, id: stockItem.id, note: f.note.value };
    payload[mode === 'restock' ? 'quantity' : 'new_quantity'] = f.quantity.value;
    var btn = sForm.querySelector('[type="submit"]');
    btn.disabled = true;
    MP.api.post('api/product_crud.php', payload).then(function (res) {
      sDlg.close();
      MP.toast('الرصيد الآن ' + M.fmtQty(M.toHundredths(res.product.stock) || 0) + ' — ' + res.product.name, 'success');
      load();
    }, function (err) {
      $('stockError').textContent = err.message;
      $('stockError').hidden = false;
    }).then(function () { btn.disabled = false; });
  });

  /* ── الحذف والاستعادة ──────────────────────────────────────────────── */

  function removeProduct(p) {
    if (!window.confirm('حذف "' + p.name + '"؟\nإن كان للصنف مبيعات سابقة فسيُخفى فقط ويبقى في الفواتير القديمة.')) return;
    MP.api.post('api/product_crud.php', { action: 'delete', id: p.id }).then(function (res) {
      MP.toast(res.mode === 'soft' ? 'أُخفي الصنف لأن له مبيعات سابقة. تجده في تصفية "المحذوفة".' : 'حُذف الصنف نهائياً.', 'success');
      load();
    }, function (err) { MP.toast(err.message, 'error'); });
  }

  function restoreProduct(p) {
    MP.api.post('api/product_crud.php', { action: 'restore', id: p.id }).then(function () {
      MP.toast('استُعيد الصنف ' + p.name, 'success');
      load();
    }, function (err) { MP.toast(err.message, 'error'); });
  }

  /* ── ملصق الباركود: معاينة بالخطوط الحقيقية وطباعة مباشرة ──────────── */

  var lDlg = $('labelDialog'), lForm = $('labelForm');
  var labelItem = null;

  function labelSettings() {
    var f = lForm.elements;
    var s = Object.assign(B.settings(), {
      preset: f.preset.value, showName: f.showName.checked, showPrice: f.showPrice.checked, showCode: f.showCode.checked
    });
    B.saveSettings(s);
    return s;
  }

  function labelCopies() {
    return Math.max(1, Math.min(500, parseInt(MP.normalizeDigits(lForm.elements.copies.value), 10) || 1));
  }

  function renderLabel() {
    var s = labelSettings();
    B.preview($('labelPreviewBox'), [labelItem], s, { single: true, scale: B.geometry(s).w > 55 ? 1.8 : 2.4 });
    $('labelWeak').hidden = B.weak([labelItem], s).length === 0;
  }

  function openLabel(p) {
    labelItem = p;
    var s = B.settings(), f = lForm.elements;
    f.preset.innerHTML = B.presetOptions(s.preset);
    f.showName.checked = s.showName;
    f.showPrice.checked = s.showPrice;
    f.showCode.checked = s.showCode;
    // نسخة لكل قطعة في المخزون افتراضياً (ملصق على كل قطعة)، وواحدة على الأقل.
    f.copies.value = Math.max(1, Math.ceil((M.toHundredths(p.stock) || 0) / 100));
    $('labelProduct').textContent = p.name;
    $('labelNoPrice').hidden = (M.toHundredths(p.sell_price) || 0) > 0;
    $('labelMore').href = 'index.php?page=labels&ids=' + p.id;
    MP.openDialog(lDlg);
    renderLabel();
    f.copies.select();
  }

  lForm.addEventListener('change', renderLabel);
  lForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var s = labelSettings();
    var copies = labelCopies();
    var labels = [];
    for (var i = 0; i < copies; i++) labels.push(labelItem);
    B.print(labels, s);
  });

  document.querySelector('[data-action="label-from-edit"]').addEventListener('click', function () {
    var p = editing;
    pDlg.close();
    if (p) openLabel(p);
  });

  /* ── البداية ───────────────────────────────────────────────────────── */

  load();
  if (url.get('new')) openProduct(null, url.get('new'));
  searchEl.focus();
})();
