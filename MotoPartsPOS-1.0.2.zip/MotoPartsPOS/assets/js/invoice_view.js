/*
 * نافذة تفاصيل الفاتورة (window.MPInvoice): تُستخدم في صفحة الفواتير وفي بطاقة "آخر فاتورة" بشاشة البيع.
 *
 *   MPInvoice.open(id, { mode: 'cancel', onChange: function (data) {} })
 *
 * ثلاثة أوضاع داخل النافذة نفسها:
 * - عرض: بيانات العميل والبنود والإجماليات وسجل المرتجعات والإلغاء.
 * - مرتجع جزئي: كمية مرتجع أمام كل صنف.
 * - إرجاع صنف: زر أمام كل بند يفتح نافذة صغيرة فوقها (الكمية + طريقة الإرجاع + المبلغ المخصوم).
 *   في المرتجع بنوعيه يُختار صراحةً: للمخزن أو مالي فقط. وما يُنهي آخر كمية يحوّل الفاتورة إلى ملغاة.
 * - إلغاء: خياران صريحان (إرجاع الأصناف للمخزن / حذف الفاتورة فقط)، ولا خيار محدد مسبقاً،
 *   فلا يتغير المخزون بالخطأ.
 */
(function () {
  'use strict';

  var MP = window.MP, APP = window.APP || {};
  var M = MP.money, h = MP.escapeHtml;

  var dlg = null, el = {};
  var state = { data: null, mode: 'view', busy: false, onChange: null };

  function build() {
    dlg = document.createElement('dialog');
    dlg.id = 'invoiceDialog';
    dlg.className = 'dialog dialog--wide';
    dlg.setAttribute('aria-labelledby', 'ivTitle');
    dlg.innerHTML =
      '<div class="dialog__head">' +
        '<h2 class="dialog__title" id="ivTitle">فاتورة</h2>' +
        '<button class="icon-btn" type="button" data-close aria-label="إغلاق"><svg class="icon"><use href="#i-x"/></svg></button>' +
      '</div>' +
      '<div class="dialog__body stack" id="ivBody"></div>' +
      '<div class="dialog__foot" id="ivFoot"></div>';
    document.body.appendChild(dlg);
    el.title = dlg.querySelector('#ivTitle');
    el.body = dlg.querySelector('#ivBody');
    el.foot = dlg.querySelector('#ivFoot');
    dlg.addEventListener('click', onClick);
    dlg.addEventListener('change', onChange);
    dlg.addEventListener('cancel', function (e) {
      if (state.busy) e.preventDefault();             // لا إغلاق بـ Esc أثناء التنفيذ
    });
  }

  /* ── حسابات من البيانات ───────────────────────────────────────────── */

  function money(v) { return M.fmt(M.toHundredths(v) || 0, true); }

  function remaining() {
    var lines = 0, pieces = 0, amount = 0;
    state.data.items.forEach(function (it) {
      var qty = M.toHundredths(it.quantity) || 0;
      var left = qty - (M.toHundredths(it.returned_qty) || 0);
      if (left > 0) {
        lines++;
        pieces += left;
      }
    });
    var inv = state.data.invoice;
    amount = (M.toHundredths(inv.total) || 0) - (M.toHundredths(inv.returned) || 0);
    return { lines: lines, pieces: pieces, amount: amount };
  }

  function statusBadge(inv) {
    if (inv.status === 'void') {
      if (inv.void_restocked === 0) return '<span class="badge badge--danger">ملغاة · بدون إرجاع مخزون</span>';
      if (inv.void_restocked === 1) return '<span class="badge badge--danger">ملغاة · أُعيدت للمخزن</span>';
      return '<span class="badge badge--danger">ملغاة · مرتجعة بالكامل</span>';
    }
    var returned = M.toHundredths(inv.returned) || 0;
    if (returned > 0) {
      return returned >= (M.toHundredths(inv.total) || 0)
        ? '<span class="badge badge--warn">مرتجعة بالكامل</span>'
        : '<span class="badge badge--warn">بها مرتجع جزئي</span>';
    }
    return '<span class="badge badge--ok">مكتملة</span>';
  }

  /* ── الرسم ─────────────────────────────────────────────────────────── */

  function render() {
    var d = state.data, inv = d.invoice, mode = state.mode;
    var anyReturned = d.items.some(function (it) { return (M.toHundredths(it.returned_qty) || 0) > 0; });
    var left = remaining();
    var open = inv.status !== 'void' && left.lines > 0;
    if (!open && mode !== 'view') mode = state.mode = 'view';
    var lineCol = mode === 'view' && open;

    el.title.innerHTML = 'فاتورة رقم <span class="mono">' + h(inv.number) + '</span> ' + statusBadge(inv);

    var rows = d.items.map(function (it) {
      var qty = M.toHundredths(it.quantity) || 0;
      var ret = M.toHundredths(it.returned_qty) || 0;
      var rest = qty - ret;
      return '<tr data-item="' + it.id + '">' +
        '<td class="mono">' + h(it.barcode) + '</td>' +
        '<td>' + h(it.name) + (it.notes
          ? '<span class="item-note" title="ملاحظة البند"><svg class="icon icon--sm"><use href="#i-edit"/></svg> ' + h(it.notes) + '</span>'
          : '') + '</td>' +
        '<td class="num">' + M.fmtQty(qty) + '</td>' +
        '<td class="num">' + money(it.unit_price) + '</td>' +
        '<td class="num">' + money(it.subtotal) + '</td>' +
        (anyReturned ? '<td class="num">' + (ret ? M.fmtQty(ret) : '—') + '</td>' : '') +
        (mode === 'return' ? '<td>' + (rest > 0
          ? '<input class="input return-qty" inputmode="decimal" placeholder="0" data-left="' + rest + '" aria-label="كمية المرتجع">'
          : '') + '</td>' : '') +
        (lineCol ? '<td class="line-action">' + (rest > 0
          ? '<button class="btn btn--sm" type="button" data-iv="line-return">إرجاع الصنف 🔄</button>'
          : '<span class="muted">رجع بالكامل</span>') + '</td>' : '') +
        '</tr>';
    }).join('');

    var total = M.toHundredths(inv.total) || 0, returned = M.toHundredths(inv.returned) || 0;
    var html =
      '<div class="kpis kpis--compact">' +
        '<div class="kpi"><span class="kpi__label">التاريخ والوقت</span><strong>' + h(MP.fmtDateTime(inv.created_at)) + '</strong></div>' +
        '<div class="kpi"><span class="kpi__label">العميل</span><strong>' + h(inv.customer_name) + '</strong>' +
          (inv.customer_phone ? '<span class="kpi__unit mono">' + h(inv.customer_phone) + '</span>' : '') + '</div>' +
        '<div class="kpi"><span class="kpi__label">عدد الأصناف</span><strong>' + d.items.length + '</strong></div>' +
        '<div class="kpi kpi--accent"><span class="kpi__label">الإجمالي</span><strong>' + M.fmt(total, true) + ' ' + h(APP.currency) + '</strong></div>' +
      '</div>' +
      '<div class="table-wrap table-wrap--tall"><table class="grid grid--compact">' +
        '<thead><tr><th>الباركود</th><th>الصنف</th><th class="num">الكمية</th><th class="num">السعر</th><th class="num">الإجمالي</th>' +
        (anyReturned ? '<th class="num">مرتجع / ملغى</th>' : '') +
        (mode === 'return' ? '<th>كمية المرتجع الآن</th>' : '') +
        (lineCol ? '<th class="actions-col">إرجاع</th>' : '') +
        '</tr></thead><tbody>' + rows + '</tbody>' +
        '<tfoot><tr><th colspan="4">الإجمالي الكلي</th><th class="num">' + M.fmt(total, true) + '</th>' +
        (anyReturned ? '<th></th>' : '') + (mode === 'return' ? '<th></th>' : '') + (lineCol ? '<th></th>' : '') + '</tr></tfoot>' +
      '</table></div>';

    if (returned > 0) {
      html += '<p class="totals-line">المرتجع والملغى: <strong>' + M.fmt(returned, true) + '</strong> · الصافي: <strong>' +
        M.fmt(total - returned, true) + ' ' + h(APP.currency) + '</strong></p>';
    }
    if (d.returns.length) {
      html += '<div><h3 class="subhead">سجل المرتجعات والإلغاء</h3><ul class="history-list">' + d.returns.map(function (r) {
        var kind = !r.is_void
          ? (r.restocked ? 'مرتجع للمخزن' : 'مرتجع مالي فقط (بدون المخزن)')
          : (r.restocked ? 'إلغاء مع إرجاع الأصناف للمخزن' : 'حذف الفاتورة دون تعديل المخزن');
        return '<li><span class="muted">' + h(MP.fmtDateTime(r.created_at)) + '</span> — <strong>' + h(kind) + '</strong> بقيمة ' + money(r.amount) +
          (r.items.length ? ': ' + r.items.map(function (i) { return h(i.name) + ' × ' + M.fmtQty(M.toHundredths(i.quantity) || 0); }).join('، ') : '') +
          (r.note ? ' <span class="muted">(' + h(r.note) + ')</span>' : '') + '</li>';
      }).join('') + '</ul></div>';
    }

    if (mode === 'return') {
      html += restockChoice('ivReturnMode') +
        '<label class="field"><span class="field__label">سبب المرتجع (اختياري)</span><input class="input" id="ivNote" maxlength="255" autocomplete="off"></label>';
    }
    if (mode === 'cancel') html += cancelPanel(left);
    html += '<div class="alert alert--danger" id="ivError" hidden></div>';
    el.body.innerHTML = html;

    var foot = '';
    if (mode === 'view') {
      if (open) {
        foot += '<button class="btn btn--danger" type="button" data-iv="cancel"><svg class="icon"><use href="#i-trash"/></svg> إلغاء / حذف الفاتورة</button>' +
                '<button class="btn" type="button" data-iv="return">مرتجع جزئي</button>';
      } else if (inv.status !== 'void') {
        foot += '<span class="muted">كل أصناف الفاتورة مرتجعة.</span>';
      }
      foot += '<span class="spacer"></span><button class="btn btn--ghost" type="button" data-close>إغلاق</button>';
    } else if (mode === 'return') {
      foot += '<button class="btn btn--ghost" type="button" data-iv="back">رجوع</button><span class="spacer"></span>' +
              '<button class="btn btn--primary" type="button" data-iv="confirm-return" disabled>اختر طريقة الإرجاع أولاً</button>';
    } else {
      foot += '<button class="btn btn--ghost" type="button" data-iv="back">رجوع</button><span class="spacer"></span>' +
              '<button class="btn btn--danger btn--lg" type="button" data-iv="confirm-cancel" disabled>اختر طريقة الإلغاء أولاً</button>';
    }
    el.foot.innerHTML = foot;

    if (mode === 'return') {
      var first = el.body.querySelector('.return-qty');
      if (first) first.focus();
    }
  }

  function cancelPanel(left) {
    var amount = M.fmt(left.amount, true) + ' ' + h(APP.currency);
    return '<div class="cancel-panel" role="group" aria-labelledby="ivCancelTitle">' +
      '<p class="cancel-panel__title" id="ivCancelTitle">كيف تريد إلغاء الفاتورة رقم ' + h(state.data.invoice.number) + '؟</p>' +
      '<label class="option-card">' +
        '<input type="radio" name="ivCancelMode" value="restock">' +
        '<span class="option-card__body"><strong>إلغاء واسترجاع الأصناف للمخزن</strong>' +
        '<span>ترجع الكميات المتبقية (' + left.lines + ' صنف، ' + M.fmtQty(left.pieces) + ' قطعة) إلى رصيد المخزون، ' +
        'وتُسجَّل حركة "إلغاء فاتورة" في دفتر كل صنف.</span></span>' +
      '</label>' +
      '<label class="option-card">' +
        '<input type="radio" name="ivCancelMode" value="no_stock">' +
        '<span class="option-card__body"><strong>حذف الفاتورة فقط (دون تعديل كميات المخزن)</strong>' +
        '<span>تخرج الفاتورة من المبيعات، وتبقى أرصدة الأصناف كما هي الآن تماماً. ' +
        'مناسب إذا كانت الأصناف لن تعود للرف، أو كان المخزون قد عُدّل يدوياً.</span></span>' +
      '</label>' +
      '<p class="cancel-panel__impact">في الحالتين: يُخصم <strong>' + amount + '</strong> من مبيعات اليوم، وتبقى الفاتورة في السجل بحالة "ملغاة".</p>' +
      '<label class="field"><span class="field__label">سبب الإلغاء (اختياري)</span><input class="input" id="ivNote" maxlength="255" autocomplete="off"></label>' +
      '</div>';
  }

  // خيارا المرتجع، بلا خيار محدد مسبقاً حتى لا يتغير المخزون بالخطأ.
  function restockChoice(name) {
    return '<div class="stack-sm" role="radiogroup" aria-label="طريقة الإرجاع">' +
      '<label class="option-card"><input type="radio" name="' + name + '" value="restock">' +
        '<span class="option-card__body"><strong>استرجاع لرصيد المخزن 🔄</strong>' +
        '<span>الكمية ترجع لرصيد الصنف، وتُسجَّل حركة "مرتجع" في دفتر المخزون.</span></span></label>' +
      '<label class="option-card"><input type="radio" name="' + name + '" value="money">' +
        '<span class="option-card__body"><strong>مرتجع مالي فقط بدون زيادة المخزن ❌</strong>' +
        '<span>يُخصم المبلغ من الفاتورة، ورصيد الصنف يبقى كما هو (مثلاً قطعة تالفة لن ترجع للرف).</span></span></label>' +
      '</div>';
  }

  function markSelected(scope, input) {
    Array.prototype.forEach.call(scope.querySelectorAll('.option-card'), function (card) {
      card.classList.toggle('is-selected', !!input && card.contains(input));
    });
  }

  function returnMessage(r) {
    var msg = 'سُجّل المرتجع بقيمة ' + money(r.amount) + ' ' + APP.currency +
      (r.restocked ? '، والكمية رجعت للمخزن.' : ' دون تعديل رصيد المخزن.');
    if (r.closed) msg += ' لم يبقَ شيء في الفاتورة فأصبحت "ملغاة / مرتجعة بالكامل".';
    return msg;
  }

  function showError(message) {
    var box = el.body.querySelector('#ivError');
    box.textContent = message;
    box.hidden = false;
  }

  /* ── الأحداث ───────────────────────────────────────────────────────── */

  function onChange(e) {
    var name = e.target.name, restock = e.target.value === 'restock', btn;
    if (name === 'ivCancelMode') {
      btn = el.foot.querySelector('[data-iv="confirm-cancel"]');
      btn.textContent = restock ? 'تأكيد: إلغاء وإرجاع الأصناف للمخزن' : 'تأكيد: حذف الفاتورة فقط';
    } else if (name === 'ivReturnMode') {
      btn = el.foot.querySelector('[data-iv="confirm-return"]');
      btn.textContent = restock ? 'تأكيد المرتجع وإرجاع الكمية للمخزن' : 'تأكيد المرتجع المالي فقط';
    } else {
      return;
    }
    btn.disabled = false;
    markSelected(el.body, e.target);
  }

  function onClick(e) {
    var btn = e.target.closest('[data-iv]');
    if (!btn || state.busy) return;
    switch (btn.dataset.iv) {
      case 'cancel': state.mode = 'cancel'; render(); break;
      case 'return': state.mode = 'return'; render(); break;
      case 'back': state.mode = 'view'; render(); break;
      case 'confirm-return': submitReturn(btn); break;
      case 'confirm-cancel': submitCancel(btn); break;
      case 'line-return': openLine(Number(btn.closest('tr').dataset.item)); break;
    }
  }

  function send(payload, btn, success, fail) {
    state.busy = true;
    btn.disabled = true;
    MP.api.post('api/invoices.php', payload).then(function (res) {
      state.data = { invoice: res.invoice, items: res.items, returns: res.returns };
      state.mode = 'view';
      render();
      success(res);
      if (state.onChange) state.onChange(state.data);
    }, function (err) {
      (fail || showError)(err.message);
      btn.disabled = false;
    }).then(function () { state.busy = false; });
  }

  function submitReturn(btn) {
    var items = [], bad = null;
    Array.prototype.forEach.call(el.body.querySelectorAll('.return-qty'), function (input) {
      if (input.value.trim() === '') return;
      var v = M.toHundredths(input.value);
      if (v === null || v < 0 || v > Number(input.dataset.left)) bad = input;
      else if (v > 0) items.push({ item_id: Number(input.closest('tr').dataset.item), quantity: M.fmt(v) });
    });
    if (bad) {
      showError('كمية المرتجع غير صالحة أو أكبر من المتبقي (' + M.fmtQty(Number(bad.dataset.left)) + ').');
      bad.focus();
      return;
    }
    if (!items.length) {
      showError('اكتب كمية المرتجع أمام صنف واحد على الأقل.');
      return;
    }
    var choice = el.body.querySelector('[name="ivReturnMode"]:checked');
    if (!choice) return;
    send({ action: 'return', invoice_id: state.data.invoice.id, items: items, restock: choice.value === 'restock',
           note: el.body.querySelector('#ivNote').value }, btn, function (res) {
      MP.toast(returnMessage(res.return), 'success', { duration: 5000 });
    });
  }

  function submitCancel(btn) {
    var choice = el.body.querySelector('[name="ivCancelMode"]:checked');
    if (!choice) return;
    var restock = choice.value === 'restock';
    send({ action: 'void', invoice_id: state.data.invoice.id, restock: restock, note: el.body.querySelector('#ivNote').value }, btn, function (res) {
      MP.toast(restock
        ? 'أُلغيت الفاتورة ورجعت ' + M.fmtQty(M.toHundredths(res.return.restocked_qty) || 0) + ' قطعة للمخزن.'
        : 'حُذفت الفاتورة من المبيعات دون تعديل المخزن.', 'success', { duration: 5000 });
    });
  }

  /* ── نافذة إرجاع بند واحد (تفتح فوق نافذة الفاتورة) ───────────────── */

  var lineDlg = null, ln = {}, line = null;

  function buildLine() {
    lineDlg = document.createElement('dialog');
    lineDlg.id = 'lineReturnDialog';
    lineDlg.className = 'dialog dialog--line';
    lineDlg.setAttribute('aria-labelledby', 'lrTitle');
    lineDlg.innerHTML =
      '<form novalidate>' +
        '<div class="dialog__head">' +
          '<h2 class="dialog__title" id="lrTitle">إرجاع صنف</h2>' +
          '<button class="icon-btn" type="button" data-close aria-label="إغلاق"><svg class="icon"><use href="#i-x"/></svg></button>' +
        '</div>' +
        '<div class="dialog__body stack">' +
          '<div><p class="stock-product" id="lrName"></p><p class="lr-facts" id="lrFacts"></p></div>' +
          '<label class="field"><span class="field__label" id="lrQtyLabel"></span>' +
            '<input class="input input--lg" name="qty" inputmode="decimal" autocomplete="off" required></label>' +
          restockChoice('lrMode') +
          '<div class="return-amount" id="lrAmount" aria-live="polite"></div>' +
          '<label class="field"><span class="field__label">سبب الإرجاع (اختياري)</span>' +
            '<input class="input" name="note" maxlength="255" autocomplete="off"></label>' +
          '<div class="alert alert--danger" id="lrError" hidden></div>' +
        '</div>' +
        '<div class="dialog__foot">' +
          '<button class="btn btn--ghost" type="button" data-close>إلغاء</button>' +
          '<button class="btn btn--primary" type="submit"></button>' +
        '</div>' +
      '</form>';
    document.body.appendChild(lineDlg);
    ln.form = lineDlg.querySelector('form');
    ln.name = lineDlg.querySelector('#lrName');
    ln.facts = lineDlg.querySelector('#lrFacts');
    ln.qtyLabel = lineDlg.querySelector('#lrQtyLabel');
    ln.qty = ln.form.elements.qty;
    ln.note = ln.form.elements.note;
    ln.amount = lineDlg.querySelector('#lrAmount');
    ln.error = lineDlg.querySelector('#lrError');
    ln.submit = ln.form.querySelector('[type="submit"]');
    ln.form.addEventListener('input', updateLine);
    ln.form.addEventListener('change', function (e) {
      if (e.target.name === 'lrMode') markSelected(lineDlg, e.target);
      updateLine();
    });
    ln.form.addEventListener('submit', function (e) {
      e.preventDefault();
      submitLine();
    });
    lineDlg.addEventListener('cancel', function (e) {
      if (state.busy) e.preventDefault();
    });
  }

  function lineFigures() {
    var qty = M.toHundredths(line.quantity) || 0;
    var left = qty - (M.toHundredths(line.returned_qty) || 0);
    var want = M.toHundredths(ln.qty.value);
    var valid = want !== null && want > 0 && want <= left;
    // آخر جزء من البند يُحسب بالفرق كما في الخادم، فمجموع مرتجعاته يساوي إجماليه تماماً.
    var amount = !valid ? 0 : want === left
      ? (M.toHundredths(line.subtotal) || 0) - (M.toHundredths(line.returned_amount) || 0)
      : M.lineTotal(M.toHundredths(line.unit_price) || 0, want);
    return { left: left, want: want, valid: valid, amount: amount };
  }

  function updateLine() {
    var f = lineFigures(), inv = state.data.invoice, cur = ' ' + h(APP.currency);
    var mode = ln.form.querySelector('[name="lrMode"]:checked');
    ln.qty.classList.toggle('is-invalid', ln.qty.value.trim() !== '' && !f.valid);
    if (f.valid) {
      var net = (M.toHundredths(inv.total) || 0) - (M.toHundredths(inv.returned) || 0);
      var closes = f.want === f.left && remaining().lines === 1;
      ln.amount.innerHTML =
        '<span>مبلغ الإرجاع المخصوم من الفاتورة: <strong>' + M.fmt(f.amount, true) + cur + '</strong></span>' +
        '<span class="muted">صافي الفاتورة بعد الإرجاع: ' + M.fmt(net - f.amount, true) + cur + '</span>' +
        (closes ? '<span class="return-amount__close">هذا آخر ما تبقى في الفاتورة، فستتحول حالتها إلى "ملغاة / مرتجعة بالكامل".</span>' : '');
    } else {
      ln.amount.innerHTML = '<span class="muted">اكتب كمية أكبر من صفر ولا تتعدى ' + M.fmtQty(f.left) + '.</span>';
    }
    ln.submit.disabled = !f.valid || !mode;
    ln.submit.textContent = !mode ? 'اختر طريقة الإرجاع أولاً'
      : 'تأكيد إرجاع ' + (f.valid ? M.fmt(f.amount, true) + ' ' + APP.currency : '');
  }

  function openLine(itemId) {
    line = state.data.items.filter(function (it) { return it.id === itemId; })[0];
    if (!line) return;
    if (!lineDlg) buildLine();
    var qty = M.toHundredths(line.quantity) || 0, ret = M.toHundredths(line.returned_qty) || 0;
    ln.form.reset();
    markSelected(lineDlg, null);
    ln.error.hidden = true;
    ln.name.textContent = line.name;
    ln.facts.innerHTML = '<span class="mono">' + h(line.barcode) + '</span> · المباع ' + M.fmtQty(qty) +
      (ret ? ' · رجع منه ' + M.fmtQty(ret) : '') + ' · المتبقي <strong>' + M.fmtQty(qty - ret) + '</strong>' +
      ' · سعر الوحدة ' + money(line.unit_price);
    ln.qtyLabel.textContent = 'الكمية المراد إرجاعها (حتى ' + M.fmtQty(qty - ret) + ')';
    ln.qty.value = M.fmtQty(qty - ret);
    updateLine();
    MP.openDialog(lineDlg);
    ln.qty.focus();
    ln.qty.select();
  }

  function submitLine() {
    var f = lineFigures(), mode = ln.form.querySelector('[name="lrMode"]:checked');
    if (!f.valid || !mode || state.busy) return;
    ln.error.hidden = true;
    send({ action: 'return', invoice_id: state.data.invoice.id, restock: mode.value === 'restock',
           items: [{ item_id: line.id, quantity: M.fmt(f.want) }], note: ln.note.value }, ln.submit, function (res) {
      lineDlg.close();
      MP.toast(returnMessage(res.return), 'success', { duration: 5000 });
    }, function (message) {
      ln.error.textContent = message;
      ln.error.hidden = false;
    });
  }

  /* ── الواجهة العامة ────────────────────────────────────────────────── */

  function open(id, opts) {
    opts = opts || {};
    if (!dlg) build();
    state.onChange = opts.onChange || null;
    return MP.api.get('api/invoices.php', { action: 'get', id: id }).then(function (res) {
      state.data = res;
      state.mode = opts.mode === 'cancel' ? 'cancel' : 'view';
      state.busy = false;
      render();
      MP.openDialog(dlg);
      return res;
    }, function (err) {
      MP.toast(err.message, 'error');
      throw err;
    });
  }

  window.MPInvoice = {
    open: open,
    isOpen: function () { return !!(dlg && dlg.open); },
    close: function () {
      if (state.busy) return;
      if (lineDlg && lineDlg.open) lineDlg.close();
      if (dlg && dlg.open) dlg.close();
    },
    statusBadge: statusBadge,
    dialog: function () { return dlg; }
  };
})();
