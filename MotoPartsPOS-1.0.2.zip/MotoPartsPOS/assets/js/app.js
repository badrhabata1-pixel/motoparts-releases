/*
 * MotoParts POS — أدوات مشتركة لكل الصفحات (window.MP). بلا مكتبات.
 * متوافق مع Chrome 109 (آخر إصدار على Windows 8.1) و Firefox ESR 115.
 */
(function () {
  'use strict';

  var APP = window.APP || {};

  /* ── النصوص ──────────────────────────────────────────────────────── */

  // الأرقام العربية-الهندية (٠-٩) والفارسية (۰-۹) والفاصلة العشرية العربية → لاتينية. مطابق لـ normalize_digits() في PHP.
  function normalizeDigits(value) {
    return String(value == null ? '' : value).replace(/[٠-٩۰-۹٫٬]/g, function (ch) {
      var c = ch.charCodeAt(0);
      if (c === 0x066B) return '.';
      if (c === 0x066C) return ',';
      return String(c >= 0x06F0 ? c - 0x06F0 : c - 0x0660);
    });
  }

  var ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) { return ESCAPES[c]; });
  }

  /* ── المال والكميات: أعداد صحيحة بالمئات، مطابقة لـ to_hundredths() و line_subtotal() في PHP ── */

  function toHundredths(value) {
    if (typeof value === 'number') {
      if (!isFinite(value)) return null;
      value = value.toFixed(6);
    }
    var s = normalizeDigits(value).replace(/[\s ]/g, '');
    if (s === '') return null;
    if (/e/i.test(s) && !isNaN(Number(s))) s = Number(s).toFixed(6);
    if (s.indexOf(',') !== -1) {
      if (s.indexOf('.') !== -1 || !/^-?\d+,\d{1,2}$/.test(s)) s = s.replace(/,/g, '');
      else s = s.replace(',', '.');
    }
    var m = /^(-?)(\d*)(?:\.(\d*))?$/.exec(s);
    if (!m || (m[2] === '' && (m[3] || '') === '')) return null;
    if (m[2].length > 12) return null;
    var frac = ((m[3] || '') + '000').slice(0, 3);
    var v = Number(m[2] || '0') * 100 + Math.floor((Number(frac) + 5) / 10);
    return m[1] === '-' ? -v : v;
  }

  function fmtHundredths(v, grouped) {
    var neg = v < 0;
    v = Math.abs(v);
    var int = String(Math.floor(v / 100));
    if (grouped) int = int.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return (neg ? '-' : '') + int + '.' + String(v % 100).padStart(2, '0');
  }

  // 100 → "1"، 150 → "1.5"، 125 → "1.25"
  function fmtQty(v) {
    return fmtHundredths(v, false).replace(/\.00$/, '').replace(/(\.\d)0$/, '$1');
  }

  // السعر (قروش) × الكمية (مئات) ÷ 100 بتقريب نصف لأعلى.
  function lineTotal(priceCents, qtyHundredths) {
    return Math.floor((priceCents * qtyHundredths + 50) / 100);
  }

  var money = { toHundredths: toHundredths, fmt: fmtHundredths, fmtQty: fmtQty, lineTotal: lineTotal };

  /* ── التخزين المحلي (قد يكون معطلاً: كل وصول داخل try) ───────────── */

  var store = {
    get: function (key, fallback) {
      try {
        var v = localStorage.getItem(key);
        return v == null ? fallback : JSON.parse(v);
      } catch (e) { return fallback; }
    },
    set: function (key, value) {
      try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* التخزين ممتلئ أو معطّل */ }
    },
    remove: function (key) {
      try { localStorage.removeItem(key); } catch (e) { /* لا شيء */ }
    }
  };

  /* ── معرّف فريد للفاتورة (مفتاح عدم التكرار) ─────────────────────── */

  // crypto.randomUUID يعمل على localhost فقط (سياق آمن)؛ من عنوان شبكة محلية نستخدم getRandomValues.
  function uuid() {
    if (window.crypto && typeof crypto.randomUUID === 'function') {
      try { return crypto.randomUUID(); } catch (e) { /* سياق غير آمن */ }
    }
    var b = new Uint8Array(16);
    crypto.getRandomValues(b);
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    var hex = Array.prototype.map.call(b, function (x) { return (x + 0x100).toString(16).slice(1); }).join('');
    return hex.slice(0, 8) + '-' + hex.slice(8, 12) + '-' + hex.slice(12, 16) + '-' + hex.slice(16, 20) + '-' + hex.slice(20);
  }

  /* ── طلبات الخادم ─────────────────────────────────────────────────── */

  function failure(message, code, extra) {
    var err = new Error(message);
    err.code = code;
    if (extra) Object.keys(extra).forEach(function (k) { err[k] = extra[k]; });
    return err;
  }

  /**
   * كل الطلبات نسبية (api/…): ترث المنفذ 8081 من الصفحة فلا يُكتب أي منفذ في JavaScript.
   * الترويسة X-Requested-With مطلوبة في كل ملفات api/ (حماية من CSRF).
   */
  function request(method, url, opts) {
    opts = opts || {};
    if (opts.params) {
      var qs = Object.keys(opts.params).filter(function (k) {
        return opts.params[k] !== undefined && opts.params[k] !== null && opts.params[k] !== '';
      }).map(function (k) {
        return encodeURIComponent(k) + '=' + encodeURIComponent(opts.params[k]);
      }).join('&');
      if (qs) url += (url.indexOf('?') === -1 ? '?' : '&') + qs;
    }
    var ctrl = new AbortController();
    var timedOut = false;
    var timer = setTimeout(function () { timedOut = true; ctrl.abort(); }, opts.timeout || 15000);
    if (opts.signal) {
      if (opts.signal.aborted) ctrl.abort();
      else opts.signal.addEventListener('abort', function () { ctrl.abort(); }, { once: true });
    }
    var headers = { 'X-Requested-With': 'MotoPartsPOS', 'Accept': 'application/json' };
    var body;
    if (opts.form) {
      body = opts.form;
    } else if (opts.body !== undefined) {
      headers['Content-Type'] = 'application/json';
      body = JSON.stringify(opts.body);
    }

    return fetch(url, { method: method, headers: headers, body: body, signal: ctrl.signal, credentials: 'same-origin', cache: 'no-store' })
      .then(function (res) {
        clearTimeout(timer);
        var type = res.headers.get('Content-Type') || '';
        if (opts.raw && res.ok && type.indexOf('application/json') === -1) return res;
        return res.json().catch(function () {
          throw failure('رد غير متوقع من الخادم (' + res.status + ').', 'bad_response');
        }).then(function (data) {
          if (res.status === 401 && data && data.code === 'auth') {
            // انتهت الجلسة: صفحة الدخول تعيد المستخدم لنفس الصفحة، والسلة محفوظة في المتصفح.
            location.href = 'login.php?expired=1&next=' + encodeURIComponent('index.php?page=' + (APP.page || 'pos'));
          }
          if (!res.ok || !data || data.ok !== true) {
            throw failure((data && data.error) || ('خطأ من الخادم (' + res.status + ').'), (data && data.code) || res.status, { data: data, status: res.status });
          }
          return data;
        });
      }, function (e) {
        clearTimeout(timer);
        if (e && e.name === 'AbortError') {
          if (timedOut) throw failure('انتهت مهلة الاتصال بالخادم. حاول مرة أخرى.', 'timeout');
          throw failure('أُلغي الطلب.', 'aborted');
        }
        throw failure('تعذر الاتصال بالخادم. أعد فتح البرنامج من أيقونة سطح المكتب، أو شغّل «إصلاح خادم MotoParts» من قائمة ابدأ.', 'network');
      });
  }

  var api = {
    get: function (url, params, opts) { return request('GET', url, Object.assign({}, opts, { params: params })); },
    post: function (url, body, opts) { return request('POST', url, Object.assign({}, opts, { body: body })); },
    upload: function (url, form, opts) { return request('POST', url, Object.assign({ timeout: 300000 }, opts, { form: form })); },
    /** تنزيل ملف (xlsx أو نسخة احتياطية) عبر fetch، لأن الرابط المباشر لا يحمل ترويسة الحماية. */
    download: function (url, params, fallbackName) {
      return request('GET', url, { params: params, raw: true, timeout: 120000 }).then(function (res) {
        var disposition = res.headers.get('Content-Disposition') || '';
        var match = /filename="?([^";]+)"?/i.exec(disposition);
        var name = match ? match[1] : fallbackName;
        return res.blob().then(function (blob) {
          var link = document.createElement('a');
          link.href = URL.createObjectURL(blob);
          link.download = name;
          document.body.appendChild(link);
          link.click();
          setTimeout(function () { URL.revokeObjectURL(link.href); link.remove(); }, 2000);
          return name;
        });
      });
    }
  };

  /* ── الإشعارات ────────────────────────────────────────────────────── */

  function toast(message, type, opts) {
    type = type || 'info';
    opts = opts || {};
    var box = document.getElementById('toasts');
    if (!box) {
      box = document.createElement('div');
      box.id = 'toasts';
      box.className = 'toasts';
      document.body.appendChild(box);
    }
    var el = document.createElement('div');
    el.className = 'toast toast--' + type;
    el.setAttribute('role', type === 'error' ? 'alert' : 'status');
    var text = document.createElement('span');
    text.textContent = message;
    el.appendChild(text);
    if (opts.action) {
      var a = document.createElement('a');
      a.className = 'toast__action';
      a.href = opts.action.href;
      a.textContent = opts.action.label;
      el.appendChild(a);
    }
    box.appendChild(el);
    while (box.children.length > 4) box.removeChild(box.firstChild);
    setTimeout(function () { el.remove(); }, opts.duration || (type === 'error' ? 6500 : 3500));
  }

  /* ── صوت الماسح: نغمات مولّدة بـ Web Audio، بلا ملفات صوت ─────────── */

  var audioCtx = null;
  var soundOn = store.get('mp_sound', true) !== false;

  function tone(freq, start, duration) {
    var osc = audioCtx.createOscillator();
    var gain = audioCtx.createGain();
    osc.type = 'square';
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.06, start);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start(start);
    osc.stop(start + duration + 0.02);
  }

  function beep(ok) {
    if (!soundOn) return;
    try {
      var Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      audioCtx = audioCtx || new Ctx();
      if (audioCtx.state === 'suspended') audioCtx.resume();
      var t = audioCtx.currentTime + 0.01;
      if (ok) {
        tone(1568, t, 0.07);
      } else {
        tone(330, t, 0.12);
        tone(247, t + 0.16, 0.18);
      }
    } catch (e) { /* الصوت غير متاح */ }
  }

  // Chrome يمنع تشغيل الصوت قبل أول تفاعل: أول ضغطة مفتاح أو نقرة تفتح سياق الصوت.
  function unlockAudio() {
    var Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    try {
      audioCtx = audioCtx || new Ctx();
      if (audioCtx.state === 'suspended') audioCtx.resume();
    } catch (e) { /* لا شيء */ }
  }
  document.addEventListener('keydown', unlockAudio, { once: true, capture: true });
  document.addEventListener('pointerdown', unlockAudio, { once: true, capture: true });

  /* ── أدوات متفرقة ─────────────────────────────────────────────────── */

  function debounce(fn, ms) {
    var timer;
    return function () {
      var self = this, args = arguments;
      clearTimeout(timer);
      timer = setTimeout(function () { fn.apply(self, args); }, ms);
    };
  }

  function openDialog(dialog) {
    if (!dialog.open) dialog.showModal();
  }

  // أي زر يحمل data-close يغلق النافذة التي يقع فيها.
  document.addEventListener('click', function (e) {
    var closer = e.target.closest('[data-close]');
    if (closer) {
      var dialog = closer.closest('dialog');
      if (dialog && dialog.open) dialog.close();
    }
  });

  function fmtDateTime(value) {
    // "2026-10-24 14:05:09" من MySQL → "2026-10-24 14:05"
    return String(value || '').slice(0, 16);
  }

  /* ── الشريط العلوي: الوضع الليلي، الصوت، الساعة ───────────────────── */

  document.addEventListener('click', function (e) {
    if (e.target.closest('[data-action="toggle-theme"]')) {
      var dark = document.documentElement.getAttribute('data-theme') !== 'dark';
      document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
      store.set('mp_theme', dark ? 'dark' : 'light');
    } else if (e.target.closest('[data-action="toggle-sound"]')) {
      soundOn = !soundOn;
      store.set('mp_sound', soundOn);
      document.body.classList.toggle('sound-off', !soundOn);
      if (soundOn) beep(true);
    }
  });
  document.body.classList.toggle('sound-off', !soundOn);

  // ساعة الخادم: إزاحة PHP (APP_TIMEZONE) على ساعة الجهاز. إن خالفت ساعة شريط المهام فالإعداد خاطئ.
  var clock = document.getElementById('clock');
  function tick() {
    if (!clock) return;
    var d = new Date(Date.now() + (APP.tzOffsetMin || 0) * 60000);
    var hh = d.getUTCHours(), mm = String(d.getUTCMinutes()).padStart(2, '0');
    var suffix = hh < 12 ? 'ص' : 'م';
    var h12 = hh % 12 === 0 ? 12 : hh % 12;
    clock.textContent = h12 + ':' + mm + ' ' + suffix;
  }
  tick();
  setInterval(tick, 15000);

  /* ── مهمة أول تشغيل في اليوم: نسخة احتياطية تلقائية (بعد هدوء الصفحة) ── */

  function runDaily() {
    if (store.get('mp_daily_done') === APP.today) return;
    request('POST', 'api/maintenance.php', { body: { action: 'daily' }, timeout: 300000 })
      .then(function () { store.set('mp_daily_done', APP.today); })
      .catch(function () { /* يُعاد غداً أو عند التحميل التالي */ });
  }
  setTimeout(function () {
    (window.requestIdleCallback || function (cb) { setTimeout(cb, 0); })(runDaily, { timeout: 10000 });
  }, 20000);

  window.MP = {
    api: api,
    money: money,
    store: store,
    toast: toast,
    beep: beep,
    uuid: uuid,
    debounce: debounce,
    escapeHtml: escapeHtml,
    normalizeDigits: normalizeDigits,
    openDialog: openDialog,
    fmtDateTime: fmtDateTime
  };
})();
