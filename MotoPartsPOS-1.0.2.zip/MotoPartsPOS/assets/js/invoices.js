/*
 * صفحة الفواتير: بحث برقم الفاتورة أو اسم العميل أو هاتفه، تصفية بالتاريخ (اليوم / الكل / يوم محدد) والحالة،
 * وملخص مبالغ ما يظهر. الضغط على أي فاتورة يفتح نافذة التفاصيل (assets/js/invoice_view.js).
 * روابط مباشرة: ?page=invoices&date=2026-10-25  و  ?page=invoices&id=15 (تفتح الفاتورة فوراً).
 */
(function () {
  'use strict';

  var MP = window.MP, APP = window.APP || {}, IV = window.MPInvoice;
  var M = MP.money, h = MP.escapeHtml;
  function $(id) { return document.getElementById(id); }

  var url = new URLSearchParams(location.search);
  var state = { page: 1, pages: 1, items: [], ctrl: null };
  var body = $('ivBody'), search = $('ivSearch'), dateInput = $('ivDate'), statusSel = $('ivStatus');
  var prev = document.querySelector('[data-action="iv-prev"]'), next = document.querySelector('[data-action="iv-next"]');

  function dayMode() {
    var checked = document.querySelector('[name="ivDay"]:checked');
    return checked ? checked.value : 'today';
  }

  function params() {
    var p = { action: 'list', q: search.value.trim(), status: statusSel.value, page: state.page };
    var mode = dayMode();
    if (mode === 'today') p.from = p.to = APP.today;
    else if (mode === 'date' && dateInput.value) p.from = p.to = dateInput.value;
    return p;
  }

  function load() {
    if (state.ctrl) state.ctrl.abort();
    state.ctrl = new AbortController();
    MP.api.get('api/invoices.php', params(), { signal: state.ctrl.signal }).then(function (res) {
      state.items = res.items;
      state.pages = res.pages;
      render(res);
    }, function (err) {
      if (err.code !== 'aborted') MP.toast(err.message, 'error');
    });
  }

  function render(res) {
    if (!res.items.length) {
      var hint = dayMode() === 'today' && !search.value.trim()
        ? 'لا توجد فواتير اليوم بعد. <button type="button" class="link-btn" data-show-all>اعرض كل الفواتير</button>'
        : 'لا توجد فواتير مطابقة.';
      body.innerHTML = '<tr><td colspan="8" class="empty">' + hint + '</td></tr>';
    } else {
      body.innerHTML = res.items.map(function (inv, i) {
        var canCancel = inv.status !== 'void';
        return '<tr data-index="' + i + '"' + (inv.status === 'void' ? ' class="is-void"' : '') + ' title="اضغط لعرض تفاصيل الفاتورة">' +
          '<td class="mono"><strong>' + h(inv.number) + '</strong></td>' +
          '<td>' + h(MP.fmtDateTime(inv.created_at)) + '</td>' +
          '<td>' + h(inv.customer_name) + '</td>' +
          '<td class="mono">' + h(inv.customer_phone) + '</td>' +
          '<td class="num">' + inv.lines + '</td>' +
          '<td class="num">' + M.fmt(M.toHundredths(inv.total) || 0, true) + '</td>' +
          '<td>' + IV.statusBadge(inv) + '</td>' +
          '<td class="actions">' +
            '<button class="btn btn--sm" type="button" data-open>عرض</button>' +
            (canCancel ? '<button class="btn btn--sm btn--danger" type="button" data-cancel>إلغاء</button>' : '') +
          '</td></tr>';
      }).join('');
    }
    var s = res.summary;
    var set = function (key, value) { $('ivSummary').querySelector('[data-sum="' + key + '"]').textContent = value; };
    set('count', s.count.toLocaleString('en-US'));
    set('total', M.fmt(M.toHundredths(s.total) || 0, true));
    set('returned', M.fmt(M.toHundredths(s.returned) || 0, true));
    set('net', M.fmt(M.toHundredths(s.net) || 0, true) + ' ' + APP.currency);
    $('ivCount').textContent = res.total.toLocaleString('en-US') + ' فاتورة — صفحة ' + res.page + ' من ' + res.pages;
    prev.disabled = res.page <= 1;
    next.disabled = res.page >= res.pages;
  }

  function reload() {
    state.page = 1;
    load();
  }

  function openInvoice(id, mode) {
    IV.open(id, { mode: mode, onChange: function () { load(); } }).catch(function () { /* الرسالة ظهرت */ });
  }

  search.addEventListener('input', MP.debounce(reload, 300));
  statusSel.addEventListener('change', reload);
  dateInput.addEventListener('change', reload);
  document.addEventListener('change', function (e) {
    if (e.target.name !== 'ivDay') return;
    dateInput.hidden = e.target.value !== 'date';
    if (e.target.value === 'date') dateInput.focus();
    reload();
  });
  prev.addEventListener('click', function () { state.page = Math.max(1, state.page - 1); load(); });
  next.addEventListener('click', function () { state.page = Math.min(state.pages, state.page + 1); load(); });

  body.addEventListener('click', function (e) {
    if (e.target.closest('[data-show-all]')) {
      document.querySelector('[name="ivDay"][value="all"]').checked = true;
      dateInput.hidden = true;
      reload();
      return;
    }
    var tr = e.target.closest('tr[data-index]');
    if (!tr) return;
    var inv = state.items[Number(tr.dataset.index)];
    openInvoice(inv.id, e.target.closest('[data-cancel]') ? 'cancel' : 'view');
  });

  /* ── البداية: فلاتر من الرابط ──────────────────────────────────────── */

  var startDate = url.get('date');
  if (startDate && /^\d{4}-\d{2}-\d{2}$/.test(startDate) && startDate !== APP.today) {
    document.querySelector('[name="ivDay"][value="date"]').checked = true;
    dateInput.value = startDate;
    dateInput.hidden = false;
  } else if (url.get('id') || url.get('q') || url.get('all')) {
    document.querySelector('[name="ivDay"][value="all"]').checked = true;
  }
  if (url.get('q')) search.value = url.get('q');
  load();
  if (url.get('id')) openInvoice(Number(url.get('id')), url.get('mode') === 'cancel' ? 'cancel' : 'view');
  else search.focus();
})();
