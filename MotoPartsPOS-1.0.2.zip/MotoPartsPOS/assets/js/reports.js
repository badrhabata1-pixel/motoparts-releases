/*
 * التقارير: ملخص اليوم والأكثر مبيعاً ونقص المخزون تُرسم في PHP (views/reports.php).
 * سجل الفواتير والمرتجعات والإلغاء في صفحة الفواتير (views/invoices.php).
 */
(function () {
  'use strict';

  // تغيير التاريخ يعيد رسم الملخص لذلك اليوم.
  var dateForm = document.getElementById('dateForm');
  dateForm.elements.date.addEventListener('change', function () { dateForm.submit(); });
})();
