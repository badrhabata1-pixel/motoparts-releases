/*
 * ملصقات الباركود (window.MPBarcode) بلا مكتبات ولا CDN:
 * - ترميز Code 128: الطقم C للأرقام (رقمان في كل رمز، فالملصق أقصر)، والطقم B لما عداها.
 * - الخطوط مسار SVG واحد لكل باركود: عنصر واحد بدل عشرات المستطيلات، فيبقى خفيفاً على المعالج القديم.
 * - الملصق بالعرض بلا أي تدوير: اسم الصنف في سطر واحد، الخطوط رأسية في صندوق بعرض 95% من الملصق،
 *   ثم رقم الباركود يميناً والسعر يساراً. يُطبع من المتصفح على رول طابعة ملصقات أو ورق A4.
 */
(function () {
  'use strict';

  var MP = window.MP, APP = window.APP || {};
  var h = MP.escapeHtml;

  // عرض الخطوط والفراغات لكل رمز (0–105)، ثم رمز الإيقاف (106) من 7 عناصر.
  var PATTERNS = ['212222', '222122', '222221', '121223', '121322', '131222', '122213', '122312', '132212', '221213',
    '221312', '231212', '112232', '122132', '122231', '113222', '123122', '123221', '223211', '221132',
    '221231', '213212', '223112', '312131', '311222', '321122', '321221', '312212', '322112', '322211',
    '212123', '212321', '232121', '111323', '131123', '131321', '112313', '132113', '132311', '211313',
    '231113', '231311', '112133', '112331', '132131', '113123', '113321', '133121', '313121', '211331',
    '231131', '213113', '213311', '213131', '311123', '311321', '331121', '312113', '312311', '332111',
    '314111', '221411', '431111', '111224', '111422', '121124', '121421', '141122', '141221', '112214',
    '112412', '122114', '122411', '142112', '142211', '241211', '221114', '413111', '241112', '134111',
    '111242', '121142', '121241', '114212', '124112', '124211', '411212', '421112', '421211', '212141',
    '214121', '412121', '111143', '111341', '131141', '114113', '114311', '411113', '411311', '113141',
    '114131', '311141', '411131', '211412', '211214', '211232', '2331112'];
  var START_B = 104, START_C = 105, CODE_B = 100, STOP = 106;
  // فراغ أبيض قبل الخطوط وبعدها: نصف رمز البداية (5.5 وحدة) ولا يقل عن 2.5 مم. بأقل منه لا يجد الماسح
  // بداية الرمز. (المواصفة توصي بعشر وحدات؛ نصف الرمز يترك للخطوط عرض الملصق تقريباً كله.)
  var QUIET = 5.5;
  var QUIET_MM = 2.5;
  var BOX = 0.95;                 // صندوق الباركود: 95% من عرض الملصق، في وسطه
  // أعرض خط رفيع: 5 نقاط على 203 dpi (0.63 مم)، فيملأ باركود من 6 أرقام بفراغيه عرض ملصق 50 مم.
  var MAX_MODULE_MM = 0.65;
  var EDGE_MM = 0.4;              // هامش أمان عند حافتي الملصق
  var MIN_DOTS = 2;               // أقل من نقطتي طباعة للخط الرفيع = قراءة غير مضمونة
  var PX_MM = 25.4 / 96;          // بكسل CSS بالمم

  /** قيم رموز Code 128 بما فيها البداية ورقم التحقق والإيقاف، أو null لنص غير قابل للترميز. */
  function encode(text) {
    var codes, i;
    if (/^\d{2,}$/.test(text)) {
      var even = text.length - (text.length % 2);
      codes = [START_C];
      for (i = 0; i < even; i += 2) codes.push(Number(text.substr(i, 2)));
      if (even < text.length) codes.push(CODE_B, text.charCodeAt(even) - 32);   // رقم أخير منفرد بالطقم B
    } else {
      codes = [START_B];
      for (i = 0; i < text.length; i++) {
        var c = text.charCodeAt(i);
        if (c < 32 || c > 126) return null;
        codes.push(c - 32);
      }
    }
    var sum = codes[0];
    for (i = 1; i < codes.length; i++) sum += codes[i] * i;
    codes.push(sum % 103, STOP);
    return codes;
  }

  /** وحدات الرموز بلا الفراغين: كل رمز 11 وحدة والإيقاف 13. */
  function dataModules(codes) {
    return codes.length * 11 + 2;
  }

  /** مسار الخطوط (أول خط عند x = 0) وعرضها بالوحدات. */
  function bars(text) {
    var codes = encode(String(text));
    if (!codes) return null;
    var widths = codes.map(function (c) { return PATTERNS[c]; }).join('');
    var x = 0, d = '';
    for (var i = 0; i < widths.length; i++) {
      var w = Number(widths[i]);
      if (i % 2 === 0) d += 'M' + x + ' 0h' + w + 'v1h-' + w + 'z';
      x += w;
    }
    return { path: d, modules: x };
  }

  /**
   * عرض الخط الرفيع = عدد صحيح من نقاط الطابعة. خط بعرض 1.95 نقطة يُطبع مرة نقطة ومرة نقطتين فيفشل المسح؛
   * المضاعفات الصحيحة تُطبع بالعرض نفسه دائماً. أعرض خط تتسع خطوطه مع فراغيها في عرض الملصق.
   */
  function fit(data, g, s) {
    var dot = 25.4 / (Number(s.dpi) || 203);
    for (var dots = Math.floor(MAX_MODULE_MM / dot + 1e-9); dots >= 1; dots--) {
      var module = dots * dot;
      var quietMm = Math.max(QUIET * module, QUIET_MM);
      var barsMm = data * module;
      if (barsMm + 2 * quietMm <= g.cellW - EDGE_MM + 1e-9) {
        return { dots: dots, module: module, barsMm: barsMm, quietMm: quietMm, ok: dots >= MIN_DOTS };
      }
    }
    return { dots: 0, module: 0, barsMm: 0, quietMm: QUIET_MM, ok: false };
  }

  /**
   * عند الطباعة يضع Chrome صندوق الـ SVG على بكسل CSS كامل (0.26 مم)، فلو وُضع الصندوق على البداية المحسوبة
   * لانزاحت الخطوط كلها حتى نصف بكسل، أي نحو نقطة طباعة. لذلك موضع الصندوق وعرضه بكسلات CSS كاملة (95% من
   * الملصق في وسطه)، والخطوط داخله في الوسط تبدأ عند نقطة طباعة كاملة محسوبة من حافة الصفحة، بإزاحة viewBox:
   * الإحداثيات داخل الرسم لا تُقرَّب. absLeft: بُعد حافة الملصق اليسرى عن حافة الصفحة (مم).
   */
  function svg(text, g, s, absLeft) {
    var codes = encode(String(text));
    if (!codes) return '<span class="label__invalid">باركود غير قابل للطباعة</span>';
    var f = fit(dataModules(codes), g, s);
    var b = bars(text);
    var place, viewBox;
    if (f.dots >= 1) {
      var dot = 25.4 / (Number(s.dpi) || 203), abs = absLeft || 0;
      var start = Math.round((abs + (g.cellW - f.barsMm) / 2) / dot) * dot - abs;    // أول خط، على نقطة كاملة
      var box = Math.min(g.cellW, Math.max(BOX * g.cellW, f.barsMm + 2 * f.quietMm));
      var leftPx = Math.floor(Math.min((g.cellW - box) / 2, start - f.quietMm) / PX_MM + 1e-6);
      var rightMm = Math.max((g.cellW + box) / 2, start + f.barsMm + f.quietMm);
      var widthPx = Math.ceil((rightMm - leftPx * PX_MM) / PX_MM - 1e-6);
      place = 'left:' + leftPx + 'px;width:' + widthPx + 'px';
      viewBox = (-(start - leftPx * PX_MM) / f.module).toFixed(6) + ' 0 ' + (widthPx * PX_MM / f.module).toFixed(6) + ' 1';
    } else {
      place = 'left:0;width:100%';
      viewBox = (-QUIET) + ' 0 ' + (b.modules + 2 * QUIET) + ' 1';
    }
    return '<svg class="barcode" xmlns="http://www.w3.org/2000/svg" viewBox="' + viewBox + '" preserveAspectRatio="none"' +
      ' shape-rendering="crispEdges" style="' + place + '" role="img" aria-label="' + h(text) + '">' +
      '<path d="' + b.path + '" fill="#000"/></svg>';
  }

  /**
   * الأصناف التي ستُطبع خطوطها أرفع من نقطتين على المقاس والدقة المختارين.
   * يكفي عدد الرموز، فلا يُرسم مسار لكل صنف (القائمة قد تكون كل المخزون).
   */
  function weak(items, s) {
    var g = geometry(s);
    return items.filter(function (item) {
      var codes = encode(String(item.barcode));
      return !codes || !fit(dataModules(codes), g, s).ok;
    });
  }

  /* ── مقاسات الورق ─────────────────────────────────────────────────── */

  var PRESETS = {
    roll50x25: { label: 'رول طابعة ملصقات 50×25 مم', mode: 'roll', w: 50, h: 25 },
    roll40x30: { label: 'رول طابعة ملصقات 40×30 مم', mode: 'roll', w: 40, h: 30 },
    roll38x25: { label: 'رول طابعة ملصقات 38×25 مم', mode: 'roll', w: 38, h: 25 },
    roll_custom: { label: 'رول بمقاس مخصص', mode: 'roll', custom: true },
    a4_24: { label: 'ورق A4 — 24 ملصقاً (3×8، 70×37 مم)', mode: 'sheet', w: 70, h: 37, cols: 3, rows: 8, top: 0.5, side: 0, gapX: 0, gapY: 0 },
    a4_40: { label: 'ورق A4 — 40 ملصقاً (4×10، 52.5×29.7 مم)', mode: 'sheet', w: 52.5, h: 29.7, cols: 4, rows: 10, top: 0, side: 0, gapX: 0, gapY: 0 },
    a4_65: { label: 'ورق A4 — 65 ملصقاً (5×13، 38.1×21.2 مم)', mode: 'sheet', w: 38.1, h: 21.2, cols: 5, rows: 13, top: 10.7, side: 4.75, gapX: 2.5, gapY: 0 }
  };

  var DEFAULTS = { preset: 'roll50x25', w: 50, h: 25, dpi: 203, showName: true, showPrice: true, showCode: true, offsetX: 0, offsetY: 0 };
  var DPIS = { 203: 'طابعة ملصقات حرارية (203 dpi)', 300: 'حرارية عالية الدقة (300 dpi)', 600: 'طابعة ليزر أو حبر (600 dpi)' };

  function num(v, min, max, fallback) {
    var n = Number(MP.normalizeDigits(v));
    return isFinite(n) && n >= min && n <= max ? n : fallback;
  }

  function settings() {
    var s = Object.assign({}, DEFAULTS, MP.store.get('mp_label_settings', {}));
    if (!PRESETS[s.preset]) s.preset = DEFAULTS.preset;   // مقاس أُلغي (مثل رول 25×50) يعود للافتراضي
    if (!DPIS[s.dpi]) s.dpi = DEFAULTS.dpi;
    delete s.rotate;                                     // التدوير أُلغي: إعداد قديم محفوظ لا أثر له
    return s;
  }

  function dpiOptions(selected) {
    return Object.keys(DPIS).map(function (dpi) {
      return '<option value="' + dpi + '"' + (Number(dpi) === Number(selected) ? ' selected' : '') + '>' + h(DPIS[dpi]) + '</option>';
    }).join('');
  }

  function saveSettings(s) { MP.store.set('mp_label_settings', s); }

  /**
   * الأبعاد الفعلية للملصق والصفحة حسب المقاس المختار.
   * cellW × cellH: الملصق كما يُطبع (صفحة الرول أقصر 0.3 مم من الملصق حتى لا تفيض إلى صفحة فارغة).
   */
  function geometry(s) {
    var p = PRESETS[s.preset] || PRESETS[DEFAULTS.preset];
    if (p.custom) p = { mode: 'roll', w: num(s.w, 15, 120, 50), h: num(s.h, 10, 120, 25) };
    return p.mode === 'roll'
      ? Object.assign({}, p, { pageW: p.w, pageH: p.h, perPage: 1, cellW: p.w, cellH: p.h - 0.3 })
      : Object.assign({}, p, { pageW: 210, pageH: 297, perPage: p.cols * p.rows, cellW: p.w, cellH: p.h });
  }

  function presetOptions(selected) {
    return Object.keys(PRESETS).map(function (key) {
      return '<option value="' + key + '"' + (key === selected ? ' selected' : '') + '>' + h(PRESETS[key].label) + '</option>';
    }).join('');
  }

  /* ── الملصق ───────────────────────────────────────────────────────── */

  // السعر 0.00 يعني أن السعر لم يُحدَّد بعد: يُطبع الملصق بلا سعر بدل "0".
  function priceText(price) {
    var cents = MP.money.toHundredths(price) || 0;
    if (cents <= 0) return '';
    return MP.money.fmt(cents, true).replace(/\.00$/, '') + ' ' + (APP.currency || '');
  }

  var measure = null;

  /** عرض النص بالمم لكل نقطة من حجم الخط، بخط الملصق العريض. قياس canvas: يشكّل العربي كما يُرسم، بلا تخطيط صفحة. */
  function nameMmPerPt(name) {
    if (!measure) {
      measure = document.createElement('canvas').getContext('2d');
      var family = getComputedStyle(document.documentElement).getPropertyValue('--font').trim() || 'Tahoma, Arial, sans-serif';
      measure.font = '700 100px ' + family;
    }
    return measure.measureText(String(name)).width / 100 * 25.4 / 72;
  }

  /**
   * حجم خط اسم الصنف (نقطة) ليتسع في سطر واحد على عرض الملصق: الاسم القصير بالحجم الكامل، والطويل يصغر
   * حتى يتسع دون النزول عن حد القراءة، وما لا يتسع بعدها يُختصر بـ … في CSS.
   * قياس لا رسم: آلاف الملصقات تُبنى دفعة واحدة على جهاز قديم.
   */
  function nameSize(name, g, small) {
    var max = small ? 7 : 9, min = small ? 5.5 : 6;
    var lineMm = (g.cellW - (small ? 2.4 : 3.2)) * 0.97;
    var fits = lineMm / Math.max(1e-6, nameMmPerPt(name));
    return Math.max(min, Math.min(max, Math.floor(fits * 4) / 4));
  }

  /**
   * ملصق واحد يملأ خانته بالعرض (صفحة الرول أو خلية الورقة): الاسم في الأعلى، الخطوط في الوسط، ثم رقم الباركود
   * يميناً والسعر يساراً (اتجاه rtl). absLeft: بُعد الخانة عن حافة الصفحة اليسرى بالمم، لمحاذاة الخطوط مع نقاط الطابعة.
   */
  function labelHtml(item, s, g, cache, absLeft) {
    var key = item.barcode + '|' + (absLeft || 0);
    var bar = cache[key] || (cache[key] = svg(item.barcode, g, s, absLeft));
    var price = s.showPrice ? priceText(item.sell_price) : '';
    var foot = (s.showCode ? '<span class="label__code">' + h(item.barcode) + '</span>' : '') +
      (price ? '<span class="label__price">' + h(price) + '</span>' : '');
    var small = g.cellH < 24 || g.cellW < 40;
    return '<div class="label' + (small ? ' label--small' : '') + '" dir="rtl">' +
      (s.showName ? '<div class="label__name" style="font-size:' + nameSize(item.name, g, small) + 'pt">' + h(item.name) + '</div>' : '') +
      '<div class="label__bars">' + bar + '</div>' +
      (foot ? '<div class="label__foot">' + foot + '</div>' : '') +
      '</div>';
  }

  /**
   * الصفحات كما تُطبع: صفحة لكل ملصق في الرول، وصفحة A4 لكل ورقة ملصقات.
   * @return {pages: string[], g: object}
   */
  function buildPages(labels, s, limit) {
    var g = geometry(s), cache = {}, pages = [], i, j;
    var n = limit ? Math.min(limit, labels.length) : labels.length;
    var offsetX = num(s.offsetX, -20, 20, 0), offsetY = num(s.offsetY, -20, 20, 0);
    var shift = 'transform:translate(' + offsetX + 'mm,' + offsetY + 'mm)';
    if (g.mode === 'roll') {
      for (i = 0; i < n; i++) {
        pages.push('<div class="print-page" style="width:' + g.cellW + 'mm;height:' + g.cellH + 'mm"><div class="print-slot" style="' + shift + '">' +
          labelHtml(labels[i], s, g, cache, offsetX) + '</div></div>');
      }
    } else {
      // كل خلية في موضعها بالمم بإزاحة transform دقيقة، لا بشبكة CSS: الشبكة تضع الخلايا على كسور البكسل،
      // و Chrome يقرّب ما بداخلها عند الطباعة فتنزاح الخطوط عن نقاط الطابعة.
      for (i = 0; i < n; i += g.perPage) {
        var cells = '';
        for (j = i; j < Math.min(i + g.perPage, n); j++) {
          var col = (j - i) % g.cols, row = Math.floor((j - i) / g.cols);   // الورقة من اليسار لليمين (.print-sheet ltr)
          var x = offsetX + g.side + col * (g.w + g.gapX), y = offsetY + g.top + row * (g.h + g.gapY);
          cells += '<div class="print-cell" style="width:' + g.w + 'mm;height:' + g.h + 'mm;transform:translate(' + x + 'mm,' + y + 'mm)">' +
            labelHtml(labels[j], s, g, cache, x) + '</div>';
        }
        pages.push('<div class="print-sheet">' + cells + '</div>');
      }
    }
    return { pages: pages, g: g };
  }

  /** كل صنف يتكرر بعدد نسخه. */
  function expand(items) {
    var out = [];
    items.forEach(function (item) {
      for (var k = 0; k < (item.copies || 0); k++) out.push(item);
    });
    return out;
  }

  function pageCount(labelCount, s) {
    return Math.ceil(labelCount / geometry(s).perPage);
  }

  /** ورقة بيضاء بمقاسها الحقيقي (مم) مضروباً في scale. */
  function paper(w, h, scale, inner) {
    return '<div class="paper" style="width:calc(' + w + 'mm * ' + scale + ');height:calc(' + h + 'mm * ' + scale + ')">' +
      '<div class="paper__inner" style="width:' + w + 'mm;height:' + h + 'mm;transform:scale(' + scale + ')">' + inner + '</div></div>';
  }

  /**
   * معاينة بمقياس على الشاشة: كل صفحة "ورقة" بيضاء بمقاسها الحقيقي مضروباً في scale (الرول 50×25 مستطيل عريض).
   * opts.single: ملصق واحد كبير بمقاسه هو، حتى لو كان المقاس المختار ورقة A4.
   */
  function preview(container, labels, s, opts) {
    opts = opts || {};
    var g = geometry(s);
    if (opts.single) {
      var one = labels[0];
      if (!one) {
        container.innerHTML = '';
        return { shown: 0, total: 0 };
      }
      container.innerHTML = paper(g.w, g.h, opts.scale || 2,
        '<div style="width:' + g.cellW + 'mm;height:' + g.cellH + 'mm">' + labelHtml(one, s, g, {}) + '</div>');
      return { shown: 1, total: labels.length };
    }
    var limit = g.mode === 'roll' ? (opts.maxLabels || 24) : g.perPage * (opts.maxSheets || 1);
    var scale = opts.scale || (g.mode === 'roll' ? 1.6 : Math.min(1, Math.max(0.3, (container.clientWidth - 40) / (210 * 3.78))));
    container.innerHTML = buildPages(labels, s, limit).pages.map(function (page) {
      return paper(g.pageW, g.pageH, scale, page);
    }).join('') || '<p class="empty">لا توجد ملصقات للمعاينة.</p>';
    return { shown: Math.min(limit, labels.length), total: labels.length };
  }

  /**
   * الطباعة من المتصفح: الملصقات تُكتب في #printArea، ومقاس الصفحة يُضبط بقاعدة @page،
   * وكل ما عداها يُخفى في الطباعة (assets/css/style.css: is-printing-labels).
   */
  function print(labels, s) {
    var built = buildPages(labels, s);
    var area = document.getElementById('printArea');
    if (!area) {
      area = document.createElement('div');
      area.id = 'printArea';
      document.body.appendChild(area);
    }
    area.innerHTML = built.pages.join('');
    var style = document.getElementById('printPageStyle');
    if (!style) {
      style = document.createElement('style');
      style.id = 'printPageStyle';
      document.head.appendChild(style);
    }
    style.textContent = '@page { size: ' + (built.g.mode === 'roll' ? built.g.w + 'mm ' + built.g.h + 'mm' : 'A4 portrait') + '; margin: 0; }';
    document.body.classList.add('is-printing-labels');
    window.addEventListener('afterprint', function () {
      document.body.classList.remove('is-printing-labels');
      area.innerHTML = '';
      style.textContent = '';
    }, { once: true });
    window.print();
    return built.pages.length;
  }

  window.MPBarcode = {
    encode: encode,
    bars: bars,
    svg: svg,
    PRESETS: PRESETS,
    settings: settings,
    saveSettings: saveSettings,
    geometry: geometry,
    presetOptions: presetOptions,
    dpiOptions: dpiOptions,
    weak: weak,
    priceText: priceText,
    expand: expand,
    pageCount: pageCount,
    preview: preview,
    print: print
  };
})();
