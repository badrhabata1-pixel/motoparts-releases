/*
 * صفحة طباعة الملصقات: قائمة أصناف بعدد نسخ لكل صنف، إعدادات الورق، معاينة بالمقاس الحقيقي، وطباعة.
 * تُفتح من المخزون (?q=&filter= أو ?ids=) أو من نتيجة الاستيراد (?from=&to=&copies=stock).
 * البحث والتصفية يحددان مجموعة أصناف يضيفها زر "إضافة الكل" دفعة واحدة، حتى كل المخزون.
 * لتبقى الصفحة خفيفة على الجهاز القديم: القائمة الطويلة تُرسم على دفعات صغيرة، وتغيير النسخ يعدّل الخانات
 * في مكانها دون إعادة رسم، والمعاينة لأول الملصقات فقط، والمهمة الكبيرة تُطبع على دفعات.
 */
(function () {
  'use strict';

  var MP = window.MP, B = window.MPBarcode;
  var M = MP.money, h = MP.escapeHtml;
  function $(id) { return document.getElementById(id); }

  var PRINT_BATCH = 1000;           // ملصقات مهمة الطباعة الواحدة: آلاف الصفحات تثقل المتصفح على جهاز قديم
  var ROW_CHUNK = 150;              // صفوف القائمة في كل دفعة رسم
  var PICK_SHOWN = 40;              // نتائج البحث المعروضة للإضافة الفردية
  var url = new URLSearchParams(location.search);
  var form = $('labelSettings');
  var s = B.settings();
  var state = {
    items: [],                       // {id, barcode, name, sell_price, stock, copies}
    byId: {},
    copyMode: url.get('copies') === 'stock' ? 'stock' : (MP.store.get('mp_label_copy_mode', 'one') || 'one'),
    fixed: 2,
    batch: 0,                        // دفعة الطباعة المختارة عندما تزيد الملصقات عن PRINT_BATCH
    batchKey: ''
  };

  /* ── الإعدادات ─────────────────────────────────────────────────────── */

  form.elements.preset.innerHTML = B.presetOptions(s.preset);
  form.elements.dpi.innerHTML = B.dpiOptions(s.dpi);
  form.elements.w.value = s.w;
  form.elements.h.value = s.h;
  form.elements.showName.checked = s.showName;
  form.elements.showPrice.checked = s.showPrice;
  form.elements.showCode.checked = s.showCode;
  form.elements.offsetX.value = s.offsetX;
  form.elements.offsetY.value = s.offsetY;
  form.elements.copyMode.value = state.copyMode;

  function readSettings() {
    var f = form.elements;
    s = Object.assign(s, {
      preset: f.preset.value,
      dpi: Number(f.dpi.value) || 203,
      w: f.w.value, h: f.h.value,
      showName: f.showName.checked, showPrice: f.showPrice.checked, showCode: f.showCode.checked,
      offsetX: f.offsetX.value || 0, offsetY: f.offsetY.value || 0
    });
    B.saveSettings(s);
    form.querySelector('[data-custom-size]').hidden = !B.PRESETS[s.preset].custom;
  }

  function copiesFor(item) {
    if (state.copyMode === 'stock') return Math.max(0, Math.ceil((M.toHundredths(item.stock) || 0) / 100));
    if (state.copyMode === 'fixed') return state.fixed;
    return 1;
  }

  function applyCopyMode() {
    state.copyMode = form.elements.copyMode.value || 'one';
    state.fixed = Math.max(1, Math.min(500, parseInt(MP.normalizeDigits(form.elements.fixedCopies.value), 10) || 1));
    form.elements.fixedCopies.hidden = state.copyMode !== 'fixed';
    MP.store.set('mp_label_copy_mode', state.copyMode);
    state.items.forEach(function (item) { item.copies = copiesFor(item); });
    syncCopyInputs();
  }

  form.addEventListener('submit', function (e) { e.preventDefault(); });
  form.addEventListener('change', function (e) {
    if (e.target.id === 'printBatch') return;
    if (e.target.name === 'copyMode' || e.target.name === 'fixedCopies') applyCopyMode();
    readSettings();
    refresh();
  });
  form.addEventListener('input', MP.debounce(function (e) {
    if (e.target.id === 'printBatch') return;
    if (e.target.name === 'fixedCopies') applyCopyMode();
    readSettings();
    refresh();
  }, 300));

  /* ── قائمة الطباعة ─────────────────────────────────────────────────── */

  var list = $('labelList');
  var EMPTY_ROW = '<tr><td colspan="6" class="empty">لم تُختر أصناف بعد. ابحث عن صنف أو امسح باركوده، أو أضف كل الأصناف بالزر أعلاه.</td></tr>';
  var rendered = 0;                 // صفوف القائمة المرسومة فعلاً، بالترتيب نفسه في state.items
  var renderToken = 0;

  function rowHtml(item) {
    var price = M.toHundredths(item.sell_price) || 0;
    return '<tr data-id="' + item.id + '">' +
      '<td class="mono">' + h(item.barcode) + '</td>' +
      '<td>' + h(item.name) + '</td>' +
      '<td class="num">' + (price ? M.fmt(price, true) : '<span class="badge badge--warn">بلا سعر</span>') + '</td>' +
      '<td class="num">' + M.fmtQty(M.toHundredths(item.stock) || 0) + '</td>' +
      '<td class="num"><input class="input copies-input" inputmode="numeric" value="' + item.copies + '" aria-label="عدد النسخ"></td>' +
      '<td><button class="icon-btn icon-btn--danger" type="button" data-remove title="إزالة من القائمة"><svg class="icon"><use href="#i-x"/></svg></button></td>' +
      '</tr>';
  }

  /**
   * يرسم ما لم يُرسم بعد: أول دفعة فوراً والباقي في مهام صغيرة متتالية، فإضافة كل المخزون
   * لا تجمد الصفحة ولا تؤخر الكتابة أو المسح. كل استدعاء جديد يكمل من حيث توقف السابق.
   */
  function drawRows() {
    var token = ++renderToken;
    if (!state.items.length) {
      list.innerHTML = EMPTY_ROW;
      rendered = 0;
      return;
    }
    if (rendered === 0) list.innerHTML = '';
    (function step() {
      if (token !== renderToken) return;
      var end = Math.min(rendered + ROW_CHUNK, state.items.length);
      list.insertAdjacentHTML('beforeend', state.items.slice(rendered, end).map(rowHtml).join(''));
      rendered = end;
      if (rendered < state.items.length) setTimeout(step, 0);
    })();
  }

  // تغيير طريقة النسخ يعدّل الخانات المرسومة في مكانها؛ ما لم يُرسم بعد يُرسم بالقيمة الجديدة.
  function syncCopyInputs() {
    Array.prototype.forEach.call(list.querySelectorAll('tr[data-id]'), function (tr) {
      tr.querySelector('.copies-input').value = state.byId[tr.dataset.id].copies;
    });
  }

  function addItems(items) {
    var added = 0;
    items.forEach(function (p) {
      if (state.byId[p.id]) return;
      var item = { id: p.id, barcode: p.barcode, name: p.name, sell_price: p.sell_price, stock: p.stock, copies: 0 };
      item.copies = copiesFor(item);
      state.byId[p.id] = item;
      state.items.push(item);
      added++;
    });
    if (added) {
      drawRows();
      refresh();
    }
    return added;
  }

  // كل تعديل يُحفظ فوراً؛ المعاينة وحدها تنتظر هدوء الكتابة (تأخير مشترك كان سيُسقط تعديل صف إذا عُدّل صف آخر بعده بسرعة).
  var refreshSoon = MP.debounce(function () { refresh(); }, 300);
  list.addEventListener('input', function (e) {
    if (!e.target.classList.contains('copies-input')) return;
    var item = state.byId[e.target.closest('tr').dataset.id];
    item.copies = Math.max(0, Math.min(500, parseInt(MP.normalizeDigits(e.target.value), 10) || 0));
    refreshSoon();
  });

  list.addEventListener('click', function (e) {
    if (!e.target.closest('[data-remove]')) return;
    var tr = e.target.closest('tr'), item = state.byId[tr.dataset.id];
    state.items.splice(state.items.indexOf(item), 1);
    delete state.byId[item.id];
    tr.parentNode.removeChild(tr);
    rendered--;
    if (!state.items.length) drawRows();
    refresh();
    if (!results.hidden && browse.items) showResults();
  });

  document.querySelector('[data-action="clear-list"]').addEventListener('click', function () {
    state.items = [];
    state.byId = {};
    rendered = 0;
    drawRows();
    refresh();
    if (!results.hidden && browse.items) showResults();
  });

  /* ── اختيار الأصناف: بحث وتصفية، وإضافة صنف واحد أو كل المطابق ─────── */

  var pick = $('pickSearch'), filterSel = $('pickFilter'), results = $('pickResults');
  var bulkBtn = document.querySelector('[data-action="add-all"]');
  // المجموعة المطابقة للبحث والتصفية الحاليين. لكل المخزون بلا بحث يُجلب العدد فقط، والأصناف عند الضغط.
  var browse = { ctrl: null, items: null, count: null, truncated: false };

  function wholeStock() {
    return !pick.value.trim() && filterSel.value === 'all';
  }

  function updateBulk(loading) {
    var all = wholeStock(), q = pick.value.trim();
    bulkBtn.querySelector('[data-bulk-label]').textContent = all ? 'إضافة كل بضاعة المخزن للطباعة 📦' : 'إضافة كل الأصناف المطابقة للطباعة 📦';
    bulkBtn.querySelector('[data-bulk-count]').textContent = loading || browse.count === null ? '…'
      : browse.count.toLocaleString('en-US') + (browse.truncated ? '+' : '') + ' صنف';
    bulkBtn.disabled = !!loading || !browse.count;
    $('bulkScope').textContent = all ? 'كل أصناف المخزن'
      : [filterSel.value !== 'all' ? 'التصفية: ' + filterSel.options[filterSel.selectedIndex].text : '',
         q ? 'البحث: «' + q + '»' : ''].filter(Boolean).join(' — ');
  }

  function browseLoad() {
    var q = pick.value.trim(), filter = filterSel.value, all = wholeStock();
    if (browse.ctrl) browse.ctrl.abort();
    browse.ctrl = new AbortController();
    browse.items = null;
    browse.count = null;
    browse.truncated = false;
    updateBulk(true);
    MP.api.get('api/labels.php', all ? { filter: 'all', count: 1 } : { q: q, filter: filter },
      { signal: browse.ctrl.signal, timeout: 60000 }).then(function (res) {
      if (all) {
        browse.count = res.count;
        results.hidden = true;
      } else {
        browse.items = res.items;
        browse.count = res.items.length;
        browse.truncated = res.truncated;
        showResults();
      }
      updateBulk(false);
    }, function (err) {
      if (err.code === 'aborted') return;
      MP.toast(err.message, 'error');
      updateBulk(false);
    });
  }

  function showResults() {
    var items = browse.items, shown = items.slice(0, PICK_SHOWN);
    if (!items.length) {
      results.innerHTML = '<p class="muted small">' + (filterSel.value === 'fast' && !pick.value.trim()
        ? 'لا توجد مبيعات في آخر 30 يوماً.' : 'لا توجد أصناف مطابقة.') + '</p>';
    } else {
      results.innerHTML = '<p class="muted small pick-count">' + items.length.toLocaleString('en-US') + (browse.truncated ? '+' : '') + ' صنف مطابق' +
        (items.length > shown.length ? ' — تُعرض أول ' + shown.length + '، والزر أعلاه يضيفها كلها' : '') + '</p>' +
        '<div class="pick-list">' + shown.map(function (p, i) {
          var inList = !!state.byId[p.id];
          return '<div class="pick-item"><span><span class="mono">' + h(p.barcode) + '</span> — ' + h(p.name) + '</span>' +
            '<button class="btn btn--sm" type="button" data-pick="' + i + '"' + (inList ? ' disabled>في القائمة' : '>إضافة') + '</button></div>';
        }).join('') + '</div>';
    }
    results.hidden = false;
  }

  bulkBtn.addEventListener('click', function () {
    var ready = browse.items ? Promise.resolve({ items: browse.items, truncated: browse.truncated })
      : MP.api.get('api/labels.php', { filter: 'all' }, { timeout: 60000 });
    bulkBtn.disabled = true;
    ready.then(function (res) {
      var added = addItems(res.items), already = res.items.length - added;
      MP.toast(added
        ? 'أُضيف ' + added.toLocaleString('en-US') + ' صنف إلى قائمة الطباعة' + (already ? ' (' + already + ' كانت في القائمة)' : '') + '.'
        : 'كل هذه الأصناف في القائمة بالفعل.', added ? 'success' : 'info');
      if (res.truncated) MP.toast('أُضيف أول ' + res.items.length + ' صنف فقط. ضيّق البحث أو التصفية للباقي.', 'warn', { duration: 8000 });
      if (!results.hidden && browse.items) showResults();
    }, function (err) {
      MP.toast(err.message, 'error');
    }).then(function () { bulkBtn.disabled = !browse.count; });
  });

  pick.addEventListener('input', MP.debounce(browseLoad, 250));
  filterSel.addEventListener('change', browseLoad);
  // ماسح الباركود: Enter على رقم يطابق باركوداً يضيف الصنف مباشرة.
  pick.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    var code = MP.normalizeDigits(pick.value).trim();
    if (!code) return;
    MP.api.get('api/search_product.php', { barcode: code }).then(function (res) {
      addItems([res.product]);
      MP.beep(true);
      pick.value = '';
      browseLoad();
    }, function () {
      browseLoad();
    });
  });

  results.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-pick]');
    if (!btn || !browse.items) return;
    addItems([browse.items[Number(btn.dataset.pick)]]);
    btn.disabled = true;
    btn.textContent = 'في القائمة';
  });

  /* ── المعاينة والطباعة ─────────────────────────────────────────────── */

  var preview = $('labelPreview'), printBtn = document.querySelector('[data-action="print"]'), batchSel = $('printBatch');

  function labels() {
    return B.expand(state.items);
  }

  // دفعة الطباعة بعدد صفحات كامل: ورق A4 لا يُقسم في منتصف الورقة.
  function batchSize() {
    var g = B.geometry(s);
    return g.mode === 'roll' ? PRINT_BATCH : Math.max(1, Math.floor(PRINT_BATCH / g.perPage)) * g.perPage;
  }

  function updateBatches(total) {
    var size = batchSize(), count = Math.ceil(total / size), key = total + '|' + size;
    if (key !== state.batchKey) {
      state.batchKey = key;
      state.batch = 0;
      var options = '';
      for (var i = 0; i < count; i++) {
        options += '<option value="' + i + '">الدفعة ' + (i + 1) + ' من ' + count + ': الملصقات ' +
          (i * size + 1) + '–' + Math.min(total, (i + 1) * size) + '</option>';
      }
      batchSel.innerHTML = options;
    }
    batchSel.value = String(state.batch);
    $('batchField').hidden = count < 2;
    printBtn.querySelector('[data-print-label]').textContent = count < 2 ? 'طباعة' : 'طباعة الدفعة ' + (state.batch + 1) + ' من ' + count;
    return { size: size, count: count };
  }

  batchSel.addEventListener('change', function () {
    state.batch = Number(batchSel.value) || 0;
    updateBatches(labels().length);
  });

  function refresh() {
    var all = labels();
    var g = B.geometry(s);
    var shown = B.preview(preview, all, s);
    var batches = updateBatches(all.length);
    $('previewNote').textContent = shown.total > shown.shown ? 'تُعرض أول ' + shown.shown + ' من ' + shown.total.toLocaleString('en-US') + ' ملصق' : '';
    $('listSummary').textContent = state.items.length ? state.items.length.toLocaleString('en-US') + ' صنف' : '';
    $('printSummary').textContent = !all.length ? ''
      : g.mode === 'roll' ? 'المجموع: ' + all.length + ' ملصق من الرول'
      : 'المجموع: ' + all.length + ' ملصق على ' + B.pageCount(all.length, s) + ' ورقة A4';
    var zero = state.items.filter(function (i) { return i.copies > 0 && !(M.toHundredths(i.sell_price) > 0); }).length;
    var warnings = '';
    var thin = B.weak(state.items.filter(function (i) { return i.copies > 0; }), s);
    if (thin.length) {
      warnings += '<div class="alert alert--danger">خطوط ' + thin.length + ' باركود ستكون أرفع من نقطتي طباعة على هذا المقاس، وقد لا يقرؤها الماسح ' +
        '(مثل ' + h(thin[0].barcode) + '). اختر مقاساً أعرض أو دقة طابعة أعلى.</div>';
    }
    if (s.showPrice && zero) warnings += '<div class="alert alert--warn">' + zero + ' صنف بلا سعر بيع: ستُطبع ملصقاته بدون سعر.</div>';
    if (batches.count > 1) {
      warnings += '<div class="alert alert--info">' + all.length.toLocaleString('en-US') + ' ملصق تُطبع على ' + batches.count +
        ' دفعات (حتى ' + batches.size + ' في كل مرة) حتى لا يثقل الجهاز. بعد كل دفعة تُختار التالية تلقائياً.</div>';
    }
    $('labelWarnings').innerHTML = warnings;
  }

  printBtn.addEventListener('click', function () {
    var all = labels();
    if (!all.length) {
      MP.toast('لا توجد ملصقات للطباعة: أضف أصنافاً أو زِد عدد النسخ.', 'warn');
      return;
    }
    var batches = updateBatches(all.length), start = state.batch * batches.size;
    B.print(batches.count > 1 ? all.slice(start, start + batches.size) : all, s);
    if (batches.count > 1) {
      var done = state.batch + 1;
      state.batch = done % batches.count;
      updateBatches(all.length);
      MP.toast(done < batches.count
        ? 'أُرسلت الدفعة ' + done + ' من ' + batches.count + '. اضغط "طباعة" للدفعة التالية.'
        : 'أُرسلت الدفعة الأخيرة (' + batches.count + ' من ' + batches.count + ').', 'info', { duration: 8000 });
    }
  });

  window.addEventListener('resize', MP.debounce(refresh, 300));

  /* ── تحميل الأصناف من الرابط ───────────────────────────────────────── */

  readSettings();
  applyCopyMode();
  browseLoad();
  var params = null;
  if (url.get('ids')) params = { ids: url.get('ids') };
  else if (url.get('from') && url.get('to')) params = { from: url.get('from'), to: url.get('to') };
  else if (url.has('q') || url.has('filter')) params = { q: url.get('q') || '', filter: url.get('filter') || 'all' };

  if (params) {
    MP.api.get('api/labels.php', params, { timeout: 60000 }).then(function (res) {
      addItems(res.items);
      if (res.truncated) MP.toast('أُضيف أول ' + res.max + ' صنف فقط. اطبع على دفعات.', 'warn', { duration: 8000 });
      if (!res.items.length) MP.toast('لا توجد أصناف مطابقة.', 'info');
    }, function (err) { MP.toast(err.message, 'error'); });
  } else {
    refresh();
    pick.focus();
  }
})();
