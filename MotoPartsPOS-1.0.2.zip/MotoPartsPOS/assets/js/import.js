/*
 * شاشة الاستيراد: معاينة قبل الحفظ دائماً. لا يُدرج صنف ولا يتغير رصيد أو سعر قبل أن يراجع المستخدم
 * الأعمدة المكتشفة، والأصناف المتطابقة بالاسم مع المخزن (الحالي بجوار الوارد) ويختار لكل منها الإجراء، ثم يؤكد.
 */
(function () {
  'use strict';

  var MP = window.MP;
  var M = MP.money, h = MP.escapeHtml;
  function $(id) { return document.getElementById(id); }

  var REASONS = { empty_name: 'بلا اسم صنف', total_row: 'صف إجمالي', header_repeat: 'عنوان مكرر' };

  function busy(container, on) {
    Array.prototype.forEach.call(container.querySelectorAll('button, input, select'), function (el) { el.disabled = on; });
  }

  function num(n) { return Number(n || 0).toLocaleString('en-US'); }

  function columnOptions(columns, selected, allowNone) {
    var html = allowNone ? '<option value="">— لا يوجد —</option>' : '';
    columns.forEach(function (c) {
      html += '<option value="' + c.index + '"' + (c.index === selected ? ' selected' : '') + '>' +
        c.letter + (c.header ? ' — ' + h(c.header) : '') + '</option>';
    });
    return html;
  }

  function selectedValue(select) {
    return select.value === '' ? null : Number(select.value);
  }

  /* ── استيراد الأصناف: جديد أو متطابق بالاسم مع المخزن ─────────────── */

  var importForm = $('importForm'), importPreview = $('importPreview'), importResult = $('importResult');
  var ACTIONS = [['add', 'زيادة الكمية وتحديث السعر'], ['new', 'إضافة كصنف مستقل بباركود جديد'], ['skip', 'تخطي الصف']];
  var MATCH_CHUNK = 150;            // صفوف المقارنة في كل دفعة رسم: ملف كامل متطابق لا يجمّد الصفحة
  // decisions: اختيار كل صف متطابق {action، target}، بمفتاح "ورقة:صف". bulk: الإجراء الافتراضي للصفوف الجديدة.
  var imp = { token: null, fileName: '', sheets: [], decisions: {}, bulk: 'add', byKey: {}, drawToken: 0 };

  function qtyText(v) { return M.fmtQty(M.toHundredths(v) || 0); }
  function priceText(v) { return M.fmt(M.toHundredths(v) || 0, true); }
  function included() { return imp.sheets.filter(function (s) { return s.include; }); }

  // كل صف متطابق له اختيار: الإجراء العام، والصنف الأول بالاسم نفسه. اختيار سابق يبقى ما دام صنفه بين المتطابقات.
  function syncDecisions() {
    imp.byKey = {};
    imp.sheets.forEach(function (s) {
      s.matched.forEach(function (m) {
        imp.byKey[m.key] = { m: m, sheet: s };
        var d = imp.decisions[m.key];
        var ids = m.matches.map(function (x) { return x.id; });
        if (!d || ids.indexOf(d.target) === -1) imp.decisions[m.key] = { action: d ? d.action : imp.bulk, target: ids[0] };
      });
    });
  }

  function counts() {
    var c = { fresh: 0, matched: 0, add: 0, new: 0, skip: 0 };
    included().forEach(function (s) {
      c.fresh += s.new_count;
      s.matched.forEach(function (m) {
        c.matched++;
        c[imp.decisions[m.key].action]++;
      });
    });
    return c;
  }

  importForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var fd = new FormData(importForm);
    fd.set('action', 'preview');
    busy(importForm, true);
    importPreview.hidden = true;
    importResult.hidden = true;
    MP.api.upload('api/import_excel.php', fd).then(function (res) {
      imp.token = res.token;
      imp.fileName = res.file_name;
      imp.decisions = {};
      imp.sheets = res.sheets.map(function (s) {
        s.include = !s.hidden && s.stats.ok > 0;
        return s;
      });
      syncDecisions();
      renderImport();
    }, function (err) {
      MP.toast(err.message, 'error');
    }).then(function () { busy(importForm, false); });
  });

  function skippedList(rows) {
    if (!rows.length) return '';
    return '<details><summary>عينة من الصفوف المتخطاة</summary><ul class="small">' + rows.map(function (r) {
      return '<li>الصف ' + r.row + ' — ' + h(REASONS[r.reason] || r.reason) + ': <span class="muted">' + h(r.text) + '</span></li>';
    }).join('') + '</ul></details>';
  }

  // فاتورة PDF: الصف الافتراضي 1 عناوين، فالبند رقم (الصف − 1) = رقم "م" في الفاتورة.
  function rowLabel(sheet, row) {
    return sheet.pdf ? 'البند ' + (row - 1) : 'الصف ' + row;
  }

  /** ملخص فاتورة PDF وفحوص اكتمالها كما قرأها الخادم. */
  function pdfHtml(p) {
    if (!p) return '';
    var c = p.checks, bad = c.arithmetic_mismatches.length;
    var checks = [
      [c.seq_contiguous, c.seq_contiguous ? 'تسلسل م متصل من 1 إلى ' + num(p.items) : 'تسلسل م غير متصل'],
      [c.qty_sum_matches_footer, 'مجموع الكميات ' + qtyText(c.qty_sum) + (c.footer_qty !== null ? (c.qty_sum_matches_footer ? ' = ' : ' ≠ ') + 'صف الإجمالي ' + qtyText(c.footer_qty) : ' (لا يوجد صف إجمالي)')],
      [!bad, bad ? num(bad) + ' بند لا تساوي فيه الكمية × السعر إجمالي السطر' : 'الكمية × السعر = إجمالي السطر في كل البنود']
    ];
    return '<div class="pdf-info">' +
      '<div>📄 <strong>فاتورة PDF' + (p.invoice_code ? ' رقم ' + h(p.invoice_code) : '') + '</strong>' + (p.invoice_date ? ' بتاريخ ' + h(p.invoice_date) : '') +
        ' — ' + num(p.pages) + ' صفحة، ' + num(p.items) + ' بنداً. استُبعد ' + num(p.skipped) + ' سطراً من الترويسة والذيل (الإجمالي، الرصيد السابق...).</div>' +
      '<ul class="pdf-checks">' + checks.map(function (x) {
        return '<li class="' + (x[0] ? 'is-ok' : 'is-bad') + '">' + (x[0] ? '✓ ' : '✗ ') + h(x[1]) + '</li>';
      }).join('') + '</ul>' +
      (p.problems.length ? '<div class="alert alert--warn">راجع البنود قبل التنفيذ:<ul>' + p.problems.slice(0, 10).map(function (x) { return '<li>' + h(x) + '</li>'; }).join('') + '</ul></div>' : '') +
      '</div>';
  }

  function sheetHtml(s) {
    var st = s.stats;
    var skipped = st.empty_name + st.total_row + st.header_repeat;
    var reasons = [];
    Object.keys(REASONS).forEach(function (k) { if (st[k]) reasons.push(st[k] + ' ' + REASONS[k]); });
    var notes = [];
    if (st.qty_invalid) notes.push(st.qty_invalid + ' كمية غير رقمية ستُسجَّل 0');
    if (st.qty_empty) notes.push(st.qty_empty + ' كمية فارغة ستُسجَّل 0');
    if (st.price_invalid) notes.push(st.price_invalid + ' سعر غير صالح سيُعامل كخلية فارغة');
    if (st.truncated) notes.push(st.truncated + ' اسم أطول من 255 حرفاً سيُقص');
    if (s.map.sell === null) notes.push('لا يوجد عمود سعر بيع: الأصناف الجديدة بسعر 0.00 والمتطابقة بسعرها الحالي');
    return '<div class="sheet-block" data-sheet="' + s.index + '">' +
      '<div class="sheet-block__head">' +
        '<label class="check"><input type="checkbox" data-role="include"' + (s.include ? ' checked' : '') + '> <strong>' + h(s.name) + '</strong></label>' +
        (s.hidden ? '<span class="badge badge--muted">ورقة مخفية</span>' : '') +
        '<span class="badge badge--ok">✨ ' + num(s.new_count) + ' جديد</span>' +
        (s.matched.length ? '<span class="badge badge--warn">⚠️ ' + num(s.matched.length) + ' متطابق بالاسم</span>' : '') +
        (skipped ? '<span class="badge badge--muted">' + num(skipped) + ' متخطى</span>' : '') +
      '</div>' + pdfHtml(s.pdf) +
      '<div class="form-grid form-grid--3">' +
        '<label class="field"><span class="field__label">عمود اسم الصنف</span><select class="input select" data-role="name">' + columnOptions(s.columns, s.map.name, false) + '</select></label>' +
        '<label class="field"><span class="field__label">عمود الكمية</span><select class="input select" data-role="qty">' + columnOptions(s.columns, s.map.qty, true) + '</select></label>' +
        '<label class="field"><span class="field__label">عمود سعر البيع</span><select class="input select" data-role="sell">' + columnOptions(s.columns, s.map.sell, true) + '</select></label>' +
        '<label class="field"><span class="field__label">عمود سعر الشراء (اختياري)</span><select class="input select" data-role="buy">' + columnOptions(s.columns, s.map.buy, true) + '</select></label>' +
        '<label class="field"><span class="field__label">رقم صف العناوين</span><input class="input" data-role="header_row" inputmode="numeric" value="' + (s.header_row || '') + '" placeholder="لا يوجد"></label>' +
      '</div>' +
      '<p class="muted small">' + (s.header_row ? 'البيانات تبدأ بعد الصف ' + s.header_row + '.' : 'لم يُعثر على صف عناوين، فكل الصفوف تُقرأ بيانات.') +
        (reasons.length ? ' المتخطى: ' + h(reasons.join('، ')) + '.' : '') + (notes.length ? ' ' + h(notes.join('، ')) + '.' : '') + '</p>' +
      skippedList(s.skipped_sample) +
      '</div>';
  }

  function facts(list) {
    return '<dl class="match__facts">' + list.map(function (f) {
      return '<dt>' + f[0] + '</dt><dd' + (f[2] ? ' class="' + f[2] + '"' : '') + '>' + f[1] + '</dd>';
    }).join('') + '</dl>';
  }

  function matchResult(m, d, cur) {
    if (d.action === 'skip') return 'لن يُستورد هذا الصف.';
    if (d.action === 'new') {
      return 'صنف جديد بباركود جديد بالاسم نفسه: الكمية ' + qtyText(m.qty) + (m.sell !== null ? '، سعر البيع ' + priceText(m.sell) : '، سعر البيع 0.00') + '.';
    }
    var after = (M.toHundredths(cur.stock) || 0) + (M.toHundredths(m.qty) || 0);
    var priceChange = m.sell !== null && m.sell !== cur.sell_price
      ? 'سعر البيع ' + priceText(cur.sell_price) + ' ← <strong>' + priceText(m.sell) + '</strong>' : 'سعر البيع بلا تغيير (' + priceText(cur.sell_price) + ')';
    return 'بعد الاستيراد: الكمية ' + qtyText(cur.stock) + ' ← <strong>' + M.fmtQty(after) + '</strong> · ' + priceChange + '.';
  }

  function matchHtml(m, sheet) {
    var d = imp.decisions[m.key];
    var cur = m.matches.filter(function (x) { return x.id === d.target; })[0] || m.matches[0];
    var pick = m.matches.length > 1
      ? '<label class="field match__pick"><span class="field__label">' + m.matches.length + ' أصناف في المخزن بالاسم نفسه — أضف إلى:</span>' +
        '<select class="input select" data-role="target">' + m.matches.map(function (x) {
          return '<option value="' + x.id + '"' + (x.id === cur.id ? ' selected' : '') + '>' + h(x.barcode) + ' — رصيد ' + qtyText(x.stock) + ' — ' + priceText(x.sell_price) + '</option>';
        }).join('') + '</select></label>'
      : '';
    var group = 'act-' + m.key.replace(/\W/g, '-');
    return '<article class="match match--' + d.action + '" data-key="' + h(m.key) + '">' +
      '<div class="match__head"><span aria-hidden="true">⚠️</span><strong class="match__name">' + h(m.name) + '</strong>' +
        '<span class="muted small">' + h(sheet.name) + ' — ' + rowLabel(sheet, m.row) + '</span></div>' +
      '<div class="match__cols">' +
        '<section class="match__box"><h4 class="match__title">📦 الصنف الحالي في المخزن</h4>' + pick +
          facts([['الباركود', h(cur.barcode), 'mono'], ['الكمية المتوفرة حالياً', qtyText(cur.stock), 'num'], ['سعر البيع الحالي', priceText(cur.sell_price), 'num']]) + '</section>' +
        '<section class="match__box match__box--file"><h4 class="match__title">📄 الوارد الجديد في الملف</h4>' +
          facts([['الكمية الواردة', qtyText(m.qty), 'num'], ['سعر البيع الوارد', m.sell !== null ? priceText(m.sell) : '<span class="muted">فارغ — يبقى الحالي</span>', 'num']]
            .concat(m.buy !== null ? [['سعر الشراء الوارد', priceText(m.buy), 'num']] : [])) + '</section>' +
      '</div>' +
      '<div class="match__foot">' +
        '<div class="segmented segmented--inline match__actions" role="radiogroup" aria-label="الإجراء">' + ACTIONS.map(function (a) {
          return '<label><input type="radio" name="' + group + '" value="' + a[0] + '" data-role="action"' + (d.action === a[0] ? ' checked' : '') + '> <span>' + a[1] + '</span></label>';
        }).join('') + '</div>' +
        '<span class="match__result">' + matchResult(m, d, cur) + '</span>' +
      '</div></article>';
  }

  // قائمة المقارنة تُرسم على دفعات: أول دفعة فوراً والباقي في مهام صغيرة متتالية.
  function drawMatches() {
    var list = importPreview.querySelector('.match-list');
    if (!list) return;
    var items = [];
    included().forEach(function (s) { s.matched.forEach(function (m) { items.push([m, s]); }); });
    var token = ++imp.drawToken, i = 0;
    list.innerHTML = '';
    (function step() {
      if (token !== imp.drawToken) return;
      var end = Math.min(i + MATCH_CHUNK, items.length), html = '';
      for (; i < end; i++) html += matchHtml(items[i][0], items[i][1]);
      list.insertAdjacentHTML('beforeend', html);
      if (i < items.length) setTimeout(step, 0);
    })();
  }

  function newRowsHtml(c) {
    if (!c.fresh) return '';
    var rows = [];
    included().forEach(function (s) {
      rows = rows.concat(s.new_sample.map(function (r) { return Object.assign({ label: s.pdf ? r.row - 1 : r.row }, r); }));
    });
    var shown = rows.slice(0, 100);
    var pdfOnly = included().every(function (s) { return !!s.pdf; });
    return '<section class="stack-sm"><h3 class="import-heading">أصناف جديدة ✨ (' + num(c.fresh) + ')</h3>' +
      '<p class="muted small">لا يوجد في المخزن صنف نشط بالاسم نفسه: كل صف صنف جديد بباركود متسلسل وكميته وسعره.</p>' +
      '<div class="table-wrap table-wrap--short"><table class="grid grid--compact"><thead><tr><th>' + (pdfOnly ? 'البند' : 'الصف') + '</th><th>الصنف</th><th class="num">الكمية</th><th class="num">سعر البيع</th><th class="num">سعر الشراء</th></tr></thead><tbody>' +
      shown.map(function (r) {
        return '<tr><td>' + r.label + '</td><td>' + h(r.name) + '</td><td class="num">' + qtyText(r.qty) + '</td>' +
          '<td class="num">' + (r.sell !== null ? priceText(r.sell) : '<span class="muted">0.00</span>') + '</td>' +
          '<td class="num">' + (r.buy !== null ? priceText(r.buy) : '<span class="muted">0.00</span>') + '</td></tr>';
      }).join('') + '</tbody></table></div>' +
      (c.fresh > shown.length ? '<p class="muted small">تُعرض أول ' + shown.length + ' من ' + num(c.fresh) + ' صنف جديد.</p>' : '') +
      '</section>';
  }

  function commitLabel(c) {
    var parts = [];
    if (c.fresh + c.new) parts.push('إضافة ' + num(c.fresh + c.new) + ' صنف جديد');
    if (c.add) parts.push('زيادة كمية ' + num(c.add));
    return parts.length ? 'تنفيذ: ' + parts.join(' و') : 'لا شيء للاستيراد';
  }

  function summaryHtml(c) {
    return '<div class="import-summary">' +
      '<span class="badge badge--ok">أصناف جديدة ✨ ' + num(c.fresh) + '</span>' +
      '<span class="badge badge--warn">أصناف متطابقة بالاسم ⚠️ ' + num(c.matched) + '</span>' +
      (c.matched ? '<span class="muted small" data-role="choices">' + choicesText(c) + '</span>' : '') +
      '</div>';
  }

  function choicesText(c) {
    return 'المتطابقة: ' + num(c.add) + ' زيادة كمية، ' + num(c.new) + ' صنف مستقل، ' + num(c.skip) + ' تخطٍّ.';
  }

  function renderImport() {
    var c = counts();
    importPreview.innerHTML =
      '<div class="alert alert--info">الملف <strong>' + h(imp.fileName) + '</strong>: ' + imp.sheets.length + ' ورقة. ' +
      'راجع الأعمدة، ثم الأصناف المتطابقة بالاسم مع المخزن واختر لكل منها الإجراء.</div>' +
      imp.sheets.map(sheetHtml).join('') +
      summaryHtml(c) +
      (c.matched
        ? '<section class="match-section"><h3 class="import-heading">أصناف متطابقة بالاسم ⚠️ (' + num(c.matched) + ')</h3>' +
          '<div class="match-toolbar"><label class="field"><span class="field__label">إجراء واحد لكل المتطابقات</span>' +
          '<select class="input select" data-role="bulk">' + ACTIONS.map(function (a) {
            return '<option value="' + a[0] + '"' + (a[0] === imp.bulk ? ' selected' : '') + '>' + a[1] + '</option>';
          }).join('') + '</select></label>' +
          '<button class="btn" type="button" data-role="apply-bulk">تطبيق على كل المتطابقات</button></div>' +
          '<div class="match-list"></div></section>'
        : '') +
      newRowsHtml(c) +
      '<div class="btn-row"><button class="btn btn--primary btn--lg" type="button" data-role="commit"' + (c.fresh + c.new + c.add ? '' : ' disabled') + '>' + commitLabel(c) + '</button>' +
      '<button class="btn btn--ghost" type="button" data-role="cancel">إلغاء</button></div>';
    importPreview.hidden = false;
    $('importCard').classList.add('card--wide');
    drawMatches();
  }

  // تغيير اختيار صف واحد: يُعاد رسم صفه فقط، ويُحدَّث الملخص وزر التنفيذ.
  function refreshCounts() {
    var c = counts();
    var choices = importPreview.querySelector('[data-role="choices"]');
    if (choices) choices.textContent = choicesText(c);
    var btn = importPreview.querySelector('[data-role="commit"]');
    btn.textContent = commitLabel(c);
    btn.disabled = !(c.fresh + c.new + c.add);
  }

  function redrawMatch(card) {
    var entry = imp.byKey[card.dataset.key];
    card.outerHTML = matchHtml(entry.m, entry.sheet);
  }

  function sheetMap(block) {
    var headerRow = block.querySelector('[data-role="header_row"]').value.trim();
    return {
      name: selectedValue(block.querySelector('[data-role="name"]')),
      qty: selectedValue(block.querySelector('[data-role="qty"]')),
      sell: selectedValue(block.querySelector('[data-role="sell"]')),
      buy: selectedValue(block.querySelector('[data-role="buy"]')),
      header_row: headerRow === '' ? null : Number(MP.normalizeDigits(headerRow)) || null
    };
  }

  importPreview.addEventListener('change', function (e) {
    var card = e.target.closest('.match');
    if (card) {
      var d = imp.decisions[card.dataset.key];
      if (e.target.dataset.role === 'action') d.action = e.target.value;
      if (e.target.dataset.role === 'target') d.target = Number(e.target.value);
      redrawMatch(card);
      refreshCounts();
      return;
    }
    if (e.target.dataset.role === 'bulk') {
      imp.bulk = e.target.value;
      return;
    }
    var block = e.target.closest('.sheet-block');
    if (!block) return;
    var index = Number(block.dataset.sheet);
    var sheet = imp.sheets.filter(function (s) { return s.index === index; })[0];
    if (e.target.dataset.role === 'include') {
      sheet.include = e.target.checked;
      renderImport();
      return;
    }
    var fd = new FormData();
    fd.set('action', 'rescan');
    fd.set('token', imp.token);
    fd.set('sheet', String(index));
    fd.set('map', JSON.stringify(sheetMap(block)));
    busy(importPreview, true);
    MP.api.upload('api/import_excel.php', fd).then(function (res) {
      res.sheet.include = sheet.include;
      imp.sheets = imp.sheets.map(function (s) { return s.index === index ? res.sheet : s; });
      syncDecisions();
      renderImport();
    }, function (err) {
      MP.toast(err.message, 'error');
      busy(importPreview, false);
    });
  });

  importPreview.addEventListener('click', function (e) {
    var role = e.target.closest('[data-role]') && e.target.closest('[data-role]').dataset.role;
    if (role === 'cancel') {
      importPreview.hidden = true;
      $('importCard').classList.remove('card--wide');
      importForm.reset();
      return;
    }
    if (role === 'apply-bulk') {
      imp.bulk = importPreview.querySelector('[data-role="bulk"]').value;
      included().forEach(function (s) {
        s.matched.forEach(function (m) { imp.decisions[m.key].action = imp.bulk; });
      });
      drawMatches();
      refreshCounts();
      return;
    }
    if (role !== 'commit') return;
    var c = counts();
    var lines = [];
    if (c.fresh) lines.push('• ' + num(c.fresh) + ' صنف جديد بباركودات متسلسلة.');
    if (c.add) lines.push('• زيادة كمية ' + num(c.add) + ' صنف موجود وتحديث سعره.');
    if (c.new) lines.push('• ' + num(c.new) + ' صنف مستقل بباركود جديد بنفس اسم صنف موجود.');
    if (c.skip) lines.push('• تخطي ' + num(c.skip) + ' صف.');
    if (!window.confirm('سيتم:\n' + lines.join('\n') + '\n\nمتابعة؟')) return;

    var decisions = {};
    included().forEach(function (s) {
      s.matched.forEach(function (m) {
        var d = imp.decisions[m.key];
        decisions[m.key] = d.action === 'add' ? { action: 'add', target: d.target } : { action: d.action };
      });
    });
    var fd = new FormData();
    fd.set('action', 'commit');
    fd.set('token', imp.token);
    fd.set('sheets', JSON.stringify(imp.sheets.map(function (s) {
      return { index: s.index, include: s.include, name: s.map.name, qty: s.map.qty, sell: s.map.sell, buy: s.map.buy, header_row: s.header_row };
    })));
    fd.set('decisions', JSON.stringify(decisions));
    fd.set('min_alert_qty', importForm.elements.min_alert_qty.value);
    fd.set('is_barcoded', importForm.elements.is_barcoded.checked ? '1' : '0');
    busy(importPreview, true);
    MP.api.upload('api/import_excel.php', fd).then(function (res) {
      importPreview.hidden = true;
      $('importCard').classList.remove('card--wide');
      importForm.reset();
      var done = [];
      if (res.inserted) {
        done.push('أُضيف ' + num(res.inserted) + ' صنف جديد' + (res.separate ? ' (منها ' + num(res.separate) + ' مستقل بنفس اسم صنف موجود)' : '') +
          '، الباركودات من <span class="mono">' + h(res.first_barcode) + '</span> إلى <span class="mono">' + h(res.last_barcode) + '</span>.');
      }
      if (res.added) done.push('زادت كمية ' + num(res.added) + ' صنف موجود' + (res.price_updated ? '، وتحدّث سعر ' + num(res.price_updated) : '') + '.');
      if (res.skipped) done.push('تُخطي ' + num(res.skipped) + ' صف متطابق.');
      importResult.innerHTML = '<div class="alert alert--ok"><strong>اكتمل الاستيراد.</strong><ul>' + done.map(function (t) { return '<li>' + t + '</li>'; }).join('') + '</ul></div>' +
        '<div class="btn-row"><a class="btn" href="index.php?page=inventory">عرض في المخزون</a>' +
        (res.inserted ? '<a class="btn btn--primary" href="index.php?page=labels&amp;from=' + encodeURIComponent(res.first_barcode) + '&amp;to=' + encodeURIComponent(res.last_barcode) + '&amp;copies=stock">' +
          'طباعة ملصقات الأصناف الجديدة (ملصق لكل قطعة)</a>' : '') +
        (res.updated_ids.length ? '<a class="btn" href="index.php?page=labels&amp;ids=' + res.updated_ids.join(',') + '">ملصقات الأصناف التي زادت كميتها</a>' : '') +
        '</div>';
      importResult.hidden = false;
      MP.toast('اكتمل الاستيراد.', 'success');
    }, function (err) {
      MP.toast(err.message, 'error', { duration: 9000 });
      busy(importPreview, false);
    });
  });

  /* ── تحديث الأسعار بالجملة ─────────────────────────────────────────── */

  var pricesForm = $('pricesForm'), pricesPreview = $('pricesPreview'), pricesResult = $('pricesResult');
  var pr = { token: null, data: null };

  pricesForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var fd = new FormData(pricesForm);
    fd.set('action', 'preview');
    busy(pricesForm, true);
    pricesPreview.hidden = true;
    pricesResult.hidden = true;
    MP.api.upload('api/bulk_update_prices.php', fd).then(function (res) {
      pr.token = res.token;
      pr.data = res;
      renderPrices();
    }, function (err) {
      MP.toast(err.message, 'error');
    }).then(function () { busy(pricesForm, false); });
  });

  function priceChange(oldV, newV) {
    if (oldV === newV) return '<span class="muted">' + M.fmt(M.toHundredths(oldV) || 0, true) + '</span>';
    return '<span class="muted">' + M.fmt(M.toHundredths(oldV) || 0, true) + '</span> ← <strong>' + M.fmt(M.toHundredths(newV) || 0, true) + '</strong>';
  }

  function renderPrices() {
    var d = pr.data, s = d.summary, map = d.map;
    var sheetSelect = d.sheets.length > 1
      ? '<label class="field"><span class="field__label">الورقة</span><select class="input select" data-role="sheet">' +
        d.sheets.map(function (sh) { return '<option value="' + sh.index + '"' + (sh.index === d.sheet ? ' selected' : '') + '>' + h(sh.name) + '</option>'; }).join('') +
        '</select></label>'
      : '';
    var issues = [];
    if (s.unmatched) issues.push(num(s.unmatched) + ' باركود غير موجود في المخزون');
    if (s.invalid) issues.push(num(s.invalid) + ' سعر غير صالح');
    if (s.duplicates) issues.push(num(s.duplicates) + ' باركود مكرر في الملف (اعتُمد آخر صف)');
    if (s.no_barcode) issues.push(num(s.no_barcode) + ' صف بلا باركود');

    var html = '<div class="alert alert--info">الملف <strong>' + h(d.file_name) + '</strong>: ' + num(s.with_price) + ' صف به سعر، ' +
      '<strong>' + num(s.changed) + ' صنف سيتغير سعره</strong>، و' + num(s.unchanged) + ' بلا تغيير.</div>';
    if (d.missing_column) html += '<div class="alert alert--danger">حدد عمود الباركود وعمود السعر الجديد.</div>';
    html += '<div class="form-grid form-grid--3">' + sheetSelect +
      '<label class="field"><span class="field__label">عمود الباركود</span><select class="input select" data-role="barcode">' + columnOptions(d.columns, map.barcode, false) + '</select></label>' +
      '<label class="field"><span class="field__label">عمود السعر الجديد</span><select class="input select" data-role="sell">' + columnOptions(d.columns, map.sell, true) + '</select></label>' +
      '<label class="field"><span class="field__label">عمود سعر الشراء الجديد</span><select class="input select" data-role="buy">' + columnOptions(d.columns, map.buy, true) + '</select></label>' +
      '</div>';
    if (issues.length) html += '<div class="alert alert--warn">' + h(issues.join('، ')) + '.</div>';
    if (d.changes_sample.length) {
      html += '<div class="table-wrap table-wrap--short"><table class="grid grid--compact"><thead><tr><th>الباركود</th><th>الصنف</th><th>سعر البيع</th><th>سعر الشراء</th></tr></thead><tbody>' +
        d.changes_sample.map(function (c) {
          return '<tr><td class="mono">' + h(c.barcode) + '</td><td>' + h(c.name) + '</td><td>' + priceChange(c.old_sell, c.new_sell) + '</td><td>' + priceChange(c.old_buy, c.new_buy) + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    }
    if (d.unmatched_sample.length) {
      html += '<details><summary>باركودات غير موجودة (' + num(s.unmatched) + ')</summary><p class="mono small">' + d.unmatched_sample.map(h).join(' · ') + '</p></details>';
    }
    if (d.invalid_sample.length) {
      html += '<details><summary>أسعار غير صالحة</summary><ul class="small">' + d.invalid_sample.map(function (r) {
        return '<li>الصف ' + r.row + ' — <span class="mono">' + h(r.barcode) + '</span>: "' + h(r.value) + '"</li>';
      }).join('') + '</ul></details>';
    }
    html += '<div class="btn-row"><button class="btn btn--primary btn--lg" type="button" data-role="commit"' + (s.changed ? '' : ' disabled') + '>تحديث أسعار ' + num(s.changed) + ' صنف</button>' +
      '<button class="btn btn--ghost" type="button" data-role="cancel">إلغاء</button></div>';
    pricesPreview.innerHTML = html;
    pricesPreview.hidden = false;
  }

  function priceRequest(action) {
    var fd = new FormData();
    var sheet = pricesPreview.querySelector('[data-role="sheet"]');
    fd.set('action', action);
    fd.set('token', pr.token);
    fd.set('sheet', String(sheet ? sheet.value : pr.data.sheet));
    fd.set('map', JSON.stringify({
      barcode: selectedValue(pricesPreview.querySelector('[data-role="barcode"]')),
      sell: selectedValue(pricesPreview.querySelector('[data-role="sell"]')),
      buy: selectedValue(pricesPreview.querySelector('[data-role="buy"]')),
      header_row: pr.data.map.header_row
    }));
    return fd;
  }

  pricesPreview.addEventListener('change', function (e) {
    var role = e.target.dataset.role;
    var fd;
    if (role === 'sheet') {
      fd = new FormData();
      fd.set('action', 'rescan');
      fd.set('token', pr.token);
      fd.set('sheet', e.target.value);           // ورقة جديدة: اكتشاف الأعمدة من جديد
    } else {
      fd = priceRequest('rescan');
    }
    busy(pricesPreview, true);
    MP.api.upload('api/bulk_update_prices.php', fd).then(function (res) {
      pr.data = res;
      renderPrices();
    }, function (err) {
      MP.toast(err.message, 'error');
      busy(pricesPreview, false);
    });
  });

  pricesPreview.addEventListener('click', function (e) {
    var el = e.target.closest('[data-role]');
    var role = el && el.dataset.role;
    if (role === 'cancel') {
      pricesPreview.hidden = true;
      pricesForm.reset();
      return;
    }
    if (role !== 'commit') return;
    if (!window.confirm('تحديث أسعار ' + num(pr.data.summary.changed) + ' صنف؟')) return;
    busy(pricesPreview, true);
    MP.api.upload('api/bulk_update_prices.php', priceRequest('commit')).then(function (res) {
      pricesPreview.hidden = true;
      pricesForm.reset();
      pricesResult.innerHTML = '<div class="alert alert--ok"><strong>تحدّثت أسعار ' + num(res.updated) + ' صنف.</strong>' +
        (res.unmatched ? ' ' + num(res.unmatched) + ' باركود في الملف غير موجود في المخزون.' : '') + '</div>';
      pricesResult.hidden = false;
      MP.toast('اكتمل تحديث الأسعار.', 'success');
    }, function (err) {
      MP.toast(err.message, 'error', { duration: 9000 });
      busy(pricesPreview, false);
    });
  });

  /* ── القوالب والتصدير ──────────────────────────────────────────────── */

  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-export]');
    if (!btn) return;
    btn.disabled = true;
    MP.api.download('api/export_products.php', { template: btn.dataset.export, filter: btn.dataset.filter || '' }, 'motoparts.xlsx')
      .then(function (name) { MP.toast('نُزّل الملف ' + name, 'success'); }, function (err) { MP.toast(err.message, 'error'); })
      .then(function () { btn.disabled = false; });
  });

  /* ── النسخ الاحتياطي ───────────────────────────────────────────────── */

  var backupList = $('backupList');

  function loadBackups() {
    MP.api.get('api/maintenance.php', { action: 'backups' }).then(function (res) {
      if (!res.items.length) {
        backupList.innerHTML = '<p class="muted">لا توجد نسخ بعد.</p>';
        return;
      }
      backupList.innerHTML = '<ul class="file-list">' + res.items.slice(0, 10).map(function (b) {
        return '<li><span><span class="mono">' + h(b.file) + '</span> <span class="muted small">' + h(b.created_at) + ' · ' + Math.max(1, Math.round(b.size / 1024)) + ' KB</span></span>' +
          '<button class="btn btn--sm" type="button" data-backup="' + h(b.file) + '">تنزيل</button></li>';
      }).join('') + '</ul>' + (res.items.length > 10 ? '<p class="muted small">و' + (res.items.length - 10) + ' نسخ أقدم في ' + h(res.dir) + '</p>' : '');
    }, function (err) {
      backupList.innerHTML = '<p class="muted">' + h(err.message) + '</p>';
    });
  }

  backupList.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-backup]');
    if (!btn) return;
    MP.api.download('api/maintenance.php', { action: 'download', file: btn.dataset.backup }, btn.dataset.backup)
      .catch(function (err) { MP.toast(err.message, 'error'); });
  });

  document.querySelector('[data-action="backup-now"]').addEventListener('click', function (e) {
    var btn = e.currentTarget;
    btn.disabled = true;
    btn.textContent = 'جارٍ النسخ…';
    MP.api.post('api/maintenance.php', { action: 'backup' }, { timeout: 300000 }).then(function (res) {
      MP.toast('أُنشئت النسخة ' + res.file, 'success');
      loadBackups();
    }, function (err) {
      MP.toast(err.message, 'error');
    }).then(function () {
      btn.disabled = false;
      btn.textContent = 'نسخة احتياطية الآن';
    });
  });

  loadBackups();
})();
