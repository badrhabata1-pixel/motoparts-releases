/*
 * فحص التحديث الصامت بعد هدوء الصفحة، دون أن يؤخر أي عملية بيع.
 * انقطاع الإنترنت حالة طبيعية: لا رسالة ولا خطأ. عند وجود إصدار أحدث تظهر شارة في الشريط العلوي،
 * والتثبيت لا يبدأ إلا بعد موافقة المستخدم.
 */
(function () {
  'use strict';

  var MP = window.MP, APP = window.APP || {};
  var badge = document.getElementById('updateBadge');
  var KEY = 'mp_update_check';
  if (!badge || !MP) return;

  function show(info) {
    badge.hidden = false;
    badge.disabled = false;
    badge.textContent = 'تحديث ' + info.latest + ' متاح';
    badge.title = info.notes || 'اضغط للتثبيت';
    badge.onclick = function () { apply(info); };
  }

  function check() {
    // التحديث من الإنترنت يُفحص مرة يومياً. من مجلد محلي أو فلاشة يُفحص مع كل صفحة: نسخ الملفين يكفي ليظهر.
    var last = MP.store.get(KEY, null);
    if (last && last.date === APP.today && last.source === 'online' && !last.available) return;
    MP.api.get('updater/check_update.php', null, { timeout: 20000 }).then(function (res) {
      MP.store.set(KEY, { date: APP.today, source: res.source || '', available: !!res.available });
      if (res.available) show(res);
    }, function () { /* بلا إنترنت أو الخادم متوقف: يُعاد الفحص لاحقاً */ });
  }

  function apply(info) {
    var message = 'تثبيت الإصدار ' + info.latest + '؟\n\n' + (info.notes ? info.notes + '\n\n' : '') +
      'تُؤخذ نسخة احتياطية من قاعدة البيانات والملفات قبل التحديث، ولا تتأثر بيانات المبيعات.\n' +
      'لا تغلق البرنامج حتى تظهر رسالة الانتهاء.';
    if (!window.confirm(message)) return;
    badge.disabled = true;
    badge.textContent = 'جارٍ التحديث…';
    MP.api.post('updater/apply_update.php', { version: info.latest }, { timeout: 900000 }).then(function (res) {
      MP.store.remove(KEY);
      MP.toast('تم التحديث إلى الإصدار ' + res.version + '. ستُعاد تحميل الصفحة.', 'success');
      setTimeout(function () { location.reload(); }, 1500);
    }, function (err) {
      show(info);
      MP.toast(err.message, 'error', { duration: 15000 });
    });
  }

  setTimeout(function () {
    (window.requestIdleCallback || function (cb) { setTimeout(cb, 0); })(check, { timeout: 10000 });
  }, 8000);
})();
