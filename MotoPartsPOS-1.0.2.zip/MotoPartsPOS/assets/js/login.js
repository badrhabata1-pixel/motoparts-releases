/*
 * شاشة تسجيل الدخول: إظهار كلمة المرور، تنبيه Caps Lock، منع الضغط المزدوج، والوضع الليلي.
 * النموذج يعمل بدون هذا الملف أيضاً: التحقق كله في login.php.
 */
(function () {
  'use strict';

  var form = document.getElementById('loginForm');
  var password = document.getElementById('password');
  var reveal = document.getElementById('togglePassword');
  var caps = document.getElementById('capsWarning');
  var submit = document.getElementById('loginSubmit');
  if (!form) return;

  reveal.addEventListener('click', function () {
    var show = password.type === 'password';
    password.type = show ? 'text' : 'password';
    var label = show ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور';
    reveal.setAttribute('aria-pressed', String(show));
    reveal.setAttribute('aria-label', label);
    reveal.title = label;
    password.focus();
  });

  function checkCaps(e) {
    if (e.getModifierState) caps.hidden = !e.getModifierState('CapsLock');
  }
  password.addEventListener('keydown', checkCaps);
  password.addEventListener('keyup', checkCaps);
  password.addEventListener('blur', function () { caps.hidden = true; });

  form.addEventListener('submit', function (e) {
    if (submit.disabled) {
      e.preventDefault();
      return;
    }
    password.type = 'password';
    submit.disabled = true;
    submit.textContent = 'جارٍ التحقق…';
  });
  // الرجوع للصفحة من ذاكرة المتصفح يعيد الزر لحالته.
  window.addEventListener('pageshow', function () {
    submit.disabled = false;
    submit.textContent = 'تسجيل الدخول';
  });

  document.addEventListener('click', function (e) {
    if (!e.target.closest('[data-action="toggle-theme"]')) return;
    var dark = document.documentElement.getAttribute('data-theme') !== 'dark';
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    try { localStorage.setItem('mp_theme', JSON.stringify(dark ? 'dark' : 'light')); } catch (err) { /* التخزين معطّل */ }
  });
})();
