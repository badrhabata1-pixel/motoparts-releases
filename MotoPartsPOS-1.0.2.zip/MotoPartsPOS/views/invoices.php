<?php defined('IN_APP') || exit; ?>
<section class="toolbar">
  <label class="search-field">
    <svg class="icon"><use href="#i-search"/></svg>
    <input id="ivSearch" class="input" type="search" autocomplete="off" spellcheck="false"
           placeholder="رقم الفاتورة، أو اسم العميل، أو رقم الهاتف">
  </label>
  <div class="segmented segmented--inline" role="radiogroup" aria-label="التاريخ">
    <label><input type="radio" name="ivDay" value="today" checked> <span>اليوم</span></label>
    <label><input type="radio" name="ivDay" value="all"> <span>الكل</span></label>
    <label><input type="radio" name="ivDay" value="date"> <span>يوم محدد</span></label>
  </div>
  <input id="ivDate" class="input" type="date" max="<?= h(date('Y-m-d')) ?>" value="<?= h(date('Y-m-d')) ?>" aria-label="اليوم المحدد" hidden>
  <select id="ivStatus" class="input select" aria-label="الحالة">
    <option value="">كل الحالات</option>
    <option value="completed">مكتملة</option>
    <option value="returned">بها مرتجع</option>
    <option value="void">ملغاة / مرتجعة بالكامل</option>
  </select>
</section>

<section class="kpis kpis--compact" id="ivSummary" aria-live="polite">
  <div class="kpi"><span class="kpi__label">عدد الفواتير</span><strong class="kpi__value" data-sum="count">—</strong></div>
  <div class="kpi"><span class="kpi__label">الإجمالي</span><strong class="kpi__value" data-sum="total">—</strong></div>
  <div class="kpi"><span class="kpi__label">المرتجع والملغى</span><strong class="kpi__value" data-sum="returned">—</strong></div>
  <div class="kpi kpi--accent"><span class="kpi__label">الصافي</span><strong class="kpi__value" data-sum="net">—</strong></div>
</section>

<section class="card card--flush">
  <div class="table-wrap">
    <table class="grid grid--rows-clickable">
      <thead>
        <tr>
          <th>رقم الفاتورة</th>
          <th>التاريخ والوقت</th>
          <th>العميل</th>
          <th>الهاتف</th>
          <th class="num">عدد الأصناف</th>
          <th class="num">الإجمالي</th>
          <th>الحالة</th>
          <th class="actions-col">إجراءات</th>
        </tr>
      </thead>
      <tbody id="ivBody"><tr><td colspan="8" class="empty">جارٍ التحميل…</td></tr></tbody>
    </table>
  </div>
  <div class="pager">
    <span id="ivCount" class="muted"></span>
    <div class="pager__buttons">
      <button class="btn btn--sm" type="button" data-action="iv-prev">السابق</button>
      <button class="btn btn--sm" type="button" data-action="iv-next">التالي</button>
    </div>
  </div>
</section>
