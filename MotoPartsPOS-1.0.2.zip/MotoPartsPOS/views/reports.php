<?php
defined('IN_APP') || exit;

$date = valid_date($_GET['date'] ?? null) ?? date('Y-m-d');
[$from, $to] = day_range($date);

$st = $pdo->prepare("SELECT COUNT(*) AS cnt, COALESCE(SUM(total_amount), 0) AS sales, COALESCE(SUM(status = 'void'), 0) AS voided
                       FROM invoices WHERE created_at >= ? AND created_at < ?");
$st->execute([$from, $to]);
$day = $st->fetch();

$st = $pdo->prepare('SELECT COALESCE(SUM(amount), 0) FROM invoice_returns WHERE created_at >= ? AND created_at < ?');
$st->execute([$from, $to]);
$returnsC = to_hundredths((string) $st->fetchColumn()) ?? 0;

$salesC = to_hundredths((string) $day['sales']) ?? 0;
$invoiceCount = (int) $day['cnt'];
$averageC = $invoiceCount > 0 ? intdiv($salesC, $invoiceCount) : 0;

$st = $pdo->prepare('SELECT COUNT(*) FROM invoice_items ii JOIN invoices i ON i.id = ii.invoice_id
                      WHERE i.created_at >= ? AND i.created_at < ? AND ii.unit_price = 0');
$st->execute([$from, $to]);
$zeroLines = (int) $st->fetchColumn();

$st = $pdo->prepare('SELECT ii.product_id, MAX(ii.product_name) AS name, MAX(ii.barcode) AS barcode,
                            SUM(ii.quantity - ii.returned_qty) AS qty, SUM(ii.subtotal) AS revenue
                       FROM invoice_items ii JOIN invoices i ON i.id = ii.invoice_id
                      WHERE i.created_at >= ? AND i.created_at < ?
                      GROUP BY ii.product_id
                     HAVING qty > 0
                      ORDER BY qty DESC, revenue DESC
                      LIMIT 10');
$st->execute([$from, $to]);
$top = $st->fetchAll();

$lowCount = (int) $pdo->query('SELECT COUNT(*) FROM products WHERE is_active = 1 AND stock_quantity <= min_alert_qty')->fetchColumn();
$low = $pdo->query('SELECT id, barcode, product_name, stock_quantity, min_alert_qty, is_barcoded
                      FROM products WHERE is_active = 1 AND stock_quantity <= min_alert_qty
                     ORDER BY stock_quantity ASC, product_name ASC LIMIT 100')->fetchAll();
$isToday = $date === date('Y-m-d');
?>
<section class="toolbar">
  <form class="toolbar__form" method="get" id="dateForm">
    <input type="hidden" name="page" value="reports">
    <label class="field field--inline">
      <span class="field__label">تقرير يوم</span>
      <input class="input" type="date" name="date" value="<?= h($date) ?>" max="<?= h(date('Y-m-d')) ?>">
    </label>
    <?php if (!$isToday): ?><a class="btn btn--sm" href="index.php?page=reports">اليوم</a><?php endif; ?>
  </form>
  <a class="btn" href="index.php?page=invoices&amp;date=<?= h($date) ?>"><svg class="icon"><use href="#i-receipt"/></svg> فواتير هذا اليوم</a>
</section>

<section class="kpis">
  <div class="kpi kpi--accent">
    <span class="kpi__label">صافي المبيعات</span>
    <strong class="kpi__value"><?= h(money_display($salesC - $returnsC)) ?></strong>
    <span class="kpi__unit"><?= h(APP_CURRENCY) ?></span>
  </div>
  <div class="kpi">
    <span class="kpi__label">إجمالي المبيعات</span>
    <strong class="kpi__value"><?= h(money_display($salesC)) ?></strong>
    <span class="kpi__unit"><?= h(APP_CURRENCY) ?></span>
  </div>
  <div class="kpi">
    <span class="kpi__label">المرتجعات والإلغاء</span>
    <strong class="kpi__value"><?= h(money_display($returnsC)) ?></strong>
    <span class="kpi__unit"><?= h(APP_CURRENCY) ?></span>
  </div>
  <div class="kpi">
    <span class="kpi__label">عدد الفواتير</span>
    <strong class="kpi__value"><?= $invoiceCount ?></strong>
    <span class="kpi__unit"><?= (int) $day['voided'] > 0 ? 'منها ' . (int) $day['voided'] . ' ملغاة' : 'فاتورة' ?></span>
  </div>
  <div class="kpi">
    <span class="kpi__label">متوسط الفاتورة</span>
    <strong class="kpi__value"><?= h(money_display($averageC)) ?></strong>
    <span class="kpi__unit"><?= h(APP_CURRENCY) ?></span>
  </div>
</section>
<?php if ($zeroLines > 0): ?>
  <div class="alert alert--warn"><?= $zeroLines ?> بند بيع بسعر 0.00 في هذا اليوم: الأسعار لم تُحدَّد بعد لهذه الأصناف.</div>
<?php endif; ?>

<div class="cards-grid">
  <section class="card card--flush">
    <div class="card__head"><h2 class="card__title">الأكثر مبيعاً — <?= h($date) ?></h2></div>
    <?php if (!$top): ?>
      <p class="empty">لا توجد مبيعات في هذا اليوم.</p>
    <?php else: ?>
      <div class="table-wrap">
        <table class="grid">
          <thead><tr><th>الصنف</th><th>الباركود</th><th class="num">الكمية</th><th class="num">الإيراد</th></tr></thead>
          <tbody>
          <?php foreach ($top as $row): ?>
            <tr>
              <td><?= h($row['name']) ?></td>
              <td class="mono"><?= h($row['barcode']) ?></td>
              <td class="num"><?= h(qty_display((string) $row['qty'])) ?></td>
              <td class="num"><?= h(money_display((string) $row['revenue'])) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </section>

  <section class="card card--flush">
    <div class="card__head">
      <h2 class="card__title">تنبيه نقص المخزون <span class="badge badge--danger"><?= $lowCount ?></span></h2>
      <?php if ($lowCount > count($low)): ?>
        <a class="btn btn--sm" href="index.php?page=inventory&amp;filter=low">عرض الكل في المخزون</a>
      <?php endif; ?>
    </div>
    <?php if (!$low): ?>
      <p class="empty">لا توجد أصناف تحت حد التنبيه.</p>
    <?php else: ?>
      <div class="table-wrap table-wrap--tall">
        <table class="grid">
          <thead><tr><th>الصنف</th><th>الباركود</th><th class="num">الرصيد</th><th class="num">حد التنبيه</th></tr></thead>
          <tbody>
          <?php foreach ($low as $row): ?>
            <tr>
              <td><?= h($row['product_name']) ?><?= (int) $row['is_barcoded'] ? '' : ' <span class="badge badge--muted">يدوي</span>' ?></td>
              <td class="mono"><?= h($row['barcode']) ?></td>
              <td class="num qty-low"><?= h(qty_display((string) $row['stock_quantity'])) ?></td>
              <td class="num"><?= h(qty_display((string) $row['min_alert_qty'])) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </section>
</div>
