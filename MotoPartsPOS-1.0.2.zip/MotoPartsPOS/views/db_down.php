<?php /* تُعرض عندما لا تستجيب قاعدة البيانات. $dbError من index.php */ ?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="15">
<title>قاعدة البيانات متوقفة — <?= h(APP_NAME) ?></title>
<link rel="icon" href="data:,">
<link rel="stylesheet" href="<?= h(asset('assets/css/style.css')) ?>">
</head>
<body>
<main class="page page--narrow">
  <section class="card">
    <div class="card__head"><h1 class="card__title">تعذر الاتصال بقاعدة البيانات</h1></div>
    <div class="card__body stack">
      <p>نقطة البيع تحتاج MySQL يعمل على <code><?= h(DB_HOST . ':' . DB_PORT) ?></code>.</p>
      <ol class="steps">
        <li>أغلق هذه النافذة وافتح البرنامج من أيقونة <strong>MotoParts POS</strong> على سطح المكتب: تشغّل الخادم تلقائياً.</li>
        <li>إن لم ينجح ذلك: من قائمة ابدأ شغّل <strong>إصلاح خادم MotoParts</strong> ووافق على طلب الصلاحيات.</li>
        <li>على جهاز التطوير (XAMPP): اضغط <strong>Start</strong> بجوار MySQL في XAMPP Control Panel.</li>
        <li>هذه الصفحة تعيد المحاولة تلقائياً كل 15 ثانية.</li>
      </ol>
      <details>
        <summary>تفاصيل تقنية</summary>
        <pre class="pre"><?= h($dbError) ?></pre>
      </details>
    </div>
  </section>
</main>
</body>
</html>
