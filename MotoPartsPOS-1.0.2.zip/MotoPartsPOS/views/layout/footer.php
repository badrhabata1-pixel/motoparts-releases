<?php defined('IN_APP') || exit; ?>
</main>
<div id="toasts" class="toasts" role="status" aria-live="polite"></div>
<script src="<?= h(asset('assets/js/app.js')) ?>" defer></script>
<?php foreach ($pageScripts as $script): ?>
<script src="<?= h(asset('assets/js/' . $script . '.js')) ?>" defer></script>
<?php endforeach; ?>
<script src="<?= h(asset('assets/js/updater.js')) ?>" defer></script>
</body>
</html>
