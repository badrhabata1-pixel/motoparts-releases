<?php
defined('IN_APP') || exit;

$navIcons = ['pos' => 'cart', 'invoices' => 'receipt', 'inventory' => 'box', 'labels' => 'printer', 'import' => 'upload', 'reports' => 'chart'];
$authUser = auth_user();
$appConfig = [
    'version'         => APP_VERSION,
    'page'            => $page,
    'currency'        => APP_CURRENCY,
    'scanGap'         => (int) SCAN_MAX_GAP_MS,
    'allowNegative'   => (bool) ALLOW_NEGATIVE_STOCK,
    'defaultMinAlert' => DEFAULT_MIN_ALERT,
    'today'           => date('Y-m-d'),
    'tzOffsetMin'     => intdiv((int) date('Z'), 60),
];
?>
<!doctype html>
<html lang="ar" dir="rtl" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($pageTitle) ?> — <?= h(APP_NAME) ?></title>
<link rel="icon" href="data:,">
<link rel="stylesheet" href="<?= h(asset('assets/css/style.css')) ?>">
<?php if ($page === 'pos'): ?>
<link rel="stylesheet" href="<?= h(asset('assets/css/pos.css')) ?>">
<?php endif; ?>
<script>
(function () {
  try {
    var saved = JSON.parse(localStorage.getItem('mp_theme') || 'null');
    var dark = saved ? saved === 'dark' : !!(window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
  } catch (e) {}
})();
window.APP = <?= json_encode($appConfig, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
</script>
</head>
<body class="page-<?= h($page) ?>">
<svg class="sprite" aria-hidden="true" focusable="false">
  <symbol id="i-cart" viewBox="0 0 24 24"><path d="M3 4h2l2.4 11.2a1 1 0 0 0 1 .8h8.9a1 1 0 0 0 1-.8L20 8H6.2"/><circle cx="9" cy="20" r="1.3"/><circle cx="17" cy="20" r="1.3"/></symbol>
  <symbol id="i-box" viewBox="0 0 24 24"><path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/></symbol>
  <symbol id="i-upload" viewBox="0 0 24 24"><path d="M12 16V4"/><path d="M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/></symbol>
  <symbol id="i-chart" viewBox="0 0 24 24"><path d="M5 20V11"/><path d="M11 20V5"/><path d="M17 20v-7"/><path d="M3 20h18"/></symbol>
  <symbol id="i-sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></symbol>
  <symbol id="i-moon" viewBox="0 0 24 24"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></symbol>
  <symbol id="i-volume" viewBox="0 0 24 24"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></symbol>
  <symbol id="i-mute" viewBox="0 0 24 24"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M22 9l-6 6M16 9l6 6"/></symbol>
  <symbol id="i-search" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></symbol>
  <symbol id="i-plus" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></symbol>
  <symbol id="i-edit" viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16v4z"/><path d="M13.5 6.5l4 4"/></symbol>
  <symbol id="i-trash" viewBox="0 0 24 24"><path d="M4 7h16"/><path d="M10 11v6M14 11v6"/><path d="M6 7l1 13h10l1-13"/><path d="M9 7V4h6v3"/></symbol>
  <symbol id="i-layers" viewBox="0 0 24 24"><path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5"/></symbol>
  <symbol id="i-download" viewBox="0 0 24 24"><path d="M12 4v12"/><path d="M7 11l5 5 5-5"/><path d="M4 20h16"/></symbol>
  <symbol id="i-x" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></symbol>
  <symbol id="i-restore" viewBox="0 0 24 24"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></symbol>
  <symbol id="i-bolt" viewBox="0 0 24 24"><path d="M13 2L4.5 13.5h6.5L10 22l9-12h-6.5L13 2z"/></symbol>
  <symbol id="i-printer" viewBox="0 0 24 24"><path d="M7 9V3h10v6"/><path d="M7 18H5a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M7 14h10v7H7z"/></symbol>
  <symbol id="i-receipt" viewBox="0 0 24 24"><path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3z"/><path d="M9 8h6M9 12h6M9 16h3"/></symbol>
  <symbol id="i-logout" viewBox="0 0 24 24"><path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3"/><path d="M10 17l-5-5 5-5"/><path d="M5 12h11"/></symbol>
</svg>

<header class="topbar">
  <a class="brand" href="index.php">
    <span class="brand__mark" aria-hidden="true">MP</span>
    <span class="brand__name">MotoParts</span>
  </a>
  <nav class="nav" aria-label="القائمة الرئيسية">
    <?php foreach ($pages as $key => $info): ?>
      <a class="nav__link<?= $key === $page ? ' is-active' : '' ?>" href="index.php?page=<?= h($key) ?>"<?= $key === $page ? ' aria-current="page"' : '' ?>>
        <svg class="icon"><use href="#i-<?= h($navIcons[$key]) ?>"/></svg><span><?= h($info['title']) ?></span>
      </a>
    <?php endforeach; ?>
  </nav>
  <div class="topbar__tools">
    <button id="updateBadge" class="update-badge" type="button" hidden></button>
    <span class="clock" id="clock" title="ساعة الخادم — يجب أن تطابق ساعة Windows. إن اختلفت فاضبط APP_TIMEZONE"></span>
    <button class="icon-btn" type="button" data-action="toggle-sound" title="صوت الماسح" aria-label="تشغيل أو كتم صوت الماسح">
      <svg class="icon icon--on"><use href="#i-volume"/></svg><svg class="icon icon--off"><use href="#i-mute"/></svg>
    </button>
    <button class="icon-btn" type="button" data-action="toggle-theme" title="الوضع الليلي" aria-label="تبديل الوضع الليلي">
      <svg class="icon icon--light"><use href="#i-moon"/></svg><svg class="icon icon--dark"><use href="#i-sun"/></svg>
    </button>
    <form class="logout-form" method="post" action="logout.php">
      <input type="hidden" name="csrf" value="<?= h(auth_csrf_token()) ?>">
      <button class="btn btn--sm logout-btn" type="submit" aria-label="تسجيل الخروج" title="تسجيل الخروج (<?= h($authUser['username'] ?? '') ?>)">
        <svg class="icon"><use href="#i-logout"/></svg><span>تسجيل الخروج</span>
      </button>
    </form>
  </div>
</header>
<main class="page page--<?= h($page) ?>">
