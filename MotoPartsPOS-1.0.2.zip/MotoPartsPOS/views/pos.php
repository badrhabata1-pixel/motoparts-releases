<?php defined('IN_APP') || exit; ?>
<div class="pos">
  <section class="pos-main">
    <div class="scanbar">
      <label class="scanbar__field">
        <svg class="icon"><use href="#i-search"/></svg>
        <input id="scanInput" class="scanbar__input" type="text" autocomplete="off" autocorrect="off" spellcheck="false"
               placeholder="امسح الباركود أو اكتب اسم الصنف" aria-label="الباركود أو اسم الصنف" autofocus>
      </label>
      <button class="btn btn--lg btn--quick" type="button" data-action="quick-access"><svg class="icon"><use href="#i-bolt"/></svg><span>وصول سريع</span> <kbd>F3</kbd></button>
      <button class="btn btn--lg" type="button" data-action="quick-fast"><span>الأكثر مبيعاً</span> <kbd>F1</kbd></button>
      <button class="btn btn--lg" type="button" data-action="quick-unbarcoded"><span>بدون باركود</span> <kbd>F2</kbd></button>
    </div>

    <div class="cart" id="cart">
      <table class="grid cart-table">
        <thead>
          <tr>
            <th class="c-idx">م</th>
            <th class="c-code">الباركود</th>
            <th>الصنف</th>
            <th class="c-qty">الكمية</th>
            <th class="c-price">السعر</th>
            <th class="c-total">الإجمالي</th>
            <th class="c-del">حذف</th>
          </tr>
        </thead>
        <tbody id="cartBody"></tbody>
      </table>
      <div class="cart-empty" id="cartEmpty">
        <svg class="icon icon--xl"><use href="#i-cart"/></svg>
        <p class="cart-empty__title">امسح أول صنف لبدء الفاتورة</p>
        <p class="muted">أو اضغط <kbd>F3</kbd> للوصول السريع، <kbd>F1</kbd> للأكثر مبيعاً، <kbd>F2</kbd> للأصناف بدون باركود</p>
      </div>
    </div>
  </section>

  <aside class="pos-side">
    <div class="total-card">
      <span class="total-card__label">الإجمالي</span>
      <strong class="total-card__value" id="grandTotal">0.00</strong>
      <span class="total-card__currency"><?= h(APP_CURRENCY) ?></span>
    </div>
    <dl class="pos-stats">
      <div><dt>عدد الأصناف</dt><dd id="statLines">0</dd></div>
      <div><dt>إجمالي القطع</dt><dd id="statPieces">0</dd></div>
      <div class="pos-stats__warn" id="statZeroRow" hidden><dt>أصناف بسعر 0.00</dt><dd id="statZero">0</dd></div>
    </dl>
    <button class="btn btn--primary btn--xl" type="button" data-action="checkout" id="checkoutBtn">حفظ الفاتورة <kbd>F9</kbd></button>
    <button class="btn btn--ghost" type="button" data-action="clear">فاتورة جديدة</button>
    <button class="last-invoice" type="button" id="lastInvoice" title="عرض تفاصيل آخر فاتورة" hidden></button>
    <ul class="shortcuts">
      <li><kbd>F3</kbd> وصول سريع</li>
      <li><kbd>F1</kbd> الأكثر مبيعاً</li>
      <li><kbd>F2</kbd> بدون باركود</li>
      <li><kbd>F9</kbd> حفظ الفاتورة</li>
      <li><kbd>Esc</kbd> إغلاق النافذة</li>
    </ul>
  </aside>
</div>

<dialog id="quickAccessDialog" class="dialog dialog--wide" aria-labelledby="qaTitle">
  <div class="dialog__head">
    <h2 id="qaTitle" class="dialog__title"><svg class="icon icon--bolt"><use href="#i-bolt"/></svg> وصول سريع <kbd>F3</kbd></h2>
    <button class="icon-btn" type="button" data-close aria-label="إغلاق"><svg class="icon"><use href="#i-x"/></svg></button>
  </div>
  <div class="dialog__body stack">
    <label class="search-field">
      <svg class="icon"><use href="#i-search"/></svg>
      <input id="qaSearch" class="input" type="search" autocomplete="off" spellcheck="false"
             placeholder="ابحث هنا… أو عن أي صنف لإضافته للوصول السريع">
    </label>
    <div id="qaGrid" class="qa-grid" role="listbox" aria-label="أصناف الوصول السريع"></div>
    <div id="qaMore" class="stack-sm" hidden>
      <h3 class="subhead">أصناف أخرى: <svg class="icon icon--bolt"><use href="#i-bolt"/></svg> تضيفها للوصول السريع، والضغط على الاسم يضيفها للفاتورة</h3>
      <div id="qaResults" class="quick-list quick-list--short" role="listbox" aria-label="نتائج البحث"></div>
    </div>
    <p class="muted small">الضغط على الصنف يضيفه للفاتورة · <svg class="icon icon--sm"><use href="#i-bolt"/></svg> تضيفه للوصول السريع أو تلغيه · ↑ ↓ للتنقل و Enter للإضافة</p>
  </div>
</dialog>

<dialog id="quickDialog" class="dialog dialog--wide" aria-labelledby="quickTitle">
  <div class="dialog__head">
    <h2 id="quickTitle" class="dialog__title">اختيار صنف</h2>
    <button class="icon-btn" type="button" data-close aria-label="إغلاق"><svg class="icon"><use href="#i-x"/></svg></button>
  </div>
  <div class="dialog__body stack">
    <div class="tabs" role="tablist">
      <button class="tab" type="button" role="tab" data-tab="fast">الأكثر مبيعاً <kbd>F1</kbd></button>
      <button class="tab" type="button" role="tab" data-tab="unbarcoded">بدون باركود <kbd>F2</kbd></button>
      <button class="tab" type="button" role="tab" data-tab="search">بحث في كل الأصناف</button>
    </div>
    <input id="quickSearch" class="input input--lg" type="search" autocomplete="off" spellcheck="false"
           placeholder="اكتب للتصفية… (↑ ↓ للتنقل، Enter للإضافة)">
    <div id="quickList" class="quick-list" role="listbox" aria-label="الأصناف"></div>
  </div>
</dialog>

<dialog id="checkoutDialog" class="dialog" aria-labelledby="checkoutTitle">
  <form id="checkoutForm" novalidate>
    <div class="dialog__head">
      <h2 id="checkoutTitle" class="dialog__title">حفظ الفاتورة</h2>
      <button class="icon-btn" type="button" data-close aria-label="إغلاق"><svg class="icon"><use href="#i-x"/></svg></button>
    </div>
    <div class="dialog__body stack">
      <div class="checkout-total">
        <span>الإجمالي</span>
        <strong id="coTotal">0.00</strong>
        <span><?= h(APP_CURRENCY) ?></span>
        <span class="muted" id="coLines"></span>
      </div>
      <div class="form-grid">
        <label class="field">
          <span class="field__label">اسم العميل (اختياري)</span>
          <input id="coName" class="input" type="text" maxlength="150" placeholder="عميل نقدي" autocomplete="off">
        </label>
        <label class="field">
          <span class="field__label">رقم الهاتف (اختياري)</span>
          <input id="coPhone" class="input" type="tel" maxlength="50" inputmode="tel" autocomplete="off" dir="ltr">
        </label>
      </div>
      <div id="coWarnings" class="stack-sm"></div>
      <label class="check" id="coSavePricesRow" hidden>
        <input type="checkbox" id="coSavePrices">
        <span>احفظ الأسعار التي كتبتها كسعر بيع للأصناف التي سعرها 0.00</span>
      </label>
      <div id="coError" class="alert alert--danger" hidden></div>
    </div>
    <div class="dialog__foot">
      <button class="btn btn--ghost" type="button" data-close>رجوع <kbd>Esc</kbd></button>
      <button class="btn btn--primary btn--lg" type="submit" id="coSubmit">حفظ <kbd>Enter</kbd></button>
    </div>
  </form>
</dialog>
