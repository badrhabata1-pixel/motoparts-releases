<?php
defined('APP_ROOT') || exit;
/* شاشة تسجيل الدخول. المتغيرات من login.php: $error و $notice و $username و $next و $csrf. */
?>
<!doctype html>
<html lang="ar" dir="rtl" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>تسجيل الدخول — <?= h(APP_NAME) ?></title>
<link rel="icon" href="data:,">
<link rel="stylesheet" href="<?= h(asset('assets/css/style.css')) ?>">
<link rel="stylesheet" href="<?= h(asset('assets/css/login.css')) ?>">
<script>
(function () {
  try {
    var saved = JSON.parse(localStorage.getItem('mp_theme') || 'null');
    var dark = saved ? saved === 'dark' : !!(window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
  } catch (e) {}
})();
</script>
</head>
<body class="page-login">
<svg class="sprite" aria-hidden="true" focusable="false">
  <symbol id="i-user" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></symbol>
  <symbol id="i-lock" viewBox="0 0 24 24"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></symbol>
  <symbol id="i-eye" viewBox="0 0 24 24"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></symbol>
  <symbol id="i-eye-off" viewBox="0 0 24 24"><path d="M3 3l18 18"/><path d="M10.6 5.1A10.5 10.5 0 0 1 12 5c6.4 0 10 7 10 7a17.4 17.4 0 0 1-3.2 4.2M6.6 6.6C3.9 8.4 2 12 2 12s3.6 7 10 7a9.9 9.9 0 0 0 5.4-1.6"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></symbol>
  <symbol id="i-alert" viewBox="0 0 24 24"><path d="M12 3l10 18H2L12 3z"/><path d="M12 10v4M12 17.5v.5"/></symbol>
  <symbol id="i-sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></symbol>
  <symbol id="i-moon" viewBox="0 0 24 24"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></symbol>
</svg>

<main class="login">
  <section class="login__card" aria-labelledby="loginTitle">
    <div class="login__brand">
      <span class="brand__mark login__mark" aria-hidden="true">MP</span>
      <div>
        <div class="login__app"><?= h(APP_NAME) ?></div>
        <div class="login__sub">نقطة البيع والمخزون</div>
      </div>
    </div>

    <h1 id="loginTitle" class="login__title">تسجيل الدخول</h1>
    <p class="login__lead">أدخل اسم المستخدم وكلمة المرور للمتابعة.</p>

    <?php if ($error !== null): ?>
      <div class="alert alert--danger login__alert" role="alert"><?= h($error) ?></div>
    <?php elseif ($notice !== null): ?>
      <div class="alert alert--info login__alert" role="status"><?= h($notice) ?></div>
    <?php endif; ?>

    <form id="loginForm" class="login__form" method="post" action="login.php">
      <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
      <input type="hidden" name="next" value="<?= h($next) ?>">

      <div class="field">
        <label class="field__label" for="username">اسم المستخدم</label>
        <span class="login__control">
          <svg class="icon"><use href="#i-user"/></svg>
          <input class="input" id="username" name="username" type="text" dir="ltr" maxlength="50"
                 value="<?= h($username) ?>" autocomplete="username" autocapitalize="off" spellcheck="false"<?= $username === '' ? ' autofocus' : '' ?>>
        </span>
      </div>

      <div class="field">
        <label class="field__label" for="password">كلمة المرور</label>
        <span class="login__control login__control--password">
          <svg class="icon"><use href="#i-lock"/></svg>
          <input class="input" id="password" name="password" type="password" dir="ltr" maxlength="200"
                 autocomplete="current-password"<?= $username !== '' ? ' autofocus' : '' ?>>
          <button class="login__reveal" id="togglePassword" type="button" aria-pressed="false" aria-controls="password"
                  aria-label="إظهار كلمة المرور" title="إظهار كلمة المرور">
            <svg class="icon icon--show"><use href="#i-eye"/></svg><svg class="icon icon--hide"><use href="#i-eye-off"/></svg>
          </button>
        </span>
        <span class="login__caps" id="capsWarning" role="status" hidden>
          <svg class="icon"><use href="#i-alert"/></svg>زر Caps Lock مفعّل: الحروف تُكتب كبيرة.
        </span>
      </div>

      <button class="btn btn--primary btn--xl login__submit" id="loginSubmit" type="submit">تسجيل الدخول</button>
    </form>

    <div class="login__foot">
      <span class="muted small">الإصدار <span class="mono"><?= h(APP_VERSION) ?></span></span>
      <button class="icon-btn" type="button" data-action="toggle-theme" title="الوضع الليلي" aria-label="تبديل الوضع الليلي">
        <svg class="icon icon--light"><use href="#i-moon"/></svg><svg class="icon icon--dark"><use href="#i-sun"/></svg>
      </button>
    </div>
  </section>
</main>
<script src="<?= h(asset('assets/js/login.js')) ?>" defer></script>
</body>
</html>
