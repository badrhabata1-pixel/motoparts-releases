<?php
/**
 * تثبيت التحديث بعد موافقة المستخدم: تنزيل الحزمة عبر HTTPS (أو نسخها من المجلد المحلي)، التحقق من بصمة SHA-256
 * (ومن توقيع Ed25519 إن ضُبط مفتاح عام)، ثم updater_install() التي تأخذ النسخ الاحتياطية
 * وتستبدل الملفات وتتراجع تلقائياً عند أي فشل.
 *
 * قاعدة البيانات لا يلمسها التحديث إلا عبر ترحيلات sql/ الإضافية (ADD COLUMN / CREATE TABLE).
 */
require __DIR__ . '/../includes/api.php';
require __DIR__ . '/../includes/http.php';
require __DIR__ . '/lib.php';

require_method('POST');
set_time_limit(900);
ignore_user_abort(true);

$in = request_json();
$state = updater_load_state();
$manifest = $state['manifest'] ?? null;
if (!is_array($manifest) || (string) ($in['version'] ?? '') !== (string) ($manifest['version'] ?? '')) {
    throw new UserError('لا يوجد تحديث جاهز بهذا الإصدار. أعد فحص التحديثات.', 409);
}
if (!version_compare($manifest['version'], APP_VERSION, '>')) {
    throw new UserError('الإصدار المثبت أحدث من هذا التحديث أو يساويه.', 409);
}
if ($manifest['min_php'] !== '' && version_compare(PHP_VERSION, $manifest['min_php'], '<')) {
    throw new UserError('هذا التحديث يتطلب PHP ' . $manifest['min_php'] . ' أو أحدث.');
}
updater_verify_signature($manifest);

$workDir = storage_path('updates');
$lock = fopen($workDir . '/.lock', 'c');
if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) {
    throw new UserError('يوجد تحديث آخر قيد التنفيذ.', 409);
}

$zipPath = $workDir . '/MotoPartsPOS-' . $manifest['version'] . '.zip';
if (($manifest['file'] ?? '') !== '') {
    // من مجلد أو فلاشة: نسخة في storage/updates أولاً، فلا يتأثر التثبيت إن نُزعت الفلاشة أثناءه.
    if (!is_file($manifest['file']) || !@copy($manifest['file'], $zipPath)) {
        @unlink($zipPath);
        throw new UserError('تعذر قراءة حزمة التحديث من ' . $manifest['file'] . '. تأكد أن الملف موجود ثم أعد المحاولة.');
    }
} else {
    $download = http_get($manifest['url'], 600, $zipPath);
    if ($download['error'] !== null || $download['status'] !== 200) {
        @unlink($zipPath);
        throw new UserError('فشل تنزيل التحديث: ' . ($download['error'] ?? 'HTTP ' . $download['status']));
    }
}
if (!hash_equals($manifest['sha256'], (string) hash_file('sha256', $zipPath))) {
    @unlink($zipPath);
    throw new UserError('بصمة الملف المنزَّل لا تطابق ملف الإصدار (ملف تالف أو معدَّل)، فأُلغي التحديث.');
}

$result = updater_install($zipPath);

unset($state['manifest']);
$state['result'] = null;
$state['installed'] = ['version' => $manifest['version'], 'at' => date('c'), 'previous' => APP_VERSION] + $result;
updater_save_state($state);
flock($lock, LOCK_UN);
fclose($lock);
@unlink($zipPath);

json_ok(['version' => $manifest['version']] + $result);
