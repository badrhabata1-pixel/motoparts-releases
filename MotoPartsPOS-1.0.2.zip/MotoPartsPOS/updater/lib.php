<?php
/**
 * أدوات المحدّث المشتركة. حالة المحدّث في storage/update_state.json، مستقلة عن قاعدة البيانات عمداً
 * حتى يبقى الفحص والتحديث ممكنين لو كانت القاعدة متوقفة.
 */
require_once __DIR__ . '/../includes/spreadsheet.php';
require_once __DIR__ . '/../includes/migrations.php';
require_once __DIR__ . '/../includes/backup.php';

/** مسارات لا يلمسها التحديث أبداً: إعدادات الجهاز والبيانات والنسخ الاحتياطية. */
const UPDATER_PROTECTED = ['config/local.php', 'storage/'];

function updater_state_path(): string
{
    return storage_path() . '/update_state.json';
}

function updater_load_state(): array
{
    $path = updater_state_path();
    $data = is_file($path) ? json_decode((string) file_get_contents($path), true) : null;
    return is_array($data) ? $data : [];
}

function updater_save_state(array $state): void
{
    file_put_contents(updater_state_path(), json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), LOCK_EX);
}

/**
 * مسار latest_version.json إن كان مصدر التحديث مجلداً على هذا الجهاز أو فلاشة (C:/MotoPartsPOS/updates/…)،
 * و null إن كان رابطاً (https://…) أو كان التحديث معطلاً.
 */
function updater_local_manifest(): ?string
{
    $source = trim((string) UPDATE_MANIFEST_URL);
    if ($source === '' || preg_match('#^[a-z][a-z0-9+.-]*://#i', $source)) {
        return null;
    }
    return str_replace('\\', '/', $source);
}

/**
 * شكل latest_version.json:
 * {"version":"1.0.1","url":"https://…/MotoPartsPOS-1.0.1.zip","sha256":"…64 hex…","notes":"…","min_php":"7.4","signature":"base64 (اختياري)"}
 *
 * من مجلد محلي ($localDir): url اسم ملف فقط ("MotoPartsPOS-1.0.1.zip") في نفس المجلد، ويُعاد مساره الكامل في file.
 */
function updater_validate_manifest($m, ?string $localDir = null): array
{
    if (!is_array($m)) {
        throw new UserError('ملف الإصدار على الخادم ليس JSON صالحاً.');
    }
    $manifest = [
        'version'   => (string) ($m['version'] ?? ''),
        'url'       => (string) ($m['url'] ?? ''),
        'sha256'    => strtolower((string) ($m['sha256'] ?? '')),
        'notes'     => clean_text((string) ($m['notes'] ?? ''), 600),
        'min_php'   => (string) ($m['min_php'] ?? ''),
        'signature' => (string) ($m['signature'] ?? ''),
    ];
    if (!preg_match('/^\d+\.\d+\.\d+$/', $manifest['version'])) {
        throw new UserError('رقم الإصدار في ملف التحديث غير صالح.');
    }
    if ($localDir !== null && preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]*\.zip$/', $manifest['url'])) {
        $manifest['file'] = rtrim($localDir, '/') . '/' . $manifest['url'];
    } elseif (stripos($manifest['url'], 'https://') !== 0) {
        throw new UserError($localDir !== null
            ? 'url في ملف التحديث يجب أن يكون اسم ملف الحزمة في نفس المجلد (MotoPartsPOS-x.y.z.zip) أو رابط HTTPS.'
            : 'رابط حزمة التحديث يجب أن يكون HTTPS.');
    }
    if (!preg_match('/^[a-f0-9]{64}$/', $manifest['sha256'])) {
        throw new UserError('بصمة SHA-256 في ملف التحديث غير صالحة.');
    }
    return $manifest;
}

/** عند ضبط UPDATE_PUBLIC_KEY: توقيع Ed25519 على "version\nsha256" إلزامي، ويُرفض التحديث إن تعذر التحقق. */
function updater_verify_signature(array $manifest): void
{
    if (UPDATE_PUBLIC_KEY === '') {
        return;
    }
    if (!function_exists('sodium_crypto_sign_verify_detached')) {
        throw new UserError('مفتاح التوقيع مضبوط لكن امتداد sodium غير مفعّل في php.ini، فلن يُثبَّت التحديث.');
    }
    $signature = base64_decode($manifest['signature'], true);
    $key = base64_decode(UPDATE_PUBLIC_KEY, true);
    if ($signature === false || $key === false
        || strlen($signature) !== SODIUM_CRYPTO_SIGN_BYTES || strlen($key) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) {
        throw new UserError('توقيع التحديث مفقود أو غير صالح.');
    }
    if (!sodium_crypto_sign_verify_detached($signature, $manifest['version'] . "\n" . $manifest['sha256'], $key)) {
        throw new UserError('توقيع التحديث لا يطابق المفتاح العام، فلن يُثبَّت.');
    }
}

function updater_is_protected(string $rel): bool
{
    foreach (UPDATER_PROTECTED as $path) {
        if (substr($path, -1) === '/' ? strpos($rel, $path) === 0 : $rel === $path) {
            return true;
        }
    }
    return false;
}

/** إن كانت كل ملفات الحزمة داخل مجلد واحد (MotoPartsPOS/…) يُحذف اسمه من المسارات. */
function updater_common_prefix(array $names): string
{
    $prefix = null;
    foreach ($names as $name) {
        $name = str_replace('\\', '/', $name);
        $slash = strpos($name, '/');
        if ($slash === false) {
            return '';
        }
        $segment = substr($name, 0, $slash + 1);
        if ($prefix === null) {
            $prefix = $segment;
        } elseif ($segment !== $prefix) {
            return '';
        }
    }
    return (string) $prefix;
}

/**
 * يعيد التسمية مع محاولات قصيرة: على Windows قد يكون الملف مفتوحاً للحظة من طلب آخر.
 * الملف الذي يُنفَّذ الآن (updater/apply_update.php نفسه) تُبقيه PHP مفتوحاً حتى نهاية الطلب، فيرفض Windows
 * إعادة التسمية فوقه لكنه يقبل الكتابة داخله: PHP ترجمته بالفعل، فالكتابة في مكانه آمنة.
 */
function updater_replace(string $tmp, string $target): bool
{
    for ($i = 0; $i < 5; $i++) {
        if (@rename($tmp, $target)) {
            return true;
        }
        usleep(150000);
    }
    $data = @file_get_contents($tmp);
    if ($data !== false && @file_put_contents($target, $data) === strlen($data)) {
        @unlink($tmp);
        return true;
    }
    return false;
}

/**
 * يثبّت حزمة تحقّق المتصل من بصمتها وتوقيعها مسبقاً.
 *
 * 1. يرفض أي مسار غير آمن، ويتجاهل المسارات المحمية (config/local.php و storage/) والملفات التي لم تتغير.
 * 2. نسخة SQL احتياطية لقاعدة البيانات + نسخة من كل ملف سيُستبدل.
 * 3. الاستبدال ملفاً ملفاً (كتابة باسم مؤقت ثم إعادة تسمية)، ثم opcache_reset، ثم الترحيلات الإضافية.
 * 4. أي فشل في الخطوة 3 يعيد الملفات السابقة ويحذف الملفات الجديدة.
 *
 * @return array{files:int, unchanged:int, migrations:string[], file_backup:string, db_backup:string}
 */
function updater_install(string $zipPath): array
{
    $zip = new ZipFile($zipPath);
    $names = $zip->names();
    $prefix = updater_common_prefix($names);
    $files = [];
    foreach ($names as $name) {
        $rel = str_replace('\\', '/', $name);
        if ($prefix !== '') {
            $rel = (string) substr($rel, strlen($prefix));
        }
        if ($rel === '' || substr($rel, -1) === '/') {
            continue;
        }
        if (strpos($rel, '..') !== false || $rel[0] === '/' || strpos($rel, ':') !== false || strpos($rel, "\0") !== false) {
            $zip->close();
            throw new UserError('حزمة التحديث تحتوي مساراً غير آمن: ' . $rel);
        }
        if (!updater_is_protected($rel)) {
            $files[$rel] = $name;
        }
    }
    if (!isset($files['index.php'], $files['config/version.php'])) {
        $zip->close();
        throw new UserError('حزمة التحديث ناقصة: لا تحتوي index.php أو config/version.php.');
    }

    $contents = [];
    $unchanged = 0;
    foreach ($files as $rel => $name) {
        $data = $zip->read($name);
        if ($data === null) {
            $zip->close();
            throw new UserError('تعذر قراءة ' . $rel . ' من حزمة التحديث. لم يُغيَّر أي ملف.');
        }
        $target = APP_ROOT . '/' . $rel;
        if (is_file($target) && hash_file('sha256', $target) === hash('sha256', $data)) {
            $unchanged++;
            continue;
        }
        $contents[$rel] = $data;
    }
    $zip->close();

    $stamp = date('Ymd-His');
    $backupDir = storage_path('updates') . '/backup-' . APP_VERSION . '-' . $stamp;
    $dbBackup = backup_database(db(), storage_path('backups'));
    $replaced = [];
    $created = [];
    foreach ($contents as $rel => $data) {
        $target = APP_ROOT . '/' . $rel;
        if (is_file($target)) {
            $copy = $backupDir . '/' . $rel;
            if ((!is_dir(dirname($copy)) && !mkdir(dirname($copy), 0775, true)) || !copy($target, $copy)) {
                throw new UserError('تعذر أخذ نسخة احتياطية من ' . $rel . '. لم يُغيَّر أي ملف.');
            }
            $replaced[] = $rel;
        } else {
            $created[] = $rel;
        }
    }

    try {
        foreach ($contents as $rel => $data) {
            $target = APP_ROOT . '/' . $rel;
            if (!is_dir(dirname($target)) && !mkdir(dirname($target), 0775, true)) {
                throw new RuntimeException('تعذر إنشاء مجلد ' . dirname($rel));
            }
            $tmp = $target . '.upd-' . $stamp;
            if (file_put_contents($tmp, $data) === false || !updater_replace($tmp, $target)) {
                @unlink($tmp);
                throw new RuntimeException('تعذر كتابة ' . $rel);
            }
        }
        if (function_exists('opcache_reset')) {
            opcache_reset();
        }
        $migrations = run_migrations(db());
    } catch (Throwable $e) {
        foreach ($replaced as $rel) {
            @copy($backupDir . '/' . $rel, APP_ROOT . '/' . $rel);
        }
        foreach ($created as $rel) {
            @unlink(APP_ROOT . '/' . $rel);
        }
        if (function_exists('opcache_reset')) {
            opcache_reset();
        }
        error_log('[update] ' . $e);
        throw new UserError('فشل التحديث وأُعيدت الملفات السابقة. نسخة قاعدة البيانات قبل التحديث: '
            . basename($dbBackup['file']) . ' — السبب: ' . $e->getMessage(), 500);
    }

    return [
        'files'       => count($contents),
        'unchanged'   => $unchanged,
        'migrations'  => $migrations,
        'file_backup' => basename($backupDir),
        'db_backup'   => basename($dbBackup['file']),
    ];
}
