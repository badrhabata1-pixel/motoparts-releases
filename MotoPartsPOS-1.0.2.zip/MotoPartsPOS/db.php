<?php
// نُقلت إعدادات الاتصال إلى config/db.php. هذا الملف باقٍ للتوافق فقط: يوفّر $pdo كما كان.
require_once __DIR__ . '/config/db.php';

$pdo = db();
