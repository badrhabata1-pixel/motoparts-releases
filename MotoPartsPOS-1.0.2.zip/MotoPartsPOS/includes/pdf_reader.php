<?php
/**
 * قارئ PDF صغير بلا مكتبات ولا أدوات خارجية، يعمل على الخادم المدمج (PHP + zlib فقط):
 * الكائنات وجداولها (xref تقليدي أو مضغوط، وكائنات داخل ObjStm)، فك FlateDecode، الخطوط
 * (Type0/Identity-H أو بسيطة، مع ToUnicode والعرض)، ومحرك نص يعيد كل حرف بموضعه على الصفحة.
 *
 * لا يستخرج نصاً "مرتباً": ملفات "Microsoft: Print To PDF" ترسم العربي حرفاً حرفاً بلا ترتيب منطقي،
 * فالترتيب والأعمدة يحسبها includes/pdf_invoice.php من المواضع. منقول من tools/pdf_invoices_extract.py.
 */

final class PdfRef
{
    /** @var int */
    public $num;

    public function __construct(int $num)
    {
        $this->num = $num;
    }
}

final class PdfString
{
    /** @var string البايتات كما في الملف */
    public $bytes;

    public function __construct(string $bytes)
    {
        $this->bytes = $bytes;
    }
}

final class PdfDict
{
    /** @var array المفاتيح بلا "/" */
    public $items;
    /** @var string|null بيانات الـ stream الخام (قبل فك الضغط) */
    public $stream;

    public function __construct(array $items)
    {
        $this->items = $items;
    }

    public function get(string $key, $default = null)
    {
        return $this->items[$key] ?? $default;
    }
}

/**
 * محلل رموز PDF: يُستخدم للكائنات ولتدفقات الرسم معاً. الأسماء تُعاد "/Name"، والنصوص PdfString،
 * والمفاتيح (عوامل الرسم وobj وR...) نصوصاً عادية.
 */
final class PdfLexer
{
    const SPACE = "\x00\t\n\x0c\r ";
    const STOP = "\x00\t\n\x0c\r ()<>[]{}/%";

    /** @var string */
    private $s;
    /** @var int */
    public $pos;
    /** @var int */
    private $len;

    public function __construct(string $s, int $pos = 0)
    {
        $this->s = $s;
        $this->pos = $pos;
        $this->len = strlen($s);
    }

    /** الرمز التالي: [النوع، القيمة] أو null في النهاية. الأنواع: n name str [ ] << >> kw */
    public function next(): ?array
    {
        $s = $this->s;
        while ($this->pos < $this->len) {
            $this->pos += strspn($s, self::SPACE, $this->pos);
            if ($this->pos < $this->len && $s[$this->pos] === '%') {
                $this->pos += strcspn($s, "\r\n", $this->pos);
                continue;
            }
            break;
        }
        if ($this->pos >= $this->len) {
            return null;
        }
        $c = $s[$this->pos];
        if ($c === '/') {
            $n = strcspn($s, self::STOP, $this->pos + 1);
            $name = substr($s, $this->pos + 1, $n);
            $this->pos += 1 + $n;
            if (strpos($name, '#') !== false) {
                $name = preg_replace_callback('/#([0-9A-Fa-f]{2})/', function ($m) { return chr(hexdec($m[1])); }, $name);
            }
            return ['name', $name];
        }
        if ($c === '(') {
            return ['str', $this->literal()];
        }
        if ($c === '<') {
            if (($s[$this->pos + 1] ?? '') === '<') {
                $this->pos += 2;
                return ['<<', null];
            }
            $end = strpos($s, '>', $this->pos);
            if ($end === false) {
                $end = $this->len;
            }
            $hex = preg_replace('/[^0-9A-Fa-f]/', '', substr($s, $this->pos + 1, $end - $this->pos - 1));
            if (strlen($hex) % 2) {
                $hex .= '0';
            }
            $this->pos = $end + 1;
            return ['str', (string) hex2bin($hex)];
        }
        if ($c === '>' && ($s[$this->pos + 1] ?? '') === '>') {
            $this->pos += 2;
            return ['>>', null];
        }
        if ($c === '[' || $c === ']') {
            $this->pos++;
            return [$c, null];
        }
        $n = strcspn($s, self::STOP, $this->pos);
        if ($n === 0) {
            $this->pos++;                                   // محرف شاذ مثل ")" أو "{" منفرد
            return ['kw', $c];
        }
        $tok = substr($s, $this->pos, $n);
        $this->pos += $n;
        if (preg_match('/^[+-]?(\d+\.?\d*|\.\d+)$/', $tok)) {
            return ['n', strpbrk($tok, '.') === false ? (int) $tok : (float) $tok];
        }
        return ['kw', $tok];
    }

    /** صورة مضمّنة في الرسم (BI ... ID بيانات EI): بياناتها ثنائية فتُتخطى كلها حتى EI. */
    public function skipInlineImage(): void
    {
        while (($t = $this->next()) !== null && !($t[0] === 'kw' && $t[1] === 'ID')) {
        }
        if (preg_match('/\sEI(?=[\s\/\[<(]|$)/', $this->s, $m, PREG_OFFSET_CAPTURE, $this->pos + 1)) {
            $this->pos = $m[0][1] + strlen($m[0][0]);
        } else {
            $this->pos = $this->len;
        }
    }

    /** نص بين قوسين مع التهريب والأقواس المتداخلة. */
    private function literal(): string
    {
        static $escapes = ['n' => "\n", 'r' => "\r", 't' => "\t", 'b' => "\x08", 'f' => "\x0c", '(' => '(', ')' => ')', '\\' => '\\'];
        $s = $this->s;
        $i = $this->pos + 1;
        $depth = 1;
        $out = '';
        while ($i < $this->len) {
            $chunk = strcspn($s, '\\()', $i);
            $out .= substr($s, $i, $chunk);
            $i += $chunk;
            if ($i >= $this->len) {
                break;
            }
            $c = $s[$i];
            if ($c === '\\') {
                $e = $s[$i + 1] ?? '';
                if (isset($escapes[$e])) {
                    $out .= $escapes[$e];
                    $i += 2;
                } elseif ($e === "\r" || $e === "\n") {
                    $i += ($e === "\r" && ($s[$i + 2] ?? '') === "\n") ? 3 : 2;
                } elseif (preg_match('/\G[0-7]{1,3}/', $s, $m, 0, $i + 1)) {
                    $out .= chr(octdec($m[0]) & 0xFF);
                    $i += 1 + strlen($m[0]);
                } else {
                    $out .= $e;
                    $i += 2;
                }
                continue;
            }
            if ($c === '(') {
                $depth++;
            } elseif (--$depth === 0) {
                $i++;
                break;
            }
            $out .= $c;
            $i++;
        }
        $this->pos = $i;
        return $out;
    }

    /** قيمة كاملة تبدأ بالرمز $tok (أو بالرمز التالي): عدد، مرجع "N G R"، اسم، نص، مصفوفة، قاموس. */
    public function value(?array $tok = null)
    {
        $tok = $tok ?? $this->next();
        if ($tok === null) {
            return null;
        }
        switch ($tok[0]) {
            case 'n':
                if (is_int($tok[1])) {
                    $save = $this->pos;
                    $gen = $this->next();
                    if ($gen !== null && $gen[0] === 'n' && is_int($gen[1])) {
                        $r = $this->next();
                        if ($r !== null && $r[0] === 'kw' && $r[1] === 'R') {
                            return new PdfRef($tok[1]);
                        }
                    }
                    $this->pos = $save;
                }
                return $tok[1];
            case 'name':
                return '/' . $tok[1];
            case 'str':
                return new PdfString($tok[1]);
            case '[':
                $list = [];
                while (($t = $this->next()) !== null && $t[0] !== ']') {
                    $list[] = $this->value($t);
                }
                return $list;
            case '<<':
                $dict = [];
                while (($t = $this->next()) !== null && $t[0] !== '>>') {
                    if ($t[0] === 'name') {
                        $dict[$t[1]] = $this->value();
                    }
                }
                return new PdfDict($dict);
            case 'kw':
                if ($tok[1] === 'true' || $tok[1] === 'false') {
                    return $tok[1] === 'true';
                }
                return $tok[1] === 'null' ? null : $tok[1];
        }
        return null;
    }
}

final class PdfDocument
{
    /** @var string */
    private $data;
    /** @var array<int, int|array{0:int,1:int}> رقم الكائن ← موضعه، أو [رقم ObjStm، ترتيبه داخله] */
    private $xref = [];
    /** @var array<int, mixed> */
    private $cache = [];
    /** @var array<int, array<int, mixed>> */
    private $objStreams = [];
    /** @var PdfDict|null */
    private $trailer;

    public static function open(string $path): self
    {
        $doc = new self();
        $doc->data = (string) file_get_contents($path);
        $start = strpos(substr($doc->data, 0, 1024), '%PDF-');
        if ($start === false) {
            throw new UserError('الملف ليس PDF صالحاً.');
        }
        if (!$doc->readXref()) {
            $doc->scanObjects();
        }
        if (!$doc->trailer || !$doc->trailer->get('Root')) {
            throw new UserError('ملف PDF تالف: لا يمكن العثور على فهرس صفحاته.');
        }
        if ($doc->trailer->get('Encrypt') !== null) {
            throw new UserError('ملف PDF محمي أو مشفّر فلا يمكن قراءته. اطبعه إلى PDF من جديد بلا حماية.');
        }
        return $doc;
    }

    public function resolve($value)
    {
        $guard = 0;
        while ($value instanceof PdfRef && $guard++ < 32) {
            $value = $this->get($value->num);
        }
        return $value;
    }

    public function get(int $num)
    {
        if (array_key_exists($num, $this->cache)) {
            return $this->cache[$num];
        }
        $this->cache[$num] = null;                      // يمنع الحلقات في ملف تالف
        $where = $this->xref[$num] ?? null;
        if (is_int($where)) {
            $this->cache[$num] = $this->objectAt($where);
        } elseif (is_array($where)) {
            $this->cache[$num] = $this->fromObjectStream($where[0], $where[1]);
        }
        return $this->cache[$num];
    }

    /** "N G obj <قيمة> [stream ... endstream]" عند الموضع. */
    private function objectAt(int $offset)
    {
        $lx = new PdfLexer($this->data, $offset);
        $num = $lx->next();
        $gen = $lx->next();
        $kw = $lx->next();
        if (!$num || !$gen || !$kw || $num[0] !== 'n' || $gen[0] !== 'n' || $kw[1] !== 'obj') {
            return null;
        }
        $value = $lx->value();
        if ($value instanceof PdfDict) {
            $save = $lx->pos;
            $t = $lx->next();
            if ($t !== null && $t[0] === 'kw' && $t[1] === 'stream') {
                $pos = $lx->pos;
                if (($this->data[$pos] ?? '') === "\r") {
                    $pos++;
                }
                if (($this->data[$pos] ?? '') === "\n") {
                    $pos++;
                }
                $length = $this->resolve($value->get('Length'));
                $end = is_int($length) ? $pos + $length : -1;
                if ($end < 0 || substr($this->data, $end, 30) === '' || strpos(substr($this->data, $end, 30), 'endstream') === false) {
                    $found = strpos($this->data, 'endstream', $pos);       // طول خاطئ أو غائب
                    $end = $found === false ? strlen($this->data) : $found;
                    while ($end > $pos && strpos("\r\n", $this->data[$end - 1]) !== false) {
                        $end--;
                    }
                }
                $value->stream = substr($this->data, $pos, $end - $pos);
            } else {
                $lx->pos = $save;
            }
        }
        return $value;
    }

    private function fromObjectStream(int $streamNum, int $index)
    {
        if (!isset($this->objStreams[$streamNum])) {
            $this->objStreams[$streamNum] = [];
            $st = $this->get($streamNum);
            if ($st instanceof PdfDict && $st->stream !== null) {
                $data = $this->streamData($st);
                $lx = new PdfLexer($data);
                $pairs = [];
                for ($i = 0, $n = (int) $st->get('N', 0); $i < $n; $i++) {
                    $pairs[] = [$lx->next()[1] ?? 0, $lx->next()[1] ?? 0];
                }
                $first = (int) $st->get('First', 0);
                foreach ($pairs as $k => [$objNum, $off]) {
                    $vx = new PdfLexer($data, $first + (int) $off);
                    $this->objStreams[$streamNum][$k] = $vx->value();
                }
            }
        }
        return $this->objStreams[$streamNum][$index] ?? null;
    }

    /** جدول الكائنات من startxref: تقليدي أو XRef stream، مع سلسلة Prev (الأحدث يتقدم). */
    private function readXref(): bool
    {
        $at = strrpos($this->data, 'startxref');
        if ($at === false || !preg_match('/\G\s*(\d+)/', $this->data, $m, 0, $at + 9)) {
            return false;
        }
        $offset = (int) $m[1];
        $seen = [];
        while ($offset > 0 && $offset < strlen($this->data) && !isset($seen[$offset])) {
            $seen[$offset] = true;
            $section = null;
            if (substr($this->data, $offset, 4) === 'xref') {
                $lx = new PdfLexer($this->data, $offset + 4);
                while (($t = $lx->next()) !== null) {
                    if ($t[0] === 'kw' && $t[1] === 'trailer') {
                        $section = $lx->value();
                        break;
                    }
                    $count = $lx->next();
                    if ($t[0] !== 'n' || !$count || $count[0] !== 'n') {
                        return false;
                    }
                    for ($i = 0; $i < $count[1]; $i++) {
                        $off = $lx->next();
                        $lx->next();
                        $type = $lx->next();
                        if ($off && $type && $type[1] === 'n' && !isset($this->xref[$t[1] + $i])) {
                            $this->xref[$t[1] + $i] = (int) $off[1];
                        }
                    }
                }
            } else {
                $section = $this->objectAt($offset);
                if (!$section instanceof PdfDict || $section->get('Type') !== '/XRef' || $section->stream === null) {
                    return false;
                }
                $this->xrefStream($section);
            }
            if (!$section instanceof PdfDict) {
                return false;
            }
            $this->trailer = $this->trailer ?? $section;
            if (is_int($section->get('XRefStm'))) {
                $hybrid = $this->objectAt($section->get('XRefStm'));
                if ($hybrid instanceof PdfDict && $hybrid->stream !== null) {
                    $this->xrefStream($hybrid);
                }
            }
            $offset = is_int($section->get('Prev')) ? $section->get('Prev') : 0;
        }
        return (bool) $this->xref;
    }

    private function xrefStream(PdfDict $st): void
    {
        $w = array_map('intval', (array) $st->get('W', [1, 2, 1]));
        $index = (array) $st->get('Index', [0, (int) $st->get('Size', 0)]);
        $data = $this->streamData($st);
        $row = array_sum($w);
        $p = 0;
        for ($k = 0; $k + 1 < count($index); $k += 2) {
            for ($i = 0; $i < (int) $index[$k + 1] && $p + $row <= strlen($data); $i++) {
                $f = [];
                foreach ($w as $j => $size) {
                    $v = 0;
                    for ($b = 0; $b < $size; $b++) {
                        $v = ($v << 8) | ord($data[$p++]);
                    }
                    $f[$j] = $size === 0 && $j === 0 ? 1 : $v;
                }
                $num = (int) $index[$k] + $i;
                if (isset($this->xref[$num])) {
                    continue;
                }
                if ($f[0] === 1) {
                    $this->xref[$num] = $f[1];
                } elseif ($f[0] === 2) {
                    $this->xref[$num] = [$f[1], $f[2]];
                }
            }
        }
    }

    /** ملف بلا جدول سليم: مواضع "N G obj" بالبحث المباشر، والجذر من آخر trailer أو XRef. */
    private function scanObjects(): void
    {
        preg_match_all('/(?<![0-9])(\d+)\s+\d+\s+obj\b/', $this->data, $m, PREG_OFFSET_CAPTURE);
        foreach ($m[1] as $k => [$num]) {
            $this->xref[(int) $num] = $m[0][$k][1];
        }
        $at = strrpos($this->data, 'trailer');
        if ($at !== false) {
            $lx = new PdfLexer($this->data, $at + 7);
            $tr = $lx->value();
            if ($tr instanceof PdfDict) {
                $this->trailer = $tr;
                return;
            }
        }
        foreach (array_keys($this->xref) as $num) {
            $obj = $this->get($num);
            if ($obj instanceof PdfDict && $obj->get('Type') === '/XRef') {
                $this->trailer = $obj;
            } elseif ($obj instanceof PdfDict && $obj->get('Type') === '/ObjStm') {
                $this->objStreamMembers($num, $obj);
            }
        }
        if (!$this->trailer) {
            foreach ($this->xref as $num => $where) {
                $obj = $this->get($num);
                if ($obj instanceof PdfDict && $obj->get('Type') === '/Catalog') {
                    $this->trailer = new PdfDict(['Root' => new PdfRef($num)]);
                    break;
                }
            }
        }
    }

    private function objStreamMembers(int $num, PdfDict $st): void
    {
        $lx = new PdfLexer($this->streamData($st));
        for ($i = 0, $n = (int) $st->get('N', 0); $i < $n; $i++) {
            $objNum = $lx->next()[1] ?? null;
            $lx->next();
            if (is_int($objNum) && !isset($this->xref[$objNum])) {
                $this->xref[$objNum] = [$num, $i];
            }
        }
    }

    /** بيانات الـ stream بعد المرشحات: FlateDecode (مع متنبئ PNG)، ASCIIHex، ASCII85. */
    public function streamData(PdfDict $st): string
    {
        $data = (string) $st->stream;
        $filters = $this->resolve($st->get('Filter'));
        $filters = is_array($filters) ? $filters : ($filters === null ? [] : [$filters]);
        $params = $this->resolve($st->get('DecodeParms'));
        $params = is_array($params) ? $params : [$params];
        foreach (array_values($filters) as $k => $filter) {
            $filter = $this->resolve($filter);
            $p = $this->resolve($params[$k] ?? null);
            if ($filter === '/FlateDecode' || $filter === '/Fl') {
                $data = self::inflate($data);
                if ($p instanceof PdfDict && (int) $this->resolve($p->get('Predictor', 1)) >= 10) {
                    $data = self::unpredict($data, (int) $this->resolve($p->get('Columns', 1)) * max(1, (int) $this->resolve($p->get('Colors', 1)))
                        * max(1, (int) $this->resolve($p->get('BitsPerComponent', 8))) / 8);
                }
            } elseif ($filter === '/ASCIIHexDecode' || $filter === '/AHx') {
                $hex = preg_replace('/[^0-9A-Fa-f]/', '', strstr($data, '>', true) ?: $data);
                $data = (string) hex2bin(strlen($hex) % 2 ? $hex . '0' : $hex);
            } elseif ($filter === '/ASCII85Decode' || $filter === '/A85') {
                $data = self::ascii85($data);
            } else {
                throw new UserError('ملف PDF يستخدم ضغطاً غير مدعوم (' . ltrim((string) $filter, '/') . ').');
            }
        }
        return $data;
    }

    private static function inflate(string $data): string
    {
        $out = @gzuncompress($data);
        if ($out !== false) {
            return $out;
        }
        $ctx = inflate_init(ZLIB_ENCODING_DEFLATE);
        $out = $ctx ? @inflate_add($ctx, substr($data, 2), ZLIB_SYNC_FLUSH) : false;   // تدفق بلا مجموع تحقق سليم
        if ($out === false) {
            throw new UserError('تعذر فك ضغط محتوى ملف PDF (ملف تالف).');
        }
        return $out;
    }

    /** يعكس متنبئ PNG (مرشح لكل صف). */
    private static function unpredict(string $data, int $columns): string
    {
        $columns = max(1, $columns);
        $out = '';
        $prev = str_repeat("\0", $columns);
        for ($p = 0; $p + $columns < strlen($data) + 1; $p += $columns + 1) {
            $type = ord($data[$p]);
            $row = substr($data, $p + 1, $columns);
            if (strlen($row) < $columns) {
                break;
            }
            $cur = '';
            for ($i = 0; $i < $columns; $i++) {
                $x = ord($row[$i]);
                $a = $i > 0 ? ord($cur[$i - 1]) : 0;
                $b = ord($prev[$i]);
                $c = $i > 0 ? ord($prev[$i - 1]) : 0;
                if ($type === 1) {
                    $x += $a;
                } elseif ($type === 2) {
                    $x += $b;
                } elseif ($type === 3) {
                    $x += intdiv($a + $b, 2);
                } elseif ($type === 4) {
                    $pa = abs($b - $c);
                    $pb = abs($a - $c);
                    $pc = abs($a + $b - 2 * $c);
                    $x += ($pa <= $pb && $pa <= $pc) ? $a : ($pb <= $pc ? $b : $c);
                }
                $cur .= chr($x & 0xFF);
            }
            $out .= $cur;
            $prev = $cur;
        }
        return $out;
    }

    private static function ascii85(string $data): string
    {
        $data = preg_replace('/\s+/', '', $data);
        if (substr($data, 0, 2) === '<~') {
            $data = substr($data, 2);
        }
        $end = strpos($data, '~>');
        if ($end !== false) {
            $data = substr($data, 0, $end);
        }
        $out = '';
        $group = [];
        for ($i = 0, $n = strlen($data); $i < $n; $i++) {
            if ($data[$i] === 'z' && !$group) {
                $out .= "\0\0\0\0";
                continue;
            }
            $group[] = ord($data[$i]) - 33;
            if (count($group) === 5) {
                $v = (((($group[0] * 85 + $group[1]) * 85 + $group[2]) * 85 + $group[3]) * 85 + $group[4]);
                $out .= pack('N', $v);
                $group = [];
            }
        }
        if ($group) {
            $pad = 5 - count($group);
            $group = array_pad($group, 5, 84);
            $v = (((($group[0] * 85 + $group[1]) * 85 + $group[2]) * 85 + $group[3]) * 85 + $group[4]);
            $out .= substr(pack('N', $v), 0, 4 - $pad);
        }
        return $out;
    }

    /** الصفحات بالترتيب، وكل صفحة ترث Resources من آبائها. @return PdfDict[] */
    public function pages(): array
    {
        $root = $this->resolve($this->trailer->get('Root'));
        $tree = $root instanceof PdfDict ? $this->resolve($root->get('Pages')) : null;
        $pages = [];
        $this->collectPages($tree, null, $pages, 0);
        return $pages;
    }

    private function collectPages($node, $resources, array &$pages, int $depth): void
    {
        if (!$node instanceof PdfDict || $depth > 64) {
            return;
        }
        $res = $node->get('Resources') ?? $resources;
        $kids = $this->resolve($node->get('Kids'));
        if (is_array($kids)) {
            foreach ($kids as $kid) {
                $this->collectPages($this->resolve($kid), $res, $pages, $depth + 1);
            }
            return;
        }
        $page = new PdfDict($node->items);
        $page->items['Resources'] = $res;
        $pages[] = $page;
    }

    /** محتوى الصفحة: stream واحد أو مصفوفة تُضم. */
    public function pageContent(PdfDict $page): string
    {
        $contents = $this->resolve($page->get('Contents'));
        $parts = is_array($contents) ? $contents : [$contents];
        $out = '';
        foreach ($parts as $part) {
            $part = $this->resolve($part);
            if ($part instanceof PdfDict && $part->stream !== null) {
                $out .= $this->streamData($part) . "\n";
            }
        }
        return $out;
    }
}

final class PdfFont
{
    /** @var bool رموز من بايتين (Type0) أو بايت واحد (خط بسيط) */
    public $twoByte;
    /** @var array<int, float> */
    private $widths = [];
    /** @var float */
    private $defaultWidth = 1000.0;
    /** @var array<int, string> الرمز ← النص */
    public $unicode = [];
    /** @var float عرض المسافة بوحدات الخط (1/1000) */
    public $spaceWidth = 250.0;

    public static function load(PdfDocument $doc, $ref): self
    {
        $f = $doc->resolve($ref);
        if (!$f instanceof PdfDict) {
            throw new UserError('ملف PDF به خط تالف.');
        }
        $font = new self();
        $subtype = $f->get('Subtype');
        if ($subtype === '/Type0') {
            if ($doc->resolve($f->get('Encoding')) !== '/Identity-H') {
                throw new UserError('ملف PDF يستخدم ترميز خط غير مدعوم (' . ltrim((string) $doc->resolve($f->get('Encoding')), '/') . ').');
            }
            $font->twoByte = true;
            $desc = $doc->resolve(($doc->resolve($f->get('DescendantFonts')) ?: [null])[0]);
            if ($desc instanceof PdfDict) {
                $font->defaultWidth = (float) $doc->resolve($desc->get('DW', 1000));
                $w = $doc->resolve($desc->get('W'));
                $w = is_array($w) ? $w : [];
                for ($i = 0; $i < count($w);) {
                    $first = (int) $doc->resolve($w[$i]);
                    $next = $doc->resolve($w[$i + 1] ?? null);
                    if (is_array($next)) {
                        foreach ($next as $k => $v) {
                            $font->widths[$first + $k] = (float) $doc->resolve($v);
                        }
                        $i += 2;
                    } else {
                        $value = (float) $doc->resolve($w[$i + 2] ?? 0);
                        for ($cid = $first; $cid <= (int) $next; $cid++) {
                            $font->widths[$cid] = $value;
                        }
                        $i += 3;
                    }
                }
            }
        } elseif (in_array($subtype, ['/TrueType', '/Type1', '/MMType1'], true)) {
            $font->twoByte = false;
            $first = (int) $doc->resolve($f->get('FirstChar', 0));
            $w = $doc->resolve($f->get('Widths'));
            foreach (is_array($w) ? $w : [] as $k => $v) {
                $font->widths[$first + $k] = (float) $doc->resolve($v);
            }
            $font->defaultWidth = 0.0;
            for ($c = 32; $c < 256; $c++) {
                $font->unicode[$c] = mb_convert_encoding(chr($c), 'UTF-8', 'Windows-1252');
            }
        } else {
            throw new UserError('ملف PDF يستخدم نوع خط غير مدعوم (' . ltrim((string) $subtype, '/') . ').');
        }
        $map = $doc->resolve($f->get('ToUnicode'));
        if ($map instanceof PdfDict && $map->stream !== null) {
            $font->unicode = self::parseToUnicode($doc->streamData($map)) + ($font->twoByte ? [] : $font->unicode);
        }
        // عرض المسافة: الرمز الذي يقابل " " في الخط، وإلا الرمز 3 (المسافة في خطوط Print To PDF) أو 32.
        $space = array_search(' ', $font->unicode, true);
        $code = $space !== false ? (int) $space : ($font->twoByte ? 3 : 32);
        $font->spaceWidth = $font->widths[$code] ?? 250.0;
        return $font;
    }

    public function width(int $code): float
    {
        return ($this->widths[$code] ?? $this->defaultWidth) / 1000.0;
    }

    /** خريطة ToUnicode: bfchar و bfrange (بقيمة بداية أو بمصفوفة). */
    private static function parseToUnicode(string $cmap): array
    {
        $out = [];
        $utf16 = function (string $hex): string {
            $bin = (string) hex2bin(strlen($hex) % 2 ? '0' . $hex : $hex);
            return (string) mb_convert_encoding($bin, 'UTF-8', 'UTF-16BE');
        };
        if (preg_match_all('/beginbfchar(.*?)endbfchar/s', $cmap, $blocks)) {
            foreach ($blocks[1] as $block) {
                preg_match_all('/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>/', $block, $m, PREG_SET_ORDER);
                foreach ($m as [, $src, $dst]) {
                    $out[hexdec($src)] = $utf16($dst);
                }
            }
        }
        if (preg_match_all('/beginbfrange(.*?)endbfrange/s', $cmap, $blocks)) {
            foreach ($blocks[1] as $block) {
                preg_match_all('/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*(\[[^\]]*\]|<[0-9A-Fa-f]+>)/', $block, $m, PREG_SET_ORDER);
                foreach ($m as [, $lo, $hi, $rest]) {
                    $lo = hexdec($lo);
                    $hi = hexdec($hi);
                    if ($rest[0] === '[') {
                        preg_match_all('/<([0-9A-Fa-f]+)>/', $rest, $dst);
                        foreach ($dst[1] as $i => $hex) {
                            $out[$lo + $i] = $utf16($hex);
                        }
                        continue;
                    }
                    $base = substr($rest, 1, -1);
                    $len = strlen($base);
                    $start = hexdec($base);
                    for ($i = 0; $i <= $hi - $lo && $i < 65536; $i++) {
                        $out[$lo + $i] = $utf16(str_pad(dechex($start + $i), $len, '0', STR_PAD_LEFT));
                    }
                }
            }
        }
        return $out;
    }
}

/**
 * كل حرف في الصفحة بموضعه: [y, x0, x1, النص، عرض المسافة في موضعه] بإحداثيات PDF (نقاط، y لأعلى).
 * يتبع عوامل النص والمصفوفات كما في مواصفة PDF: q Q cm BT Tf Tc Tw Tz Ts TL Td TD Tm T* Tj TJ ' ".
 */
function pdf_page_glyphs(PdfDocument $doc, PdfDict $page): array
{
    $resources = $doc->resolve($page->get('Resources'));
    $fontDict = $resources instanceof PdfDict ? $doc->resolve($resources->get('Font')) : null;
    $loaded = [];
    $font = null;

    $ctm = [1.0, 0.0, 0.0, 1.0, 0.0, 0.0];
    $stack = [];
    $tm = $tlm = [1.0, 0.0, 0.0, 1.0, 0.0, 0.0];
    $size = 0.0;
    $tc = 0.0;
    $th = 1.0;
    $rise = 0.0;
    $leading = 0.0;
    $glyphs = [];

    $mul = function (array $m, array $n): array {
        return [$m[0] * $n[0] + $m[1] * $n[2], $m[0] * $n[1] + $m[1] * $n[3], $m[2] * $n[0] + $m[3] * $n[2],
                $m[2] * $n[1] + $m[3] * $n[3], $m[4] * $n[0] + $m[5] * $n[2] + $n[4], $m[4] * $n[1] + $m[5] * $n[3] + $n[5]];
    };
    $show = function (string $bytes) use (&$tm, &$ctm, &$font, &$size, &$tc, &$th, &$rise, &$glyphs, $mul): void {
        if ($font === null) {
            throw new UserError('ملف PDF به نص بلا خط محدد.');
        }
        $step = $font->twoByte ? 2 : 1;
        for ($k = 0, $n = strlen($bytes) - $step + 1; $k < $n; $k += $step) {
            $code = $step === 2 ? (ord($bytes[$k]) << 8) | ord($bytes[$k + 1]) : ord($bytes[$k]);
            $adv = ($font->width($code) * $size + $tc) * $th;
            $m = $mul([1.0, 0.0, 0.0, 1.0, 0.0, $rise], $mul($tm, $ctm));
            $x0 = $m[4];
            $y0 = $m[5];
            $x1 = $adv * $m[0] + $m[4];
            $glyphs[] = [$y0, min($x0, $x1), max($x0, $x1), $font->unicode[$code] ?? "\u{FFFD}", $font->spaceWidth / 1000.0 * $size * abs($m[0])];
            $tm = $mul([1.0, 0.0, 0.0, 1.0, $adv, 0.0], $tm);
        }
    };

    $lx = new PdfLexer($doc->pageContent($page));
    $operands = [];
    while (($t = $lx->next()) !== null) {
        if ($t[0] !== 'kw' || $t[1] === 'true' || $t[1] === 'false' || $t[1] === 'null') {
            $operands[] = $lx->value($t);
            continue;
        }
        $op = $t[1];
        $o = $operands;
        $operands = [];
        switch ($op) {
            case 'q':
                $stack[] = $ctm;
                break;
            case 'Q':
                $ctm = $stack ? array_pop($stack) : [1.0, 0.0, 0.0, 1.0, 0.0, 0.0];
                break;
            case 'cm':
                if (count($o) >= 6) {
                    $ctm = $mul(array_map('floatval', array_slice($o, -6)), $ctm);
                }
                break;
            case 'BT':
                $tm = $tlm = [1.0, 0.0, 0.0, 1.0, 0.0, 0.0];
                break;
            case 'Tf':
                $name = ltrim((string) ($o[0] ?? ''), '/');
                if (!isset($loaded[$name])) {
                    $ref = $fontDict instanceof PdfDict ? $fontDict->get($name) : null;
                    $loaded[$name] = $ref === null ? null : PdfFont::load($doc, $ref);
                }
                $font = $loaded[$name];
                $size = (float) ($o[1] ?? 0);
                break;
            case 'Tc':
                $tc = (float) ($o[0] ?? 0);
                break;
            case 'Tz':
                $th = (float) ($o[0] ?? 100) / 100.0;
                break;
            case 'Ts':
                $rise = (float) ($o[0] ?? 0);
                break;
            case 'TL':
                $leading = (float) ($o[0] ?? 0);
                break;
            case 'Td':
            case 'TD':
                $ty = (float) ($o[1] ?? 0);
                if ($op === 'TD') {
                    $leading = -$ty;
                }
                $tlm = $mul([1.0, 0.0, 0.0, 1.0, (float) ($o[0] ?? 0), $ty], $tlm);
                $tm = $tlm;
                break;
            case 'Tm':
                if (count($o) >= 6) {
                    $tlm = $tm = array_map('floatval', array_slice($o, -6));
                }
                break;
            case 'T*':
                $tlm = $mul([1.0, 0.0, 0.0, 1.0, 0.0, -$leading], $tlm);
                $tm = $tlm;
                break;
            case 'Tj':
                if (($o[0] ?? null) instanceof PdfString) {
                    $show($o[0]->bytes);
                }
                break;
            case 'TJ':
                foreach (is_array($o[0] ?? null) ? $o[0] : [] as $part) {
                    if ($part instanceof PdfString) {
                        $show($part->bytes);
                    } elseif (is_int($part) || is_float($part)) {
                        $tm = $mul([1.0, 0.0, 0.0, 1.0, -$part / 1000.0 * $size * $th, 0.0], $tm);
                    }
                }
                break;
            case "'":
            case '"':
                $tlm = $mul([1.0, 0.0, 0.0, 1.0, 0.0, -$leading], $tlm);
                $tm = $tlm;
                $last = end($o);
                if ($last instanceof PdfString) {
                    $show($last->bytes);
                }
                break;
            case 'BI':
                $lx->skipInlineImage();
                break;
        }
    }
    return $glyphs;
}
