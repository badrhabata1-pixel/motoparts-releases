<?php
/**
 * تسجيل الدخول والجلسات.
 *
 * - bootstrap.php يستدعي auth_require() لكل صفحة وكل API: بلا جلسة صالحة تُحوَّل الصفحة إلى login.php،
 *   ويرد الـ API بـ 401 ورمز auth فيفتح assets/js/app.js صفحة الدخول. الاستثناء صريح فقط: الملف يعرّف
 *   PUBLIC_PAGE قبل bootstrap (login.php، logout.php، install.php الذي له قاعدته الخاصة).
 * - ملفات الجلسات في storage/sessions: لا تُخدم عبر HTTP ولا يمسها التحديث، وتعمل كما هي على XAMPP والخادم المدمج.
 * - كوكي الجلسة بلا مدة: إغلاق نافذة البرنامج يُنهي الجلسة، وكذلك AUTH_IDLE_MINUTES بلا استخدام.
 * - الطلبات العادية تقرأ الجلسة وتغلقها فوراً (read_and_close): ملف الجلسة لا يبقى مقفلاً، فبحث الماسح
 *   لا ينتظر استيراداً أو نسخة احتياطية تعمل في طلب آخر.
 */

const AUTH_COOKIE = 'MPPOS_SID';
const AUTH_MAX_FAILS = 5;          // محاولات خاطئة متتالية...
const AUTH_LOCK_SECONDS = 60;      // ...ثم انتظار دقيقة قبل المحاولة التالية
const AUTH_TOUCH_SECONDS = 300;    // وقت آخر استخدام يُكتب في الجلسة كل 5 دقائق على الأكثر، لا مع كل طلب
// بصمة لكلمة عشوائية لا يعرفها أحد: تُفحص عند اسم مستخدم غير موجود، فلا يكشف زمن الرد أي الأسماء مسجلة.
const AUTH_DUMMY_HASH = '$2y$10$AGmbrnGFU9ns7KdTsyuuEOfvvHjmTkw77qvuxg0Eq2Xv1YMhj9tkS';

function auth_idle_seconds(): int
{
    return max(5, (int) AUTH_IDLE_MINUTES) * 60;
}

/** يفتح الجلسة. $write = false: قراءة ثم إغلاق فوري دون قفل الملف. */
function auth_session(bool $write = false): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    ini_set('session.save_path', storage_path('sessions'));
    // الحذف التلقائي لملفات الجلسات القديمة بعد مدة الخمول، لا بعد 24 دقيقة (قيمة PHP الافتراضية).
    ini_set('session.gc_maxlifetime', (string) (auth_idle_seconds() + 3600));
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_lifetime', '0');
    ini_set('session.cookie_path', '/');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Strict');
    session_name(AUTH_COOKIE);
    session_start($write ? [] : ['read_and_close' => true]);
}

/**
 * حالة الطلب الحالي، تُحسب مرة واحدة: ['ok', المستخدم] أو ['expired', null] أو ['none', null].
 * الجلسة التي تجاوزت مدة الخمول يُحذف منها المستخدم هنا.
 */
function auth_state(): array
{
    static $state = null;
    if ($state !== null) {
        return $state;
    }
    auth_session();
    $auth = $_SESSION['auth'] ?? null;
    if (!is_array($auth) || empty($auth['id'])) {
        return $state = ['none', null];
    }
    $idle = time() - (int) ($auth['seen'] ?? 0);
    if ($idle > auth_idle_seconds()) {
        auth_session(true);
        unset($_SESSION['auth']);
        session_write_close();
        return $state = ['expired', null];
    }
    if ($idle > AUTH_TOUCH_SECONDS) {
        auth_session(true);
        $_SESSION['auth']['seen'] = time();
        session_write_close();
    }
    return $state = ['ok', $auth];
}

/** @return array{id:int, username:string, role:string}|null */
function auth_user(): ?array
{
    return auth_state()[1];
}

/** وجهة ما بعد الدخول: صفحات التطبيق فقط (index.php?page=…)، فلا يُستغل الرابط للتحويل لموقع آخر. */
function auth_safe_next($next): string
{
    $next = is_string($next) ? $next : '';
    return preg_match('/^index\.php(\?page=[a-z_]{1,20})?$/', $next) ? $next : 'index.php';
}

/** بلا جلسة صالحة: الصفحة تُحوَّل إلى login.php، والـ API يرد 401 برمز auth. */
function auth_require(): void
{
    [$state] = auth_state();
    if ($state === 'ok') {
        return;
    }
    if (defined('APP_API')) {
        json_error($state === 'expired' ? 'انتهت الجلسة لعدم الاستخدام. سجّل الدخول مرة أخرى.' : 'سجّل الدخول أولاً.',
            401, ['code' => 'auth']);
    }
    $page = $_GET['page'] ?? '';
    $params = [];
    $next = auth_safe_next('index.php' . (is_string($page) && $page !== '' ? '?page=' . $page : ''));
    if ($next !== 'index.php') {
        $params['next'] = $next;
    }
    if ($state === 'expired') {
        $params['expired'] = '1';
    }
    header('Location: login.php' . ($params ? '?' . http_build_query($params) : ''));
    exit;
}

/**
 * يتحقق من اسم المستخدم وكلمة المرور ويبدأ جلسة جديدة. يعيد رسالة الخطأ بالعربية، أو null عند النجاح.
 * بعد AUTH_MAX_FAILS محاولات خاطئة متتالية يُرفض الدخول AUTH_LOCK_SECONDS ثانية. القفل للجهاز كله،
 * لأن كل الطلبات تأتي من 127.0.0.1.
 */
function auth_login(PDO $pdo, string $username, string $password): ?string
{
    $wait = auth_lock_remaining();
    if ($wait > 0) {
        return auth_lock_message($wait);
    }
    if ($username === '' || $password === '') {
        return 'أدخل اسم المستخدم وكلمة المرور.';
    }
    $row = false;
    if (strlen($password) <= 200) {
        $st = $pdo->prepare('SELECT id, username, password_hash, role FROM users WHERE username = ? LIMIT 1');
        $st->execute([$username]);
        $row = $st->fetch();
    }
    $valid = password_verify($password, $row ? (string) $row['password_hash'] : AUTH_DUMMY_HASH);
    if (!$row || !$valid) {
        $wait = auth_record_failure();
        return $wait > 0 ? auth_lock_message($wait) : 'اسم المستخدم أو كلمة المرور غير صحيحة.';
    }
    auth_clear_failures();
    if (password_needs_rehash((string) $row['password_hash'], PASSWORD_DEFAULT)) {
        $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
            ->execute([password_hash($password, PASSWORD_DEFAULT), $row['id']]);
    }

    auth_session(true);
    session_regenerate_id(true);                   // معرّف جديد بعد الدخول: معرّف ما قبل الدخول لا يصلح لشيء
    $_SESSION['auth'] = [
        'id'       => (int) $row['id'],
        'username' => (string) $row['username'],
        'role'     => (string) $row['role'],
        'at'       => time(),
        'seen'     => time(),
    ];
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
    session_write_close();
    return null;
}

function auth_logout(): void
{
    auth_session(true);
    $_SESSION = [];
    session_regenerate_id(true);                   // يحذف ملف الجلسة القديمة من storage/sessions
    session_write_close();
}

/* ───────────── رمز النماذج (CSRF) لنموذجي الدخول والخروج ───────────── */

function auth_csrf_token(): string
{
    auth_state();
    if (empty($_SESSION['csrf'])) {
        auth_session(true);
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
        session_write_close();
    }
    return (string) $_SESSION['csrf'];
}

function auth_csrf_valid($token): bool
{
    auth_state();
    return is_string($token) && !empty($_SESSION['csrf']) && hash_equals((string) $_SESSION['csrf'], $token);
}

/* ───────────── قفل مؤقت بعد المحاولات الخاطئة ───────────── */

function auth_throttle_path(): string
{
    return storage_path('tmp') . '/login_throttle.json';
}

function auth_lock_remaining(): int
{
    $path = auth_throttle_path();
    $data = is_file($path) ? json_decode((string) file_get_contents($path), true) : null;
    return max(0, (int) ($data['until'] ?? 0) - time());
}

/** يسجّل محاولة خاطئة، ويعيد ثواني الانتظار إن بلغت المحاولات الحد. */
function auth_record_failure(): int
{
    $path = auth_throttle_path();
    $data = is_file($path) ? json_decode((string) file_get_contents($path), true) : null;
    $fails = (int) ($data['fails'] ?? 0) + 1;
    $until = 0;
    if ($fails >= AUTH_MAX_FAILS) {
        $fails = 0;
        $until = time() + AUTH_LOCK_SECONDS;
    }
    file_put_contents($path, json_encode(['fails' => $fails, 'until' => $until]), LOCK_EX);
    return max(0, $until - time());
}

function auth_clear_failures(): void
{
    if (is_file(auth_throttle_path())) {
        @unlink(auth_throttle_path());
    }
}

function auth_lock_message(int $seconds): string
{
    return 'محاولات خاطئة كثيرة. انتظر ' . $seconds . ' ثانية ثم حاول مرة أخرى.';
}
