<?php
/**
 * بنود فاتورة المورد من ملف PDF، داخل الخادم المدمج بلا Python ولا أدوات خارجية.
 * منقول سطراً بسطر من tools/pdf_invoices_extract.py (الخوارزمية المختبرة على فواتير المورد)، ونتيجته مطابقة لها:
 *
 * 1. كل حرف بموضعه من الخط المضمَّن (includes/pdf_reader.php)، والصفوف حسب خط القاعدة (y).
 * 2. المسافات بين الكلمات من الفراغ الفعلي بين الحروف، لا من حروف المسافة المرسومة.
 * 3. الترتيب المرئي ← المنطقي: عكس خوارزمية Bidi لفقرة من اليمين لليسار، فلا تنعكس الحروف ولا الأرقام.
 * 4. الأعمدة من مواضع عناوين الجدول في كل صفحة (م، الصنف، الكمية، السعر، الإجمالي).
 * 5. البند = صف فيه رقم "م" وكمية واسم. ما عداه (ترويسة الصفحة، صف الإجمالي، الرصيد السابق، التوقيعات...) يُستبعد.
 * 6. فحوص اكتمال: "م" متصلة، مجموع الكميات = صف الإجمالي، الكمية × السعر = إجمالي السطر.
 */
require_once __DIR__ . '/pdf_reader.php';

const PDF_ROW_TOLERANCE = 0.6;       // نقاط: حروف السطر الواحد على خط قاعدة واحد تقريباً
const PDF_SPACE_FRACTION = 0.45;     // فراغ أكبر من 45% من عرض المسافة = مسافة بين كلمتين
const PDF_TOTAL_LABELS = ['الاجمالى', 'الاجمالي', 'الإجمالي', 'الإجمالى'];
const PDF_WHITESPACE = '\x{09}-\x{0D}\x{1C}-\x{20}\x{85}\x{A0}\x{1680}\x{2000}-\x{200A}\x{2028}\x{2029}\x{202F}\x{205F}\x{3000}';

/** str.isspace() في Python: نص غير فارغ كله مسافات (بتعريف Unicode). */
function pdf_isspace(string $s): bool
{
    return $s !== '' && preg_match('/^[' . PDF_WHITESPACE . ']+$/u', $s) === 1;
}

/** الصفوف من الأعلى للأسفل؛ الحرف يلحق بالصف إن كان على خط قاعدته تقريباً. */
function pdf_rows(array $glyphs): array
{
    usort($glyphs, function ($a, $b) { return $b[0] <=> $a[0]; });
    $rows = [];
    $last = -1;
    foreach ($glyphs as $g) {
        if ($last >= 0 && abs($rows[$last]['y'] - $g[0]) <= PDF_ROW_TOLERANCE) {
            $rows[$last]['glyphs'][] = $g;
        } else {
            $rows[] = ['y' => $g[0], 'glyphs' => [$g]];
            $last++;
        }
    }
    return $rows;
}

/** النص بالترتيب المرئي (يسار ← يمين)، والمسافات من الفراغ الفعلي بين الحروف. */
function pdf_visual_line(array $glyphs): string
{
    $ink = array_values(array_filter($glyphs, function ($g) { return !pdf_isspace($g[3]); }));
    usort($ink, function ($a, $b) { return [$a[1], $a[2]] <=> [$b[1], $b[2]]; });
    $out = '';
    $prev = null;
    foreach ($ink as $g) {
        if ($prev !== null && $g[1] - $prev[2] > PDF_SPACE_FRACTION * $g[4]) {
            $out .= ' ';
        }
        $out .= $g[3];
        $prev = $g;
    }
    return $out;
}

/**
 * صنف الحرف في خوارزمية Bidi كما يعيده unicodedata.bidirectional في Python، مختصراً إلى ما تحتاجه
 * pdf_visual_to_logical: R (عربي/عبري)، L (لاتيني)، N (أرقام EN/AN)، CS، ES، ET، وON لكل ما عداها.
 */
function pdf_bidi_class(string $ch): string
{
    $cp = mb_ord($ch, 'UTF-8');
    if ($cp === false) {
        return 'ON';
    }
    if ($cp < 0x80) {
        if ($cp >= 0x30 && $cp <= 0x39) {
            return 'N';
        }
        if (($cp >= 0x41 && $cp <= 0x5A) || ($cp >= 0x61 && $cp <= 0x7A)) {
            return 'L';
        }
        if (strpos(',./:', $ch) !== false) {
            return 'CS';
        }
        if ($ch === '+' || $ch === '-') {
            return 'ES';
        }
        if ($ch === '#' || $ch === '$' || $ch === '%') {
            return 'ET';
        }
        return 'ON';
    }
    if ($cp >= 0x0600 && $cp <= 0x06FF) {
        if (($cp >= 0x0600 && $cp <= 0x0605) || ($cp >= 0x0660 && $cp <= 0x0669) || $cp === 0x066B || $cp === 0x066C || $cp === 0x06DD
            || ($cp >= 0x06F0 && $cp <= 0x06F9)) {
            return 'N';
        }
        if ($cp === 0x060C) {
            return 'CS';
        }
        if ($cp === 0x0609 || $cp === 0x060A || $cp === 0x066A) {
            return 'ET';
        }
        if (($cp >= 0x0610 && $cp <= 0x061A) || ($cp >= 0x064B && $cp <= 0x065F) || $cp === 0x0670 || ($cp >= 0x06D6 && $cp <= 0x06DC)
            || ($cp >= 0x06DF && $cp <= 0x06E4) || $cp === 0x06E7 || $cp === 0x06E8 || ($cp >= 0x06EA && $cp <= 0x06ED)) {
            return 'NSM';
        }
        if ($cp === 0x0606 || $cp === 0x0607 || $cp === 0x060E || $cp === 0x060F || $cp === 0x06DE || $cp === 0x06E9) {
            return 'ON';
        }
        return 'R';
    }
    if (($cp >= 0x0590 && $cp <= 0x08FF) || ($cp >= 0xFB1D && $cp <= 0xFDFD) || ($cp >= 0xFE70 && $cp <= 0xFEFE) || $cp === 0x200F) {
        return 'R';
    }
    if ($cp === 0xA0 || $cp === 0x202F || $cp === 0x2044 || in_array($cp, [0xFE50, 0xFE52, 0xFE55, 0xFF0C, 0xFF0E, 0xFF0F, 0xFF1A], true)) {
        return 'CS';
    }
    if (in_array($cp, [0x207A, 0x207B, 0x208A, 0x208B, 0x2212, 0xFE62, 0xFE63, 0xFF0B, 0xFF0D], true)) {
        return 'ES';
    }
    if (($cp >= 0xA2 && $cp <= 0xA5) || $cp === 0xB0 || $cp === 0xB1 || ($cp >= 0x2030 && $cp <= 0x2034) || ($cp >= 0x20A0 && $cp <= 0x20CF)
        || in_array($cp, [0xFE5F, 0xFE69, 0xFE6A, 0xFF03, 0xFF04, 0xFF05, 0xFFE0, 0xFFE1, 0xFFE5, 0xFFE6], true)) {
        return 'ET';
    }
    if (($cp >= 0xB2 && $cp <= 0xB3) || $cp === 0xB9 || ($cp >= 0x2070 && $cp <= 0x2079) || ($cp >= 0x2080 && $cp <= 0x2089) || ($cp >= 0xFF10 && $cp <= 0xFF19)) {
        return 'N';
    }
    return ($cp === 0x200E || preg_match('/^\p{L}$/u', $ch)) ? 'L' : 'ON';
}

/** أشكال العرض العربية (مثل ﻻ) إلى حروفها الأصلية (NFKC)، حرفاً حرفاً. */
function pdf_unpresent(string $text): string
{
    static $forms = null;
    if (!preg_match('/[\x{FB50}-\x{FDFF}\x{FE70}-\x{FEFF}]/u', $text)) {
        return $text;
    }
    $forms = $forms ?? require __DIR__ . '/pdf_arabic_forms.php';
    return preg_replace_callback('/[\x{FB50}-\x{FDFF}\x{FE70}-\x{FEFF}]/u', function ($m) use ($forms) {
        return $forms[mb_ord($m[0], 'UTF-8')] ?? $m[0];
    }, $text);
}

/**
 * عكس خوارزمية Bidi لفقرة اتجاهها الأساسي من اليمين لليسار، بلا تضمين صريح:
 * - يُقلب السطر كله فتصبح الحروف العربية بترتيبها المنطقي.
 * - كل كتلة تحتوي حرفاً لاتينياً تُعاد كما تُقرأ يساراً ليمين (الأرقام بعد حرف لاتيني تُعامل لاتينية، W7).
 * - كتلة أرقام بلا لاتيني: كل رقم يُعاد وحده، ومعه الفاصل المنفرد بين رقمين مثل 16/90 و1,500 (W4)
 *   وعلامات مثل % الملاصقة للرقم (W5). المسافات بين الأرقام تبقى عربية الاتجاه: "12 / 500" تبقى كما هي.
 * - الأقواس داخل النص العربي معكوسة الشكل عند الرسم، فتُعاد إلى أصلها.
 */
function pdf_visual_to_logical(string $visual): string
{
    static $mirror = ['(' => ')', ')' => '(', '[' => ']', ']' => '[', '{' => '}', '}' => '{', '<' => '>', '>' => '<'];
    $chars = $visual === '' ? [] : array_reverse(mb_str_split($visual, 1, 'UTF-8'));
    $n = count($chars);
    $cls = array_map('pdf_bidi_class', $chars);
    $out = [];
    $i = 0;
    while ($i < $n) {
        if ($cls[$i] === 'R') {
            $out[] = $chars[$i++];
            continue;
        }
        $j = $i;
        while ($j < $n && $cls[$j] !== 'R') {
            $j++;
        }
        $block = array_slice($chars, $i, $j - $i);
        $bcls = array_slice($cls, $i, $j - $i);
        $s = 0;
        $e = count($block);
        while ($s < $e && $bcls[$s] !== 'L' && $bcls[$s] !== 'N') {
            $s++;
        }
        while ($e > $s && $bcls[$e - 1] !== 'L' && $bcls[$e - 1] !== 'N') {
            $e--;
        }
        foreach (array_slice($block, 0, $s) as $c) {
            $out[] = $mirror[$c] ?? $c;
        }
        $core = array_slice($block, $s, $e - $s);
        $coreCls = array_slice($bcls, $s, $e - $s);
        $len = count($core);
        if (in_array('L', $coreCls, true)) {
            foreach (array_reverse($core) as $c) {
                $out[] = $c;
            }
        } else {
            $k = 0;
            while ($k < $len) {
                if ($coreCls[$k] === 'N' || ($coreCls[$k] === 'ET' && $k + 1 < $len && $coreCls[$k + 1] === 'N')) {
                    $m = $k;
                    while ($m < $len && (
                        $coreCls[$m] === 'N'
                        || (($coreCls[$m] === 'CS' || $coreCls[$m] === 'ES') && $m + 1 < $len && $coreCls[$m + 1] === 'N' && $m > $k && $coreCls[$m - 1] === 'N')
                        || $coreCls[$m] === 'ET'
                    )) {
                        $m++;
                    }
                    foreach (array_reverse(array_slice($core, $k, $m - $k)) as $c) {
                        $out[] = $c;
                    }
                    $k = $m;
                } else {
                    $out[] = $mirror[$core[$k]] ?? $core[$k];
                    $k++;
                }
            }
        }
        foreach (array_slice($block, $e) as $c) {
            $out[] = $mirror[$c] ?? $c;
        }
        $i = $j;
    }
    // أشكال العرض العربية إلى حروفها الأصلية، بعد الترتيب لا قبله
    $text = pdf_unpresent(implode('', $out));
    $text = preg_replace('/[' . PDF_WHITESPACE . ']+/u', ' ', $text);
    return preg_replace('/^[' . PDF_WHITESPACE . ']+|[' . PDF_WHITESPACE . ']+$/u', '', $text);
}

/** حروف الصف الواقعة بين حدي عمود (من بداية الحرف). */
function pdf_column(array $row, float $lo, float $hi): array
{
    return array_values(array_filter($row['glyphs'], function ($g) use ($lo, $hi) { return $lo <= $g[1] && $g[1] < $hi; }));
}

/** "1,250.50" ← 125050 بالمئات (تقريب نصف لأعلى عند الخانة الثالثة)، أو null. */
function pdf_parse_number(string $text): ?int
{
    $t = str_replace([',', ' '], '', $text);
    if (!preg_match('/^-?\d+(\.\d+)?$/', $t)) {
        return null;
    }
    $neg = $t[0] === '-';
    $t = ltrim($t, '-');
    $whole = strstr($t, '.', true);
    $frac = $whole === false ? '' : substr($t, strlen($whole) + 1);
    $whole = $whole === false ? $t : $whole;
    $value = (int) $whole * 100 + intdiv((int) substr($frac . '000', 0, 3) + 5, 10);
    return $neg ? -$value : $value;
}

/** صف عناوين الجدول وحدود الأعمدة من مواضع العناوين. @return array{0: ?float, 1: ?array} */
function pdf_find_header(array $rows): array
{
    foreach ($rows as $row) {
        $text = pdf_visual_to_logical(pdf_visual_line($row['glyphs']));
        if (mb_strpos($text, 'الصنف') === false || mb_strpos($text, 'الكمية') === false) {
            continue;
        }
        // موضع كل عنوان: حروفه المتجاورة بلا فراغ بينها
        $ink = array_values(array_filter($row['glyphs'], function ($g) { return !pdf_isspace($g[3]); }));
        usort($ink, function ($a, $b) { return $a[1] <=> $b[1]; });
        $groups = [];
        $cur = [];
        foreach ($ink as $g) {
            if ($cur && $g[1] - $cur[count($cur) - 1][2] > PDF_SPACE_FRACTION * $g[4]) {
                $groups[] = $cur;
                $cur = [];
            }
            $cur[] = $g;
        }
        if ($cur) {
            $groups[] = $cur;
        }
        $words = [];
        foreach ($groups as $grp) {
            $word = pdf_visual_to_logical(implode('', array_column($grp, 3)));
            $words[$word] = [$grp[0][1], $grp[count($grp) - 1][2]];
        }
        foreach (['الصنف', 'الكمية', 'السعر', 'م'] as $need) {
            if (!isset($words[$need])) {
                continue 2;
            }
        }
        $total = null;
        foreach ($words as $w => $pos) {
            $w = (string) $w;
            if (mb_strpos($w, 'ال') === 0 && mb_strpos($w, 'جمال') !== false) {
                $total = $pos;
                break;
            }
        }
        if ($total === null) {
            continue;
        }
        [$qty, $price, $seq] = [$words['الكمية'], $words['السعر'], $words['م']];
        // الأرقام محاذاة لليمين تحت عناوينها، والاسم محاذى لليمين وينتهي قبل عمود "م" بنحو 10 نقاط.
        return [$row['y'], [
            'total' => [-1e9, ($total[1] + $price[0]) / 2],
            'price' => [($total[1] + $price[0]) / 2, ($price[1] + $qty[0]) / 2],
            'qty'   => [($price[1] + $qty[0]) / 2, $qty[1] + 50],
            'name'  => [$qty[1] + 50, $seq[0] - 8],
            'seq'   => [$seq[0] - 8, 1e9],
        ]];
    }
    return [null, null];
}

function pdf_labelled_value(array $texts, string $label, string $pattern): ?string
{
    foreach ($texts as $text) {
        if (mb_strpos(str_replace(' ', '', $text), $label) !== false && preg_match($pattern, $text, $m)) {
            return $m[0];
        }
    }
    return null;
}

function pdf_fmt(?int $h): ?string
{
    return $h === null ? null : from_hundredths($h);
}

/**
 * بنود فاتورة PDF وفحوصها.
 * @return array{file:string, pages:int, invoice_code:?string, invoice_date:?string,
 *   items: array<int, array{page:int, y:float, seq:int, name:string, qty:int, price:?int, line_total:?int}>,
 *   skipped: array, checks: array, problems: string[]}
 */
function pdf_extract_invoice(string $path, string $fileName = ''): array
{
    $doc = PdfDocument::open($path);
    $pages = $doc->pages();
    if (!$pages) {
        throw new UserError('ملف PDF بلا صفحات.');
    }
    $items = [];
    $skipped = [];
    $problems = [];
    $invoiceCode = $invoiceDate = null;
    $footerQty = $footerTotal = null;
    $anyText = false;
    foreach ($pages as $p => $page) {
        $pno = $p + 1;
        $glyphs = pdf_page_glyphs($doc, $page);
        $anyText = $anyText || $glyphs;
        $rows = pdf_rows($glyphs);
        $texts = array_map(function ($r) { return pdf_visual_to_logical(pdf_visual_line($r['glyphs'])); }, $rows);
        if ($invoiceCode === null) {
            $invoiceCode = pdf_labelled_value($texts, 'كودالفاتورة', '/\d{2,}/');
            $invoiceDate = pdf_labelled_value($texts, 'التاريخ', '#\d{4}/\d{2}/\d{2}#');
        }
        [$headerY, $cols] = pdf_find_header($rows);
        // رأس الصفحة (اسم المورد، العميل، العنوان) يتكرر في كل صفحة وآخره سطر "العنوان".
        $pageTop = null;
        foreach ($rows as $k => $r) {
            if (mb_strpos($texts[$k], 'العنوان') === 0) {
                $pageTop = $r['y'];
                break;
            }
        }
        foreach ($rows as $k => $row) {
            $textAll = $texts[$k];
            if ($pageTop !== null && $row['y'] >= $pageTop - PDF_ROW_TOLERANCE) {
                continue;
            }
            if ($headerY === null) {
                $skipped[] = ['page' => $pno, 'reason' => 'ذيل الفاتورة', 'text' => $textAll];
                continue;
            }
            if ($row['y'] >= $headerY - PDF_ROW_TOLERANCE) {
                continue;                                   // عناوين الجدول
            }
            $parts = [];
            foreach ($cols as $key => [$lo, $hi]) {
                $parts[$key] = pdf_visual_to_logical(pdf_visual_line(pdf_column($row, $lo, $hi)));
            }
            $seqText = str_replace(' ', '', $parts['seq']);
            $qty = pdf_parse_number($parts['qty']);
            if (ctype_digit($seqText) && $qty !== null && $parts['name'] !== '') {
                // حارس: حرف ملاصق لحد عمود يعني أن التقسيم قد يكون خاطئاً، فيُبلَّغ ولا يُخمَّن.
                foreach ($row['glyphs'] as $g) {
                    if (pdf_isspace($g[3])) {
                        continue;
                    }
                    foreach ($cols as $key => [$lo, $hi]) {
                        if ($lo <= $g[1] && $g[1] < $hi && ($g[1] - $lo < 2 || $hi - $g[2] < 2) && in_array($key, ['name', 'seq', 'qty'], true)) {
                            $problems[] = 'صفحة ' . $pno . ' م ' . $seqText . ': الحرف "' . $g[3] . '" ملاصق لحد عمود ' . $key;
                        }
                    }
                }
                $items[] = [
                    'page' => $pno, 'y' => round($row['y'], 1), 'seq' => (int) $seqText, 'name' => $parts['name'],
                    'qty' => $qty, 'price' => pdf_parse_number($parts['price']), 'line_total' => pdf_parse_number($parts['total']),
                ];
                continue;
            }
            $compact = str_replace(' ', '', $parts['name']);
            if (in_array($compact, PDF_TOTAL_LABELS, true) && $qty !== null) {
                $footerQty = $qty;
                $footerTotal = pdf_parse_number($parts['total']);
                $skipped[] = ['page' => $pno, 'reason' => 'صف الإجمالي (للتدقيق)', 'text' => $textAll];
            } else {
                $skipped[] = ['page' => $pno, 'reason' => 'ذيل الفاتورة', 'text' => $textAll];
            }
        }
    }
    if (!$anyText) {
        throw new UserError('ملف PDF بلا نص (صورة ممسوحة ضوئياً)، فلا يمكن قراءة بنوده. اطلب من المورد الفاتورة كملف PDF من برنامجه، أو اكتبها في Excel.');
    }

    // ── فحوص الاكتمال ──
    $seqs = array_column($items, 'seq');
    $expected = $items ? range(1, count($items)) : [];
    if ($seqs !== $expected) {
        $missing = array_values(array_diff($expected, $seqs));
        $counts = array_count_values($seqs);
        $dups = array_keys(array_filter($counts, function ($c) { return $c > 1; }));
        sort($dups);
        $problems[] = 'تسلسل م غير متصل: ناقص [' . implode(', ', array_slice($missing, 0, 20)) . '] مكرر [' . implode(', ', array_slice($dups, 0, 20)) . ']';
    }
    $qtySum = array_sum(array_column($items, 'qty'));
    if ($footerQty === null) {
        $problems[] = 'لم يُعثر على صف الإجمالي للتحقق من مجموع الكميات';
    } elseif ($qtySum !== $footerQty) {
        $problems[] = 'مجموع الكميات ' . from_hundredths($qtySum) . ' لا يساوي إجمالي الفاتورة ' . from_hundredths($footerQty);
    }
    $arithmetic = [];
    foreach ($items as $it) {
        if ($it['price'] === null || $it['line_total'] === null) {
            $arithmetic[] = [$it['seq'], 'سعر أو إجمالي مفقود'];
            continue;
        }
        $expect = intdiv($it['price'] * $it['qty'] + 50, 100);
        if (abs($expect - $it['line_total']) > 1) {
            $arithmetic[] = [$it['seq'], from_hundredths($it['qty']) . ' × ' . from_hundredths($it['price']) . ' = ' . from_hundredths($expect) . ' ≠ ' . from_hundredths($it['line_total'])];
        }
    }
    $lineTotalSum = array_sum(array_map(function ($it) { return $it['line_total'] ?? 0; }, $items));
    if ($footerTotal !== null && abs($lineTotalSum - $footerTotal) > count($items)) {
        $problems[] = 'مجموع إجمالي السطور ' . from_hundredths($lineTotalSum) . ' لا يساوي قيمة الفاتورة ' . from_hundredths($footerTotal);
    }
    foreach ($items as $it) {
        if (strpos($it['name'], "\u{FFFD}") !== false) {
            $problems[] = 'م ' . $it['seq'] . ': حرف غير معروف في الاسم';
        }
    }

    return [
        'file' => $fileName !== '' ? $fileName : basename($path),
        'pages' => count($pages),
        'invoice_code' => $invoiceCode,
        'invoice_date' => $invoiceDate,
        'items' => $items,
        'skipped' => $skipped,
        'checks' => [
            'seq_contiguous' => $seqs === $expected,
            'qty_sum' => from_hundredths($qtySum),
            'footer_qty' => pdf_fmt($footerQty),
            'qty_sum_matches_footer' => $footerQty !== null && $qtySum === $footerQty,
            'line_total_sum' => from_hundredths($lineTotalSum),
            'footer_total' => pdf_fmt($footerTotal),
            'arithmetic_mismatches' => $arithmetic,
        ],
        'problems' => $problems,
    ];
}
