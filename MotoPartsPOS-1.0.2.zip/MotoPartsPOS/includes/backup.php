<?php
/**
 * نسخة احتياطية منطقية (SQL مضغوط) بلغة PHP خالصة: لا تحتاج mysqldump ولا مسار XAMPP،
 * ولا تعتمد على ملفات InnoDB، فتُستعاد على أي MariaDB سليمة حتى لو تلفت ملفات البيانات.
 * الاستعادة: phpMyAdmin ← استيراد ← اختر ملف .sql.gz (يدعم gzip مباشرة).
 */

/** @return array{file:string, size:int, tables:int} */
function backup_database(PDO $pdo, string $dir): array
{
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) {
        throw new RuntimeException('تعذر إنشاء مجلد النسخ الاحتياطية: ' . $dir);
    }
    $file = $dir . '/' . DB_NAME . '-' . date('Ymd-His') . '.sql.gz';
    $partial = $file . '.part';
    $gz = gzopen($partial, 'wb6');
    if ($gz === false) {
        throw new RuntimeException('تعذر كتابة ملف النسخة الاحتياطية.');
    }

    $tables = $pdo->query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'")->fetchAll(PDO::FETCH_NUM);
    gzwrite($gz, "-- " . APP_NAME . ' ' . APP_VERSION . " backup of `" . DB_NAME . "`\n-- " . date('Y-m-d H:i:s P') . "\n"
        . "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\nSET UNIQUE_CHECKS = 0;\n\n");

    // لقطة واحدة متسقة لكل الجداول (مثل mysqldump --single-transaction): فاتورة تُحفظ أثناء النسخ
    // تظهر في النسخة كاملة أو لا تظهر، ولا تُقفل أي جداول فيستمر البيع أثناء النسخ.
    $pdo->exec('SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ');
    $pdo->exec('START TRANSACTION WITH CONSISTENT SNAPSHOT');
    try {
        foreach ($tables as [$table]) {
            $create = $pdo->query('SHOW CREATE TABLE `' . $table . '`')->fetch(PDO::FETCH_NUM)[1];
            gzwrite($gz, 'DROP TABLE IF EXISTS `' . $table . "`;\n" . $create . ";\n\n");

            // قراءة غير مخزّنة: صف بصف، فالذاكرة ثابتة مهما كبر الجدول.
            $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);
            $rows = $pdo->query('SELECT * FROM `' . $table . '`', PDO::FETCH_NUM);
            $batch = [];
            foreach ($rows as $row) {
                $values = [];
                foreach ($row as $value) {
                    $values[] = $value === null ? 'NULL' : $pdo->quote((string) $value);
                }
                $batch[] = '(' . implode(',', $values) . ')';
                if (count($batch) === 200) {
                    gzwrite($gz, 'INSERT INTO `' . $table . '` VALUES ' . implode(",\n", $batch) . ";\n");
                    $batch = [];
                }
            }
            $rows->closeCursor();
            $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
            if ($batch) {
                gzwrite($gz, 'INSERT INTO `' . $table . '` VALUES ' . implode(",\n", $batch) . ";\n");
            }
            gzwrite($gz, "\n");
        }
        gzwrite($gz, "SET UNIQUE_CHECKS = 1;\nSET FOREIGN_KEY_CHECKS = 1;\n");
    } finally {
        $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
        $pdo->exec('COMMIT');
        gzclose($gz);
    }

    if (!rename($partial, $file)) {
        @unlink($partial);
        throw new RuntimeException('تعذر حفظ ملف النسخة الاحتياطية.');
    }
    return ['file' => $file, 'size' => (int) filesize($file), 'tables' => count($tables)];
}

/** يبقي أحدث $keep نسخة ويحذف الأقدم. */
function prune_backups(string $dir, int $keep): int
{
    $files = list_backups($dir);
    $removed = 0;
    foreach (array_slice($files, $keep) as $old) {
        if (@unlink($dir . '/' . $old['file'])) {
            $removed++;
        }
    }
    return $removed;
}

/** @return array<int, array{file:string, size:int, created_at:string}> الأحدث أولاً */
function list_backups(string $dir): array
{
    $out = [];
    foreach (glob($dir . '/*.sql.gz') ?: [] as $path) {
        $out[] = ['file' => basename($path), 'size' => (int) filesize($path), 'created_at' => date('Y-m-d H:i', (int) filemtime($path))];
    }
    usort($out, function ($a, $b) {
        return strcmp($b['file'], $a['file']);
    });
    return $out;
}
