<?php
/**
 * طلب HTTPS خارجي للمحدّث فقط. التحقق من الشهادة إلزامي دائماً (openssl.cafile في php.ini).
 * cURL إن وُجد، وإلا stream context.
 *
 * @return array{status:int, body:?string, error:?string}
 */
function http_get(string $url, int $timeout, ?string $saveTo = null, int $maxBytes = 52428800): array
{
    if (stripos($url, 'https://') !== 0) {
        return ['status' => 0, 'body' => null, 'error' => 'يُسمح بروابط HTTPS فقط.'];
    }
    $agent = 'MotoPartsPOS/' . APP_VERSION;

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        $out = null;
        $opts = [
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_PROTOCOLS      => CURLPROTO_HTTPS,
            CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT      => $agent,
            CURLOPT_NOPROGRESS     => false,
            CURLOPT_PROGRESSFUNCTION => function ($res, $dlTotal, $dlNow) use ($maxBytes) {
                return $dlNow > $maxBytes ? 1 : 0;   // غير الصفر يوقف التنزيل
            },
        ];
        if ($saveTo !== null) {
            $out = fopen($saveTo, 'wb');
            if ($out === false) {
                return ['status' => 0, 'body' => null, 'error' => 'تعذر الكتابة في ' . $saveTo];
            }
            $opts[CURLOPT_FILE] = $out;
        } else {
            $opts[CURLOPT_RETURNTRANSFER] = true;
        }
        curl_setopt_array($ch, $opts);
        $body = curl_exec($ch);
        $error = $body === false ? curl_error($ch) : null;
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($out) {
            fclose($out);
        }
        return ['status' => $status, 'body' => $saveTo === null && is_string($body) ? $body : null, 'error' => $error];
    }

    $context = stream_context_create([
        'http' => ['timeout' => $timeout, 'follow_location' => 1, 'max_redirects' => 5, 'user_agent' => $agent, 'ignore_errors' => true],
        'ssl'  => ['verify_peer' => true, 'verify_peer_name' => true],
    ]);
    $in = @fopen($url, 'rb', false, $context);
    if ($in === false) {
        $last = error_get_last();
        return ['status' => 0, 'body' => null, 'error' => $last['message'] ?? 'تعذر الاتصال.'];
    }
    $meta = stream_get_meta_data($in);
    $status = 0;
    foreach ($meta['wrapper_data'] ?? [] as $header) {
        if (preg_match('#^HTTP/\S+\s+(\d{3})#', $header, $m)) {
            $status = (int) $m[1];                  // آخر حالة بعد التحويلات
        }
    }
    $out = $saveTo !== null ? fopen($saveTo, 'wb') : null;
    $body = '';
    $read = 0;
    while (!feof($in)) {
        $chunk = (string) fread($in, 65536);
        $read += strlen($chunk);
        if ($read > $maxBytes) {
            fclose($in);
            if ($out) {
                fclose($out);
            }
            return ['status' => $status, 'body' => null, 'error' => 'الملف أكبر من الحد المسموح.'];
        }
        if ($out) {
            fwrite($out, $chunk);
        } else {
            $body .= $chunk;
        }
    }
    fclose($in);
    if ($out) {
        fclose($out);
    }
    return ['status' => $status, 'body' => $saveTo === null ? $body : null, 'error' => null];
}
