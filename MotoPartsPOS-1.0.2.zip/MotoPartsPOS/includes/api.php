<?php
/**
 * بداية كل ملف في api/ و updater/: يرفض الطلبات غير الموثوقة، ويحوّل أي خطأ إلى رد JSON مفهوم.
 * بلا تسجيل دخول يرد bootstrap.php بـ 401 JSON بدلاً من تحويل الصفحة.
 */
defined('APP_API') || define('APP_API', true);
require_once __DIR__ . '/bootstrap.php';

set_exception_handler(function (Throwable $e): void {
    if ($e instanceof UserError) {
        json_error($e->getMessage(), $e->status, $e->extra);
    }
    error_log('[api] ' . $e);
    if ($e instanceof PDOException && db_error_is_connection($e)) {
        json_error('تعذر الاتصال بقاعدة البيانات. تأكد أن MySQL يعمل على المنفذ ' . DB_PORT . '.', 503);
    }
    json_error('حدث خطأ غير متوقع في الخادم. التفاصيل في storage/logs/php-errors.log', 500);
});

register_shutdown_function(function (): void {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true) && !headers_sent()) {
        json_out(['ok' => false, 'error' => 'خطأ داخلي في الخادم. التفاصيل في storage/logs/php-errors.log'], 500);
    }
});

api_guard();
