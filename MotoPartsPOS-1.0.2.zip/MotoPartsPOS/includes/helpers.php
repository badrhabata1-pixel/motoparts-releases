<?php
/**
 * دوال مشتركة: الردود، حماية الطلبات، تطبيع النص العربي، والحساب المالي بأعداد صحيحة.
 */

/** خطأ موجّه للمستخدم: يُعرض نصه كما هو ويُرجع برمز HTTP المحدد. */
final class UserError extends RuntimeException
{
    /** @var int */
    public $status;
    /** @var array */
    public $extra;

    public function __construct(string $message, int $status = 400, array $extra = [])
    {
        parent::__construct($message);
        $this->status = $status;
        $this->extra = $extra;
    }
}

/* ───────────── HTML و JSON ───────────── */

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function json_out(array $data, int $status = 200): void
{
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        header('X-Content-Type-Options: nosniff');
    }
    // JSON_UNESCAPED_UNICODE: الحرف العربي بايتان بدلاً من ستة (ك).
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function json_ok(array $data = []): void
{
    json_out(['ok' => true] + $data);
}

function json_error(string $message, int $status = 400, array $extra = []): void
{
    json_out(['ok' => false, 'error' => $message] + $extra, $status);
}

/* ───────────── حماية الطلبات ───────────── */

/** يمنع DNS rebinding: التطبيق يُخدم فقط باسم مضيف محلي معروف. */
function request_host_allowed(): bool
{
    $host = strtolower(trim($_SERVER['HTTP_HOST'] ?? ''));
    if ($host === '') {
        return PHP_SAPI === 'cli';
    }
    if ($host[0] === '[') {
        $end = strpos($host, ']');
        $name = $end === false ? $host : substr($host, 0, $end + 1);
    } else {
        $name = preg_replace('/:\d+$/', '', $host);
    }
    return in_array($name, array_map('strtolower', (array) APP_ALLOWED_HOSTS), true);
}

/**
 * كل طلب API يجب أن يأتي من صفحات التطبيق نفسها: نموذج HTML من موقع آخر لا يستطيع إضافة
 * ترويسة مخصصة، وطلب fetch يحملها من أصل آخر يحتاج موافقة CORS لا نعطيها أبداً.
 */
function api_guard(): void
{
    if (!request_host_allowed()) {
        json_error('طلب من عنوان غير مسموح.', 403);
    }
    if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'MotoPartsPOS') {
        json_error('طلب غير صالح.', 403);
    }
    $site = $_SERVER['HTTP_SEC_FETCH_SITE'] ?? '';
    if ($site !== '' && $site !== 'same-origin' && $site !== 'none') {
        json_error('طلب من موقع آخر مرفوض.', 403);
    }
}

function require_method(string $method): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== $method) {
        json_error('طريقة الطلب غير مسموحة.', 405);
    }
}

function request_json(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') {
        return [];
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        throw new UserError('بيانات الطلب غير صالحة.');
    }
    return $data;
}

/* ───────────── النص العربي ───────────── */

/** الأرقام العربية-الهندية (٠١٢) والفارسية (۰۱۲) والفاصلة العشرية العربية → أرقام لاتينية. */
function normalize_digits(string $s): string
{
    static $map = null;
    if ($map === null) {
        $map = ['٫' => '.', '٬' => ','];
        for ($i = 0; $i <= 9; $i++) {
            $map[mb_chr(0x0660 + $i, 'UTF-8')] = (string) $i;
            $map[mb_chr(0x06F0 + $i, 'UTF-8')] = (string) $i;
        }
    }
    return strtr($s, $map);
}

/** ينظف النص دون تغيير معناه: يحذف المحارف الخفية والمسافات الزائدة فقط، ويقص إلى $max حرفاً. */
function clean_text(string $s, int $max = 255): string
{
    if (!mb_check_encoding($s, 'UTF-8')) {
        $s = mb_convert_encoding($s, 'UTF-8', 'UTF-8');
    }
    $s = preg_replace('/[\x{0000}-\x{001F}\x{007F}\x{200B}-\x{200F}\x{202A}-\x{202E}\x{2066}-\x{2069}\x{FEFF}]/u', ' ', $s) ?? $s;
    $s = trim(preg_replace('/\s+/u', ' ', $s) ?? $s);
    return mb_substr($s, 0, $max, 'UTF-8');
}

/**
 * مفتاح البحث المطبَّع. اختبار فعلي على MariaDB 10.4: LIKE في utf8mb4_unicode_ci لا يساوي بين
 * ة/ه ولا ى/ي ولا أ/ا، لذلك يُطبَّع النص هنا ويُخزَّن في products.search_key.
 */
function normalize_search(string $s): string
{
    $s = mb_strtolower(normalize_digits(clean_text($s, 1000)), 'UTF-8');
    $s = preg_replace('/[\x{064B}-\x{065F}\x{0670}\x{0640}]/u', '', $s) ?? $s;   // التشكيل والتطويل
    $s = strtr($s, [
        'أ' => 'ا', 'إ' => 'ا', 'آ' => 'ا', 'ٱ' => 'ا',
        'ى' => 'ي', 'ئ' => 'ي', 'ة' => 'ه', 'ؤ' => 'و',
    ]);
    $s = preg_replace('~\s*([/+\-])\s*~u', '$1', $s) ?? $s;                   // "12 / 500" = "12/500"
    return mb_substr(trim(preg_replace('/\s+/u', ' ', $s) ?? $s), 0, 255, 'UTF-8');
}

/** كلمات البحث بعد التطبيع (حتى 6 كلمات). البحث يشترط وجودها كلها بأي ترتيب. */
function search_tokens(string $q): array
{
    $norm = normalize_search($q);
    if ($norm === '') {
        return [];
    }
    return array_slice(array_values(array_unique(explode(' ', $norm))), 0, 6);
}

function like_escape(string $s): string
{
    return addcslashes($s, '\\%_');
}

/** باركود من خلية Excel أو CSV: أرقام لاتينية، بلا ".0" أو صيغة علمية، بلا مسافات. */
function normalize_barcode($value): string
{
    $s = trim(normalize_digits(clean_text((string) $value, 100)));
    if (preg_match('/^\d+\.0+$/', $s)) {
        $s = substr($s, 0, strpos($s, '.'));
    } elseif (preg_match('/^\d+(\.\d+)?e\+?\d+$/i', $s)) {
        $s = sprintf('%.0f', (float) $s);
    }
    return str_replace(' ', '', $s);
}

/* ───────────── المال والكميات: أعداد صحيحة بالمئات، بلا float ───────────── */

/**
 * "12.5" أو "١٢٫٥" أو 12.5 → 1250. يعيد null إذا لم تكن القيمة رقماً صالحاً.
 * التقريب نصف لأعلى عند الخانة الثالثة، مطابق لـ MP.money.toHundredths في assets/js/app.js.
 */
function to_hundredths($value): ?int
{
    if (is_int($value)) {
        return $value * 100;
    }
    if (is_float($value)) {
        if (!is_finite($value)) {
            return null;
        }
        $value = sprintf('%.6F', $value);
    }
    if (!is_string($value)) {
        return null;
    }
    $s = str_replace([' ', "\u{00A0}"], '', normalize_digits(trim($value)));
    if ($s === '') {
        return null;
    }
    if (stripos($s, 'e') !== false && is_numeric($s)) {          // 1.5E+3 من Excel
        $s = sprintf('%.6F', (float) $s);
    }
    if (strpos($s, ',') !== false) {
        if (strpos($s, '.') !== false || !preg_match('/^-?\d+,\d{1,2}$/', $s)) {
            $s = str_replace(',', '', $s);                          // 1,250.00 أو 1,250
        } else {
            $s = str_replace(',', '.', $s);                         // 12,5 فاصلة عشرية
        }
    }
    if (!preg_match('/^(-?)(\d*)(?:\.(\d*))?$/', $s, $m) || ($m[2] === '' && ($m[3] ?? '') === '')) {
        return null;
    }
    if (strlen($m[2]) > 12) {
        return null;
    }
    $frac = substr(str_pad($m[3] ?? '', 3, '0'), 0, 3);
    $result = (int) $m[2] * 100 + intdiv((int) $frac + 5, 10);
    return $m[1] === '-' ? -$result : $result;
}

function from_hundredths(int $value): string
{
    $sign = $value < 0 ? '-' : '';
    $value = abs($value);
    return $sign . intdiv($value, 100) . '.' . str_pad((string) ($value % 100), 2, '0', STR_PAD_LEFT);
}

/** للعرض فقط: 1250050 → "12,500.50". */
function money_display($value): string
{
    $c = is_int($value) ? $value : (to_hundredths((string) $value) ?? 0);
    $sign = $c < 0 ? '-' : '';
    $c = abs($c);
    return $sign . number_format(intdiv($c, 100)) . '.' . str_pad((string) ($c % 100), 2, '0', STR_PAD_LEFT);
}

/** للعرض فقط: "1.00" → "1"، "2.50" → "2.5". */
function qty_display($value): string
{
    $s = from_hundredths(is_int($value) ? $value : (to_hundredths((string) $value) ?? 0));
    return preg_replace(['/\.00$/', '/(\.\d)0$/'], ['', '$1'], $s);
}

/** إجمالي السطر بالقروش: السعر (قروش) × الكمية (مئات) ÷ 100، تقريب نصف لأعلى. */
function line_subtotal(int $priceCents, int $qtyHundredths): int
{
    return intdiv($priceCents * $qtyHundredths + 50, 100);
}

/* ───────────── قاعدة البيانات ───────────── */

/**
 * ينفذ $work داخل معاملة واحدة، ويعيد المحاولة حتى 3 مرات عند deadlock (1213) أو انتهاء مهلة القفل (1205).
 * أي استثناء آخر يلغي المعاملة كاملة ثم يُعاد رميه.
 */
function with_transaction(PDO $pdo, callable $work, int $attempts = 3)
{
    for ($try = 1; ; $try++) {
        $pdo->beginTransaction();
        try {
            $result = $work($pdo);
            $pdo->commit();
            return $result;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $code = $e instanceof PDOException ? (int) ($e->errorInfo[1] ?? 0) : 0;
            if (($code === 1213 || $code === 1205) && $try < $attempts) {
                usleep(50000 * $try);
                continue;
            }
            throw $e;
        }
    }
}

function db_error_is_connection(PDOException $e): bool
{
    $code = (int) ($e->errorInfo[1] ?? $e->getCode());
    return in_array($code, [1044, 1045, 1049, 2002, 2003, 2006, 2013], true)
        || preg_match('/\[(1045|1049|2002|2003|2006)\]/', $e->getMessage()) === 1;
}

function meta_get(PDO $pdo, string $key, ?string $default = null): ?string
{
    $st = $pdo->prepare('SELECT meta_value FROM app_meta WHERE meta_key = ?');
    $st->execute([$key]);
    $value = $st->fetchColumn();
    return $value === false ? $default : (string) $value;
}

function meta_set(PDO $pdo, string $key, string $value): void
{
    $st = $pdo->prepare('INSERT INTO app_meta (meta_key, meta_value) VALUES (?, ?)
                         ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value)');
    $st->execute([$key, $value]);
}

/* ───────────── التواريخ والمسارات ───────────── */

function valid_date(?string $s): ?string
{
    if ($s === null || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $s)) {
        return null;
    }
    $d = DateTimeImmutable::createFromFormat('!Y-m-d', $s);
    return $d && $d->format('Y-m-d') === $s ? $s : null;
}

/** حدود يوم محلي كامل [بدايته، بداية اليوم التالي) — شرط قابل للفهرسة على created_at. */
function day_range(string $date): array
{
    $start = DateTimeImmutable::createFromFormat('!Y-m-d', $date) ?: new DateTimeImmutable('today');
    return [$start->format('Y-m-d H:i:s'), $start->modify('+1 day')->format('Y-m-d H:i:s')];
}

/**
 * رابط ملف ثابت (css/js) مع وقت تعديله: الملفات تُخزَّن في المتصفح 30 يوماً (assets/.htaccess)،
 * وأي ملف يتغير بتعديل أو تحديث يحصل على رابط جديد فيُحمَّل فوراً.
 */
function asset(string $path): string
{
    $mtime = @filemtime(APP_ROOT . '/' . $path);
    return $path . '?v=' . ($mtime ?: APP_VERSION);
}

/** مسار داخل storage/ مع إنشائه عند الحاجة. */
function storage_path(string $sub = ''): string
{
    $dir = APP_ROOT . '/storage' . ($sub !== '' ? '/' . $sub : '');
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    return $dir;
}
