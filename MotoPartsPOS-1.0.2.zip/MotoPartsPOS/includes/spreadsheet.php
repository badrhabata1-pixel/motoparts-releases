<?php
/**
 * قراءة ملفات XLSX و CSV دون أي مكتبة خارجية: XMLReader بالتدفق، وقارئ ZIP داخلي عند غياب امتداد zip.
 * كل الخلايا تُقرأ نصوصاً كما هي في الملف؛ التحويل إلى أرقام يتم لاحقاً بـ to_hundredths().
 */

/** قارئ أرشيف ZIP: ZipArchive إن وُجد، وإلا تنفيذ بـ PHP خالصة (ZIP عادي بلا Zip64، ضغط deflate أو بدون). */
final class ZipFile
{
    /** @var ZipArchive|null */
    private $zip;
    /** @var resource|null */
    private $fh;
    /** @var array<string, array> */
    private $entries = [];

    public function __construct(string $path)
    {
        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($path) !== true) {
                throw new UserError('تعذر فتح الملف كأرشيف ZIP. تأكد أنه ملف xlsx سليم.');
            }
            $this->zip = $zip;
            return;
        }
        $this->openPure($path);
    }

    /** @return string[] */
    public function names(): array
    {
        if ($this->zip) {
            $names = [];
            for ($i = 0; $i < $this->zip->numFiles; $i++) {
                $names[] = (string) $this->zip->getNameIndex($i);
            }
            return $names;
        }
        return array_keys($this->entries);
    }

    /** الاسم الفعلي للعنصر مع تجاهل حالة الأحرف والشرطة الأولى، أو null. */
    public function find(string $name): ?string
    {
        $wanted = strtolower(ltrim($name, '/'));
        foreach ($this->names() as $candidate) {
            if (strtolower(ltrim(str_replace('\\', '/', $candidate), '/')) === $wanted) {
                return $candidate;
            }
        }
        return null;
    }

    public function read(string $name): ?string
    {
        if ($this->zip) {
            $data = $this->zip->getFromName($name);
            return $data === false ? null : $data;
        }
        if (!isset($this->entries[$name])) {
            return null;
        }
        $e = $this->entries[$name];
        fseek($this->fh, $e['offset']);
        $local = unpack('Vsig/vver/vflags/vmethod/vtime/vdate/Vcrc/Vcsize/Vusize/vnameLen/vextraLen', (string) fread($this->fh, 30));
        if (!$local || $local['sig'] !== 0x04034b50) {
            throw new UserError('أرشيف ZIP تالف.');
        }
        fseek($this->fh, $e['offset'] + 30 + $local['nameLen'] + $local['extraLen']);
        $data = $e['csize'] > 0 ? (string) fread($this->fh, $e['csize']) : '';
        if ($e['method'] === 0) {
            return $data;
        }
        if ($e['method'] === 8) {
            $out = @gzinflate($data);
            if ($out === false) {
                throw new UserError('تعذر فك ضغط ' . $name . ' من الأرشيف.');
            }
            return $out;
        }
        throw new UserError('طريقة ضغط غير مدعومة داخل الأرشيف.');
    }

    public function close(): void
    {
        if ($this->zip) {
            $this->zip->close();
            $this->zip = null;
        }
        if ($this->fh) {
            fclose($this->fh);
            $this->fh = null;
        }
    }

    private function openPure(string $path): void
    {
        $fh = fopen($path, 'rb');
        $size = (int) filesize($path);
        if (!$fh || $size < 22) {
            throw new UserError('ملف ZIP غير صالح.');
        }
        $tailLen = min($size, 65557);                  // 22 بايت EOCD + أقصى تعليق 65535
        fseek($fh, $size - $tailLen);
        $tail = (string) fread($fh, $tailLen);
        $pos = strrpos($tail, "PK\x05\x06");
        if ($pos === false) {
            throw new UserError('ملف ZIP غير صالح (لا يوجد فهرس مركزي).');
        }
        $eocd = unpack('vdisk/vcdDisk/vcountDisk/vcount/Vsize/Voffset', substr($tail, $pos + 4, 16));
        fseek($fh, $eocd['offset']);
        $cd = (string) fread($fh, $eocd['size']);
        $p = 0;
        for ($i = 0; $i < $eocd['count']; $i++) {
            $h = unpack('Vsig/vmade/vneed/vflags/vmethod/vtime/vdate/Vcrc/Vcsize/Vusize/vnameLen/vextraLen/vcommentLen/vdisk/vinternal/Vexternal/Voffset', substr($cd, $p, 46));
            if (!$h || $h['sig'] !== 0x02014b50) {
                throw new UserError('فهرس ZIP تالف.');
            }
            $name = substr($cd, $p + 46, $h['nameLen']);
            $this->entries[$name] = ['offset' => $h['offset'], 'csize' => $h['csize'], 'method' => $h['method']];
            $p += 46 + $h['nameLen'] + $h['extraLen'] + $h['commentLen'];
        }
        $this->fh = $fh;
    }
}

/** ينشئ أرشيف ZIP في الذاكرة (deflate). يكفي لملفات التصدير وحزم التحديث الصغيرة. */
function zip_build(array $files): string
{
    $now = getdate();
    $dosTime = ($now['hours'] << 11) | ($now['minutes'] << 5) | intdiv($now['seconds'], 2);
    $dosDate = (($now['year'] - 1980) << 9) | ($now['mon'] << 5) | $now['mday'];
    $body = '';
    $central = '';
    $count = 0;
    foreach ($files as $name => $data) {
        $data = (string) $data;
        $crc = crc32($data);
        $packed = gzdeflate($data, 6);
        $method = 8;
        if ($packed === false || strlen($packed) >= strlen($data)) {
            $packed = $data;
            $method = 0;
        }
        $offset = strlen($body);
        $body .= pack('VvvvvvVVVvv', 0x04034b50, 20, 0x0800, $method, $dosTime, $dosDate, $crc, strlen($packed), strlen($data), strlen($name), 0)
            . $name . $packed;
        $central .= pack('VvvvvvvVVVvvvvvVV', 0x02014b50, 20, 20, 0x0800, $method, $dosTime, $dosDate, $crc, strlen($packed), strlen($data), strlen($name), 0, 0, 0, 0, 0, $offset)
            . $name;
        $count++;
    }
    return $body . $central . pack('VvvvvVVv', 0x06054b50, 0, 0, $count, $count, strlen($central), strlen($body), 0);
}

function column_letter(int $index): string
{
    $letters = '';
    for ($n = $index + 1; $n > 0; $n = intdiv($n - 1, 26)) {
        $letters = chr(65 + ($n - 1) % 26) . $letters;
    }
    return $letters;
}

final class SpreadsheetReader
{
    /** @var string xlsx | csv | pdf */
    private $type;
    /** @var array|null بنود فاتورة PDF وفحوصها (includes/pdf_invoice.php) */
    private $pdf;
    /** @var string */
    private $path;
    /** @var ZipFile|null */
    private $zip;
    /** @var array<int, array{name:string,path:string,hidden:bool}> */
    private $sheets = [];
    /** @var string[]|null */
    private $sharedStrings;
    /** @var string */
    private $csvName = 'CSV';

    public static function open(string $path, string $originalName): self
    {
        $reader = new self();
        $reader->path = $path;
        $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        $magic = (string) file_get_contents($path, false, null, 0, 8);

        if (strncmp($magic, "PK\x03\x04", 4) === 0) {
            $reader->type = 'xlsx';
            $reader->openXlsx();
        } elseif (strncmp($magic, "\xD0\xCF\x11\xE0", 4) === 0 || $ext === 'xls') {
            throw new UserError('صيغة xls القديمة غير مدعومة. افتح الملف في Excel واحفظه بصيغة xlsx (أو CSV UTF-8).');
        } elseif ($ext === 'pdf' || strpos((string) file_get_contents($path, false, null, 0, 1024), '%PDF-') !== false) {
            $reader->type = 'pdf';
            $reader->pdf = self::pdfInvoice($path, $originalName);
        } elseif (in_array($ext, ['csv', 'txt', 'tsv'], true)) {
            $reader->type = 'csv';
            $reader->csvName = pathinfo($originalName, PATHINFO_FILENAME) ?: 'CSV';
        } else {
            throw new UserError('صيغة الملف غير مدعومة. استخدم xlsx أو csv أو pdf.');
        }
        return $reader;
    }

    /**
     * بنود فاتورة PDF، محفوظة بجوار الملف المرفوع: المعاينة وإعادة القراءة والتنفيذ تقرأ الملف مرة واحدة.
     * @see pdf_extract_invoice()
     */
    private static function pdfInvoice(string $path, string $originalName): array
    {
        $cache = $path . '.pdf.json';
        if (is_file($cache) && filemtime($cache) >= filemtime($path)) {
            $data = json_decode((string) file_get_contents($cache), true);
            if (is_array($data)) {
                return $data;
            }
        }
        require_once __DIR__ . '/pdf_invoice.php';
        $data = pdf_extract_invoice($path, $originalName);
        @file_put_contents($cache, json_encode($data, JSON_UNESCAPED_UNICODE));
        return $data;
    }

    /** ملخص فاتورة PDF للمعاينة (رقمها وتاريخها وفحوص الاكتمال)، أو null لملفات Excel و CSV. */
    public function info(int $sheetIndex): ?array
    {
        if ($this->type !== 'pdf' || $sheetIndex !== 0) {
            return null;
        }
        $p = $this->pdf;
        return [
            'invoice_code' => $p['invoice_code'], 'invoice_date' => $p['invoice_date'], 'pages' => $p['pages'],
            'items' => count($p['items']), 'skipped' => count($p['skipped']), 'checks' => $p['checks'], 'problems' => $p['problems'],
        ];
    }

    /** يغلق الأرشيف: على Windows لا يمكن حذف ملف ما زال مفتوحاً. */
    public function close(): void
    {
        if ($this->zip) {
            $this->zip->close();
            $this->zip = null;
        }
    }

    /** @return array<int, array{index:int,name:string,hidden:bool}> */
    public function sheets(): array
    {
        if ($this->type === 'csv') {
            return [['index' => 0, 'name' => $this->csvName, 'hidden' => false]];
        }
        if ($this->type === 'pdf') {
            $code = $this->pdf['invoice_code'];
            return [['index' => 0, 'name' => $code ? 'فاتورة ' . $code : pathinfo($this->pdf['file'], PATHINFO_FILENAME), 'hidden' => false]];
        }
        $out = [];
        foreach ($this->sheets as $i => $sheet) {
            $out[] = ['index' => $i, 'name' => $sheet['name'], 'hidden' => $sheet['hidden']];
        }
        return $out;
    }

    /**
     * صفوف الورقة واحداً تلو الآخر: [رقم الصف كما في Excel (يبدأ من 1)، [رقم العمود (يبدأ من 0) => النص]].
     * الخلايا الفارغة غير موجودة في المصفوفة.
     */
    public function rows(int $sheetIndex): Generator
    {
        if ($this->type === 'csv') {
            yield from $this->csvRows();
            return;
        }
        if ($this->type === 'pdf') {
            // ورقة افتراضية من بنود الفاتورة: سعر الفاتورة هو سعر شراء المحل، فيُقرأ في عمود سعر الشراء.
            yield [1, ['م', 'اسم الصنف', 'الكمية', 'سعر الشراء', 'الإجمالي']];
            foreach ($this->pdf['items'] as $k => $it) {
                $cells = [0 => (string) $it['seq'], 1 => $it['name'], 2 => from_hundredths($it['qty'])];
                if ($it['price'] !== null) {
                    $cells[3] = from_hundredths($it['price']);
                }
                if ($it['line_total'] !== null) {
                    $cells[4] = from_hundredths($it['line_total']);
                }
                yield [$k + 2, $cells];
            }
            return;
        }
        $sheet = $this->sheets[$sheetIndex] ?? null;
        $entry = $sheet ? $this->zip->find($sheet['path']) : null;
        $xml = $entry !== null ? $this->zip->read($entry) : null;
        if ($xml === null || $xml === '') {
            return;
        }
        $strings = $this->sharedStrings();
        $x = new XMLReader();
        $x->XML($xml, 'UTF-8', LIBXML_NONET | LIBXML_COMPACT | LIBXML_PARSEHUGE);
        unset($xml);

        $rowNum = 0;
        $cells = [];
        $nextCol = 0;
        $col = 0;
        $type = '';
        $value = null;
        $inRow = false;
        $inCell = false;
        while ($x->read()) {
            if ($x->nodeType === XMLReader::ELEMENT) {
                $name = $x->localName;
                if ($name === 'row') {
                    $r = $x->getAttribute('r');
                    $rowNum = $r !== null ? (int) $r : $rowNum + 1;
                    $cells = [];
                    $nextCol = 0;
                    if ($x->isEmptyElement) {
                        yield [$rowNum, []];
                    } else {
                        $inRow = true;
                    }
                } elseif ($name === 'c' && $inRow) {
                    $ref = $x->getAttribute('r');
                    $col = $ref !== null ? self::columnIndex($ref) : $nextCol;
                    $nextCol = $col + 1;
                    $type = (string) $x->getAttribute('t');
                    $value = null;
                    $inCell = !$x->isEmptyElement;
                } elseif ($inCell && $name === 'v') {
                    $value = $x->readString();
                } elseif ($inCell && $name === 't' && $type === 'inlineStr') {
                    $value = ($value ?? '') . $x->readString();
                }
            } elseif ($x->nodeType === XMLReader::END_ELEMENT) {
                if ($x->localName === 'c' && $inCell) {
                    $inCell = false;
                    if ($value !== null) {
                        if ($type === 's') {
                            $value = $strings[(int) $value] ?? '';
                        } elseif ($type === 'b') {
                            $value = $value === '1' ? 'TRUE' : 'FALSE';
                        } elseif ($type === 'e') {
                            $value = '';
                        }
                        if ($value !== '') {
                            $cells[$col] = $value;
                        }
                    }
                } elseif ($x->localName === 'row' && $inRow) {
                    $inRow = false;
                    yield [$rowNum, $cells];
                }
            }
        }
        $x->close();
    }

    public static function columnIndex(string $ref): int
    {
        $n = 0;
        $len = strlen($ref);
        for ($i = 0; $i < $len; $i++) {
            $c = ord($ref[$i]) & 0xDF;                 // حرف كبير
            if ($c < 65 || $c > 90) {
                break;
            }
            $n = $n * 26 + ($c - 64);
        }
        return max(0, $n - 1);
    }

    private function openXlsx(): void
    {
        $this->zip = new ZipFile($this->path);
        $workbook = $this->zip->find('xl/workbook.xml');
        if ($workbook === null) {
            throw new UserError('ملف xlsx غير صالح: لا يحتوي على xl/workbook.xml.');
        }

        $targets = [];
        $relsName = $this->zip->find('xl/_rels/workbook.xml.rels');
        if ($relsName !== null) {
            $x = new XMLReader();
            $x->XML((string) $this->zip->read($relsName), 'UTF-8', LIBXML_NONET);
            while ($x->read()) {
                if ($x->nodeType === XMLReader::ELEMENT && $x->localName === 'Relationship') {
                    $targets[(string) $x->getAttribute('Id')] = (string) $x->getAttribute('Target');
                }
            }
            $x->close();
        }

        $x = new XMLReader();
        $x->XML((string) $this->zip->read($workbook), 'UTF-8', LIBXML_NONET);
        while ($x->read()) {
            if ($x->nodeType !== XMLReader::ELEMENT || $x->localName !== 'sheet') {
                continue;
            }
            $rid = $x->getAttributeNs('id', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships')
                ?? $x->getAttribute('r:id');
            $target = $targets[(string) $rid] ?? null;
            if ($target === null || $target === '') {
                continue;
            }
            $target = ltrim(str_replace('\\', '/', $target), '/');
            if (strpos($target, 'xl/') !== 0) {
                $target = 'xl/' . $target;
            }
            $state = (string) $x->getAttribute('state');
            $this->sheets[] = [
                'name'   => (string) $x->getAttribute('name'),
                'path'   => $target,
                'hidden' => $state === 'hidden' || $state === 'veryHidden',
            ];
        }
        $x->close();
        if (!$this->sheets) {
            throw new UserError('لم يُعثر على أي ورقة عمل داخل الملف.');
        }
    }

    /** @return string[] */
    private function sharedStrings(): array
    {
        if ($this->sharedStrings !== null) {
            return $this->sharedStrings;
        }
        $this->sharedStrings = [];
        $name = $this->zip->find('xl/sharedStrings.xml');
        if ($name === null) {
            return $this->sharedStrings;
        }
        $x = new XMLReader();
        $x->XML((string) $this->zip->read($name), 'UTF-8', LIBXML_NONET | LIBXML_COMPACT | LIBXML_PARSEHUGE);
        $current = null;
        $phonetic = false;
        while ($x->read()) {
            if ($x->nodeType === XMLReader::ELEMENT) {
                if ($x->localName === 'si') {
                    if ($x->isEmptyElement) {
                        $this->sharedStrings[] = '';
                    } else {
                        $current = '';
                    }
                } elseif ($x->localName === 'rPh') {
                    $phonetic = !$x->isEmptyElement;          // نطق ياباني ملحق بالنص: يُتجاهل
                } elseif ($x->localName === 't' && $current !== null && !$phonetic) {
                    $current .= $x->readString();
                }
            } elseif ($x->nodeType === XMLReader::END_ELEMENT) {
                if ($x->localName === 'si' && $current !== null) {
                    $this->sharedStrings[] = $current;
                    $current = null;
                } elseif ($x->localName === 'rPh') {
                    $phonetic = false;
                }
            }
        }
        $x->close();
        return $this->sharedStrings;
    }

    private function csvRows(): Generator
    {
        $raw = (string) file_get_contents($this->path);
        if (strncmp($raw, "\xFF\xFE", 2) === 0) {
            $raw = mb_convert_encoding(substr($raw, 2), 'UTF-8', 'UTF-16LE');
        } elseif (strncmp($raw, "\xFE\xFF", 2) === 0) {
            $raw = mb_convert_encoding(substr($raw, 2), 'UTF-8', 'UTF-16BE');
        } elseif (strncmp($raw, "\xEF\xBB\xBF", 3) === 0) {
            $raw = substr($raw, 3);
        } elseif (!mb_check_encoding($raw, 'UTF-8')) {
            // Excel العربي يحفظ "CSV (Comma delimited)" بترميز Windows-1256 وليس UTF-8.
            $converted = function_exists('iconv') ? @iconv('CP1256', 'UTF-8//IGNORE', $raw) : false;
            $raw = $converted !== false ? $converted : mb_convert_encoding($raw, 'UTF-8', 'UTF-8');
        }
        $delimiter = self::detectDelimiter($raw);

        $fh = fopen('php://temp', 'r+');
        fwrite($fh, $raw);
        unset($raw);
        rewind($fh);
        $rowNum = 0;
        while (($row = fgetcsv($fh, 0, $delimiter, '"', '')) !== false) {
            $rowNum++;
            $cells = [];
            foreach ($row as $i => $value) {
                if ($value !== null && trim($value) !== '') {
                    $cells[$i] = $value;
                }
            }
            yield [$rowNum, $cells];
        }
        fclose($fh);
    }

    private static function detectDelimiter(string $raw): string
    {
        $sample = substr($raw, 0, 8192);
        $lines = array_slice(preg_split('/\r\n|\n|\r/', $sample) ?: [], 0, 10);
        $best = ',';
        $bestScore = 0;
        foreach ([',', ';', "\t", '|'] as $candidate) {
            $score = 0;
            foreach ($lines as $line) {
                $score += substr_count(preg_replace('/"[^"]*"/', '', $line) ?? $line, $candidate);
            }
            if ($score > $bestScore) {
                $best = $candidate;
                $bestScore = $score;
            }
        }
        return $best;
    }
}

/**
 * يبحث في أول صفوف الورقة عن صف العناوين ويحدد عمود كل دور.
 *
 * @param array $rows      أول الصفوف كما تعيدها rows(): [[رقم الصف، الخلايا], ...]
 * @param array $roles     الدور => ['words' => كلمات مطبَّعة بالأولوية، 'exclude' => كلمات تستبعد العمود]
 * @param string[] $required أدوار يجب وجودها ليُعتبر الصف صف عناوين
 * @return array{header_row: ?int, columns: array<string, ?int>}
 */
function detect_header(array $rows, array $roles, array $required): array
{
    foreach ($rows as [$rowNum, $cells]) {
        // صف العناوين نص فقط: صف فيه رقم (كمية أو سعر أو باركود) صف بيانات، حتى لو احتوى اسم صنفه كلمة "صنف".
        foreach ($cells as $text) {
            if (trim((string) $text) !== '' && to_hundredths((string) $text) !== null) {
                continue 2;
            }
        }
        $candidates = [];
        foreach ($cells as $col => $text) {
            $norm = normalize_search((string) $text);
            if ($norm === '' || mb_strlen($norm) > 40) {
                continue;
            }
            foreach ($roles as $role => $def) {
                foreach ($def['exclude'] ?? [] as $bad) {
                    if (mb_strpos($norm, $bad) !== false) {
                        continue 2;
                    }
                }
                foreach ($def['words'] as $rank => $word) {
                    if ($norm === $word) {
                        $score = 1000 - $rank * 10;
                    } elseif (mb_strpos($norm, $word) !== false) {
                        $score = 500 - $rank * 10;
                    } else {
                        continue;
                    }
                    $candidates[] = [$score, $role, (int) $col];
                    break;
                }
            }
        }
        if (!$candidates) {
            continue;
        }
        usort($candidates, function ($a, $b) {
            return $b[0] <=> $a[0];
        });
        $columns = array_fill_keys(array_keys($roles), null);
        $usedCols = [];
        foreach ($candidates as [$score, $role, $col]) {
            if ($columns[$role] === null && !isset($usedCols[$col])) {
                $columns[$role] = $col;
                $usedCols[$col] = true;
            }
        }
        $complete = true;
        foreach ($required as $role) {
            if ($columns[$role] === null) {
                $complete = false;
            }
        }
        if ($complete) {
            return ['header_row' => (int) $rowNum, 'columns' => $columns];
        }
    }
    return ['header_row' => null, 'columns' => array_fill_keys(array_keys($roles), null)];
}

/** قائمة أعمدة الورقة للاختيار اليدوي: [{index, letter, header}]. */
function sheet_columns(array $rows, ?int $headerRow): array
{
    $max = -1;
    $headers = [];
    foreach ($rows as [$rowNum, $cells]) {
        if ($cells) {
            $max = max($max, max(array_keys($cells)));
        }
        if ($headerRow !== null && $rowNum === $headerRow) {
            $headers = $cells;
        }
    }
    $columns = [];
    for ($i = 0; $i <= min($max, 51); $i++) {
        $columns[] = ['index' => $i, 'letter' => column_letter($i), 'header' => clean_text((string) ($headers[$i] ?? ''), 40)];
    }
    return $columns;
}

/** يحفظ الملف المرفوع في storage/tmp ويعيد [token, path, name]. */
function store_upload(string $field, string $prefix): array
{
    $file = $_FILES[$field] ?? null;
    if (!$file || !isset($file['error'])) {
        throw new UserError('لم يُرفع أي ملف.');
    }
    $errors = [
        UPLOAD_ERR_INI_SIZE   => 'الملف أكبر من الحد المسموح في php.ini (upload_max_filesize).',
        UPLOAD_ERR_FORM_SIZE  => 'الملف أكبر من الحد المسموح.',
        UPLOAD_ERR_PARTIAL    => 'رُفع جزء من الملف فقط. حاول مرة أخرى.',
        UPLOAD_ERR_NO_FILE    => 'لم يُختر أي ملف.',
        UPLOAD_ERR_NO_TMP_DIR => 'مجلد الملفات المؤقتة غير موجود على الخادم.',
        UPLOAD_ERR_CANT_WRITE => 'تعذر حفظ الملف على القرص.',
    ];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new UserError($errors[$file['error']] ?? 'فشل رفع الملف.');
    }
    if ($file['size'] > 30 * 1024 * 1024) {
        throw new UserError('الملف أكبر من 30MB.');
    }
    $name = clean_text((string) $file['name'], 120);
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($ext, ['xlsx', 'csv', 'txt', 'tsv', 'xls', 'pdf'], true)) {
        throw new UserError('صيغة الملف غير مدعومة. استخدم xlsx أو csv أو pdf.');
    }
    $token = bin2hex(random_bytes(16));
    $path = storage_path('tmp') . '/' . $prefix . '_' . $token . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $path)) {
        throw new UserError('تعذر حفظ الملف المرفوع.');
    }
    file_put_contents($path . '.json', json_encode(['name' => $name, 'path' => $path], JSON_UNESCAPED_UNICODE));
    return ['token' => $token, 'path' => $path, 'name' => $name];
}

/** يسترجع ملفاً رُفع سابقاً بالرمز الذي أعادته المعاينة. */
function load_upload(string $token, string $prefix): array
{
    if (!preg_match('/^[a-f0-9]{32}$/', $token)) {
        throw new UserError('رمز الملف غير صالح. أعد رفع الملف.');
    }
    $matches = glob(storage_path('tmp') . '/' . $prefix . '_' . $token . '.*.json') ?: [];
    $meta = $matches ? json_decode((string) file_get_contents($matches[0]), true) : null;
    if (!is_array($meta) || !is_file($meta['path'] ?? '')) {
        throw new UserError('انتهت صلاحية الملف المرفوع. أعد رفعه ومعاينته.');
    }
    return ['token' => $token, 'path' => $meta['path'], 'name' => $meta['name']];
}

function discard_upload(array $upload, ?SpreadsheetReader $reader = null): void
{
    if ($reader) {
        $reader->close();
    }
    @unlink($upload['path']);
    @unlink($upload['path'] . '.json');
    @unlink($upload['path'] . '.pdf.json');
}
