<?php
/**
 * مشغّل ترحيلات المخطط: ينفذ ملفات sql/NNN_*.sql الأحدث من الإصدار المسجل في app_meta، بالترتيب.
 *
 * قاعدة الترحيلات: إضافية فقط (CREATE TABLE / ADD COLUMN ... IF NOT EXISTS) وآمنة لإعادة التشغيل،
 * لأن جمل DDL في MySQL تُنهي المعاملة ضمنياً ولا يمكن التراجع عنها.
 * عند إضافة ملف جديد في sql/ ارفع SCHEMA_VERSION إلى رقمه.
 */

const SCHEMA_VERSION = 7;

function schema_version(PDO $pdo): int
{
    try {
        $value = $pdo->query("SELECT meta_value FROM app_meta WHERE meta_key = 'schema_version'")->fetchColumn();
        return $value === false ? 0 : (int) $value;
    } catch (PDOException $e) {
        return 0;                                   // app_meta غير موجود بعد
    }
}

/**
 * اتصال قاعدة البيانات لصفحة HTML (index.php و login.php): قاعدة غير موجودة أو مخطط أقدم من الكود
 * يحوّل إلى install.php، وقاعدة متوقفة تعرض views/db_down.php. لا يعود في الحالتين.
 */
function db_for_page(): PDO
{
    try {
        $pdo = db();
        if (schema_version($pdo) < SCHEMA_VERSION) {
            header('Location: install.php');
            exit;
        }
        return $pdo;
    } catch (PDOException $e) {
        error_log('[page] ' . $e->getMessage());
        $unknownDb = (int) ($e->errorInfo[1] ?? $e->getCode()) === 1049 || strpos($e->getMessage(), '[1049]') !== false;
        if ($unknownDb) {
            header('Location: install.php');
            exit;
        }
        http_response_code(503);
        $dbError = $e->getMessage();
        require APP_ROOT . '/views/db_down.php';
        exit;
    }
}

/** @return string[] أسماء الملفات التي نُفذت */
function run_migrations(PDO $pdo): array
{
    $pdo->exec("CREATE TABLE IF NOT EXISTS app_meta (
        meta_key VARCHAR(50) NOT NULL PRIMARY KEY,
        meta_value VARCHAR(255) NOT NULL DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $current = schema_version($pdo);
    $files = glob(APP_ROOT . '/sql/[0-9][0-9][0-9]_*.sql') ?: [];
    sort($files, SORT_STRING);

    $applied = [];
    foreach ($files as $file) {
        $version = (int) substr(basename($file), 0, 3);
        if ($version <= $current) {
            continue;
        }
        foreach (split_sql((string) file_get_contents($file)) as $statement) {
            try {
                $pdo->exec($statement);
            } catch (PDOException $e) {
                throw new RuntimeException(basename($file) . ': ' . $e->getMessage() . "\n" . $statement, 0, $e);
            }
        }
        meta_set($pdo, 'schema_version', (string) $version);
        $applied[] = basename($file);
    }
    return $applied;
}

/**
 * يقسم ملف SQL إلى جمل: كل جملة تنتهي بفاصلة منقوطة في آخر السطر.
 * يتجاهل التعليقات (--) وجملتي CREATE DATABASE و USE، فاسم القاعدة يأتي من config/db.php دائماً.
 */
function split_sql(string $sql): array
{
    $sql = preg_replace('/^\xEF\xBB\xBF/', '', $sql);
    $statements = [];
    $buffer = '';
    // فواصل الأسطر الحقيقية فقط: \R بدون u يطابق البايت 0x85 الموجود داخل حروف عربية مثل "م".
    foreach (preg_split('/\r\n|\n|\r/', $sql) as $line) {
        $trimmed = trim($line);
        if ($trimmed === '' || strpos($trimmed, '--') === 0) {
            continue;
        }
        $buffer .= $line . "\n";
        if (substr($trimmed, -1) === ';') {
            $statement = trim(substr(trim($buffer), 0, -1));
            $buffer = '';
            if ($statement !== '' && !preg_match('/^(CREATE\s+DATABASE|USE)\b/i', $statement)) {
                $statements[] = $statement;
            }
        }
    }
    if (trim($buffer) !== '') {
        $statements[] = trim($buffer);
    }
    return $statements;
}
