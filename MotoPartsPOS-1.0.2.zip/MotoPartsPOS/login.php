<?php
/**
 * تسجيل الدخول. المستخدمون في جدول users (sql/007_auth_login.sql)، والتصميم في views/login.php.
 * بعد الدخول يعود المستخدم للصفحة التي طلبها (?next=index.php?page=…).
 */
define('PUBLIC_PAGE', true);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/migrations.php';

if (!request_host_allowed()) {
    http_response_code(403);
    exit('Forbidden host');
}

$next = auth_safe_next($_POST['next'] ?? $_GET['next'] ?? '');
if (auth_user() !== null) {
    header('Location: ' . $next);
    exit;
}

// جدول المستخدمين يأتي مع الترحيل 007: قبله تحوّل هذه الدالة إلى install.php.
$pdo = db_for_page();

$error = null;
$notice = null;
$username = '';
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $username = clean_text(is_string($_POST['username'] ?? null) ? $_POST['username'] : '', 50);
    $password = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';
    $site = $_SERVER['HTTP_SEC_FETCH_SITE'] ?? '';
    if (($site !== '' && $site !== 'same-origin') || !auth_csrf_valid($_POST['csrf'] ?? null)) {
        $error = 'انتهت صلاحية الصفحة. أدخل كلمة المرور مرة أخرى ثم اضغط تسجيل الدخول.';
    } else {
        $error = auth_login($pdo, $username, $password);
        if ($error === null) {
            header('Location: ' . $next);
            exit;
        }
    }
} elseif (($_GET['bye'] ?? '') === '1') {
    $notice = 'تم تسجيل الخروج.';
} elseif (($_GET['expired'] ?? '') === '1') {
    $notice = 'انتهت الجلسة لعدم الاستخدام. سجّل الدخول مرة أخرى.';
}

$csrf = auth_csrf_token();
require __DIR__ . '/views/login.php';
