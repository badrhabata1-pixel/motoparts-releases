<?php
/**
 * إعدادات التطبيق.
 *
 * لا تعدّل هذا الملف على جهاز المحل: ضع أي قيمة مختلفة في config/local.php
 * (انسخ config/local.example.php). المحدّث التلقائي لا يستبدل local.php أبداً.
 */

if (is_file(__DIR__ . '/local.php')) {
    require_once __DIR__ . '/local.php';
}

defined('APP_NAME') || define('APP_NAME', 'MotoParts POS');
defined('APP_VERSION') || define('APP_VERSION', (string) require __DIR__ . '/version.php');

// Africa/Cairo يتبع قواعد التوقيت الصيفي المصري الحالية.
// إن كانت ساعة Windows 8.1 (نظام غير محدَّث) لا تعرف التوقيت الصيفي فاستخدم 'Etc/GMT-2' (= UTC+02:00 ثابت)
// حتى تطابق ساعة رأس الشاشة ساعة شريط المهام.
defined('APP_TIMEZONE') || define('APP_TIMEZONE', 'Africa/Cairo');
defined('APP_CURRENCY') || define('APP_CURRENCY', 'ج.م');

// البيع بكمية أكبر من الرصيد المسجل: true = يُسمح مع تحذير، false = يُمنع حفظ الفاتورة.
defined('ALLOW_NEGATIVE_STOCK') || define('ALLOW_NEGATIVE_STOCK', true);

// أول باركود يولّده النظام. الأرقام بطول ثابت (6 خانات) تسهّل الطباعة والمسح.
defined('BARCODE_START') || define('BARCODE_START', 100001);
defined('DEFAULT_MIN_ALERT') || define('DEFAULT_MIN_ALERT', '5.00');

// أقصى فاصل بالملي ثانية بين حرفين ليُعتبر الإدخال قادماً من الماسح. زِده إلى 80 للماسحات اللاسلكية البطيئة.
defined('SCAN_MAX_GAP_MS') || define('SCAN_MAX_GAP_MS', 50);

// أسماء المضيف المسموح بها في ترويسة Host (حماية من DNS rebinding).
// أضف عنوان IP الجهاز هنا فقط إذا استُخدم النظام من جهاز آخر على الشبكة.
defined('APP_ALLOWED_HOSTS') || define('APP_ALLOWED_HOSTS', ['localhost', '127.0.0.1', '[::1]']);

// تسجيل الدخول: الجلسة تنتهي بعد هذا العدد من الدقائق بلا أي استخدام، أو عند إغلاق نافذة البرنامج.
// 720 = 12 ساعة: يوم عمل كامل دون خروج، والجهاز المتروك مفتوحاً للصباح يطلب الدخول من جديد.
defined('AUTH_IDLE_MINUTES') || define('AUTH_IDLE_MINUTES', 720);

// التحديث التلقائي: مصدر ملف latest_version.json. فارغ = التحديث معطّل.
// - رابط HTTPS: https://example.com/motoparts/latest_version.json
// - أو مسار على هذا الجهاز (مجلد أو فلاشة) بلا إنترنت: C:/MotoPartsPOS/updates/latest_version.json
//   وتوضع حزمة MotoPartsPOS-x.y.z.zip في المجلد نفسه (tools/build_release.php --local).
defined('UPDATE_MANIFEST_URL') || define('UPDATE_MANIFEST_URL', '');
// مفتاح Ed25519 العام (base64) للتحقق من توقيع حزمة التحديث. يتطلب extension=sodium في php.ini.
// فارغ = التحقق ببصمة SHA-256 فقط.
defined('UPDATE_PUBLIC_KEY') || define('UPDATE_PUBLIC_KEY', '');

// عدد النسخ الاحتياطية اليومية المحفوظة في storage/backups.
defined('BACKUP_KEEP') || define('BACKUP_KEEP', 30);

date_default_timezone_set(APP_TIMEZONE);
