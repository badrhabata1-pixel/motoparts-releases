<?php
/**
 * اتصال قاعدة البيانات عبر PDO — MariaDB على المنفذ 3307.
 *
 * 127.0.0.1 وليس localhost: يفرض اتصال TCP على المنفذ المحدد، ويتجنب محاولة ::1 أولاً
 * التي تؤخر كل اتصال على Windows إذا كانت MariaDB مقيّدة على IPv4.
 */
require_once __DIR__ . '/app.php';

defined('DB_HOST') || define('DB_HOST', '127.0.0.1');
defined('DB_PORT') || define('DB_PORT', 3307);
defined('DB_NAME') || define('DB_NAME', 'motoparts_db');
defined('DB_USER') || define('DB_USER', 'root');
defined('DB_PASS') || define('DB_PASS', '');

/** اتصال جديد. $withDatabase = false يُستخدم فقط لإنشاء قاعدة البيانات أثناء التثبيت. */
function db_connect(bool $withDatabase = true): PDO
{
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . (int) DB_PORT
        . ($withDatabase ? ';dbname=' . DB_NAME : '') . ';charset=utf8mb4';

    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    // نفس إزاحة PHP الحالية (بما فيها التوقيت الصيفي)، فيتطابق CURRENT_TIMESTAMP مع حدود "اليوم" في التقارير.
    $pdo->exec("SET time_zone = '" . date('P') . "'");
    return $pdo;
}

/** اتصال واحد مشترك طوال الطلب. */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $pdo = db_connect();
    }
    return $pdo;
}
