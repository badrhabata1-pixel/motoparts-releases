<?php
// انسخ هذا الملف باسم local.php وفعّل ما تحتاجه فقط. القيم هنا تتقدم على config/app.php و config/db.php،
// ولا يستبدل المحدّث التلقائي ملف local.php أبداً.

// define('DB_PASS', 'كلمة-المرور');
// define('APP_TIMEZONE', 'Etc/GMT-2');          // ساعة Windows لا تعرف التوقيت الصيفي
// define('ALLOW_NEGATIVE_STOCK', false);        // منع البيع فوق الرصيد
// define('SCAN_MAX_GAP_MS', 80);                // ماسح لاسلكي أبطأ
// define('UPDATE_MANIFEST_URL', 'https://example.com/motoparts/latest_version.json');
// define('UPDATE_MANIFEST_URL', 'C:/MotoPartsPOS/updates/latest_version.json');   // تحديث من مجلد أو فلاشة
// define('AUTH_IDLE_MINUTES', 240);             // تسجيل خروج تلقائي بعد 4 ساعات بلا استخدام
