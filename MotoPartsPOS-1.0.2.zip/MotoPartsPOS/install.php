<?php
/**
 * التثبيت والترقية: ينشئ قاعدة البيانات إن لم تكن موجودة، ويشغّل ترحيلات sql/ بالترتيب.
 * آمن لإعادة التشغيل في أي وقت ولا يحذف بيانات. من سطر الأوامر: php install.php
 *
 * من المتصفح: مفتوح بلا تسجيل دخول فقط ما دامت القاعدة تحتاج ترحيلاً (جدول المستخدمين نفسه يأتي
 * مع الترحيل 007، فلا دخول قبله). بعد ذلك يتطلب تسجيل الدخول كبقية الصفحات.
 */
define('PUBLIC_PAGE', true);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/migrations.php';
require __DIR__ . '/includes/inventory.php';

$cli = PHP_SAPI === 'cli';

/** @return array<int, array{0:string,1:string}> سطور السجل: [ok|warn، النص] */
function install_run(): array
{
    if (version_compare(PHP_VERSION, '7.4.0', '<')) {
        throw new RuntimeException('يتطلب PHP 7.4 أو أحدث. الإصدار الحالي: ' . PHP_VERSION);
    }
    foreach (['pdo_mysql', 'mbstring', 'xmlreader', 'zlib', 'json'] as $ext) {
        if (!extension_loaded($ext)) {
            throw new RuntimeException('امتداد PHP مطلوب وغير مفعّل في php.ini: ' . $ext);
        }
    }
    $log = [['ok', 'PHP ' . PHP_VERSION]];
    $optional = [
        'zip'          => 'قراءة xlsx أسرع (يوجد بديل داخلي)',
        'iconv'        => 'قراءة ملفات CSV المحفوظة بترميز Windows-1256',
        'curl'         => 'التحديث التلقائي (يوجد بديل)',
        'Zend OPcache' => 'تسريع PHP على الأجهزة القديمة — فعّله في php.ini',
    ];
    foreach ($optional as $ext => $why) {
        $loaded = extension_loaded($ext);
        $log[] = [$loaded ? 'ok' : 'warn', $ext . ($loaded ? '' : ' غير مفعّل: ' . $why)];
    }

    $server = db_connect(false);
    $version = (string) $server->query('SELECT VERSION()')->fetchColumn();
    if (stripos($version, 'mariadb') === false) {
        throw new RuntimeException('الترحيلات مكتوبة لـ MariaDB (المرفقة مع XAMPP)، والخادم الحالي: ' . $version);
    }
    $log[] = ['ok', 'MariaDB ' . $version . ' على ' . DB_HOST . ':' . DB_PORT];
    $server->exec('CREATE DATABASE IF NOT EXISTS `' . str_replace('`', '', DB_NAME) . '`
                   CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $server = null;

    $pdo = db();
    $applied = run_migrations($pdo);
    $log[] = ['ok', $applied ? 'ترحيلات نُفذت: ' . implode('، ', $applied) : 'المخطط محدَّث بالفعل'];
    $log[] = ['ok', 'إصدار المخطط: ' . schema_version($pdo) . ' — قاعدة البيانات: ' . DB_NAME];

    $fixed = rebuild_search_keys($pdo);
    if ($fixed) {
        $log[] = ['ok', 'حُدّث مفتاح البحث لـ ' . $fixed . ' صنف'];
    }
    foreach (['backups', 'logs', 'tmp', 'updates', 'sessions'] as $dir) {
        storage_path($dir);
    }
    $count = (int) $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
    $log[] = ['ok', 'عدد الأصناف الحالي: ' . $count];
    return $log;
}

if ($cli) {
    try {
        foreach (install_run() as [$level, $text]) {
            echo strtoupper($level), '  ', $text, PHP_EOL;
        }
        exit(0);
    } catch (Throwable $e) {
        fwrite(STDERR, 'ERROR  ' . $e->getMessage() . PHP_EOL);
        exit(1);
    }
}

if (!request_host_allowed()) {
    http_response_code(403);
    exit('Forbidden host');
}

if (auth_user() === null) {
    try {
        $upToDate = schema_version(db()) >= SCHEMA_VERSION;
    } catch (PDOException $e) {
        $upToDate = false;                          // القاعدة غير موجودة أو متوقفة: الصفحة تعرض السبب
    }
    if ($upToDate) {
        auth_require();
    }
}

$log = null;
$error = null;
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $site = $_SERVER['HTTP_SEC_FETCH_SITE'] ?? '';
    if ($site !== '' && $site !== 'same-origin') {
        http_response_code(403);
        exit('Cross-site request blocked');
    }
    try {
        $log = install_run();
    } catch (Throwable $e) {
        error_log('[install] ' . $e);
        $error = $e->getMessage();
    }
}
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>التثبيت — <?= h(APP_NAME) ?></title>
<link rel="icon" href="data:,">
<link rel="stylesheet" href="<?= h(asset('assets/css/style.css')) ?>">
</head>
<body>
<main class="page page--narrow">
  <section class="card">
    <div class="card__head"><h1 class="card__title">تثبيت وترقية قاعدة البيانات</h1></div>
    <div class="card__body stack">
      <p>ينشئ قاعدة <code><?= h(DB_NAME) ?></code> على <code><?= h(DB_HOST . ':' . DB_PORT) ?></code> إن لم تكن موجودة،
         ثم يطبّق ترحيلات المخطط بالترتيب. التشغيل آمن في أي وقت ولا يحذف أي بيانات.</p>
      <?php if ($error !== null): ?>
        <div class="alert alert--danger"><strong>تعذّر الإكمال:</strong> <?= h($error) ?></div>
      <?php endif; ?>
      <?php if ($log !== null): ?>
        <ul class="checklist">
          <?php foreach ($log as [$level, $text]): ?>
            <li class="checklist__item checklist__item--<?= h($level) ?>"><?= h($text) ?></li>
          <?php endforeach; ?>
        </ul>
        <a class="btn btn--primary btn--xl" href="index.php">فتح نقطة البيع</a>
      <?php else: ?>
        <form method="post">
          <button type="submit" class="btn btn--primary btn--xl">تشغيل التثبيت / الترقية</button>
        </form>
      <?php endif; ?>
    </div>
  </section>
</main>
</body>
</html>
